import { assertInvocationCurrent } from "../invocation.js";
/**
 * compat/extension-kv.ts — Extension KV store client for standalone addons.
 *
 * Accesses piclaw's global extension KV store bridge when running inside
 * the piclaw runtime. Falls back to an in-memory store for standalone use.
 *
 * Extensions use this through scoped wrappers that bind the extension ID.
 */

export type KvScope = "chat" | "global";

export interface ExtensionStorage {
  write<T>(body: () => T): Promise<T>;
  get<T = unknown>(key: string, scope?: KvScope, scopeKey?: string): T | null;
  set(key: string, value: unknown, scope?: KvScope, scopeKey?: string): void;
  delete(key: string, scope?: KvScope, scopeKey?: string): boolean;
  list(prefix?: string, scope?: KvScope, scopeKey?: string): string[];
  clear(scope?: KvScope, scopeKey?: string): number;
}

// ── In-memory fallback ───────────────────────────────────────────

class InMemoryStorage implements ExtensionStorage {
  async write<T>(body: () => T): Promise<T> { return body(); }
  private store = new Map<string, string>();
  constructor(private extensionId: string) {}

  private k(key: string, scope?: KvScope, scopeKey?: string): string {
    return `${this.extensionId}\0${scope || "chat"}\0${scopeKey || ""}\0${key}`;
  }

  get<T = unknown>(key: string, scope?: KvScope, scopeKey?: string): T | null {
    assertInvocationCurrent();
    const v = this.store.get(this.k(key, scope, scopeKey));
    return v ? JSON.parse(v) : null;
  }

  set(key: string, value: unknown, scope?: KvScope, scopeKey?: string): void {
    assertInvocationCurrent();
    this.store.set(this.k(key, scope, scopeKey), JSON.stringify(value));
  }

  delete(key: string, scope?: KvScope, scopeKey?: string): boolean {
    assertInvocationCurrent();
    return this.store.delete(this.k(key, scope, scopeKey));
  }

  list(prefix?: string, scope?: KvScope, scopeKey?: string): string[] {
    assertInvocationCurrent();
    const base = `${this.extensionId}\0${scope || "chat"}\0${scopeKey || ""}\0`;
    const keys: string[] = [];
    for (const k of this.store.keys()) {
      if (k.startsWith(base)) {
        const remainder = k.slice(base.length);
        if (!prefix || remainder.startsWith(prefix)) keys.push(remainder);
      }
    }
    return keys.sort();
  }

  clear(scope?: KvScope, scopeKey?: string): number {
    assertInvocationCurrent();
    const prefix = scopeKey
      ? `${this.extensionId}\0${scope || "chat"}\0${scopeKey}\0`
      : scope
        ? `${this.extensionId}\0${scope}\0`
        : `${this.extensionId}\0`;
    let count = 0;
    for (const k of [...this.store.keys()]) {
      if (k.startsWith(prefix)) { this.store.delete(k); count++; }
    }
    return count;
  }
}

// ── Runtime-backed storage ───────────────────────────────────────

interface RuntimeKvStore {
  write?<T>(extensionId: string, body: () => T): Promise<T>;
  get<T>(extensionId: string, key: string, scope?: KvScope, scopeKey?: string): T | null;
  set(extensionId: string, key: string, value: unknown, scope?: KvScope, scopeKey?: string): void;
  delete(extensionId: string, key: string, scope?: KvScope, scopeKey?: string): boolean;
  list(extensionId: string, prefix?: string, scope?: KvScope, scopeKey?: string): string[];
  clear(extensionId: string, scope?: KvScope, scopeKey?: string): number;
}

class RuntimeBackedStorage implements ExtensionStorage {
  async write<T>(body: () => T): Promise<T> {
    return this.store.write ? this.store.write(this.extensionId, body) : body();
  }
  constructor(private extensionId: string, private store: RuntimeKvStore) {}

  get<T = unknown>(key: string, scope?: KvScope, scopeKey?: string): T | null {
    assertInvocationCurrent();
    return this.store.get<T>(this.extensionId, key, scope, scopeKey);
  }

  set(key: string, value: unknown, scope?: KvScope, scopeKey?: string): void {
    assertInvocationCurrent();
    this.store.set(this.extensionId, key, value, scope, scopeKey);
  }

  delete(key: string, scope?: KvScope, scopeKey?: string): boolean {
    assertInvocationCurrent();
    return this.store.delete(this.extensionId, key, scope, scopeKey);
  }

  list(prefix?: string, scope?: KvScope, scopeKey?: string): string[] {
    assertInvocationCurrent();
    return this.store.list(this.extensionId, prefix, scope, scopeKey);
  }

  clear(scope?: KvScope, scopeKey?: string): number {
    assertInvocationCurrent();
    return this.store.clear(this.extensionId, scope, scopeKey);
  }
}

// ── Factory ──────────────────────────────────────────────────────

function getRuntimeInterop(): { getExtensionKvStore?: () => RuntimeKvStore } | null {
  const interop = (globalThis as { __piclawRuntimeInterop?: { getExtensionKvStore?: () => RuntimeKvStore } }).__piclawRuntimeInterop;
  return interop || null;
}

/**
 * Try to resolve piclaw's runtime KV store.
 * Add-ons must not import piclaw workspace/runtime source paths directly;
 * the installed runtime exposes the DB-backed store through this global bridge.
 */
function tryGetRuntimeStore(): RuntimeKvStore | null {
  try {
    const interop = getRuntimeInterop();
    if (typeof interop?.getExtensionKvStore === "function") {
      return interop.getExtensionKvStore();
    }
  } catch {
    // Not running inside piclaw — use fallback.
  }
  return null;
}

/**
 * Create a scoped ExtensionStorage for the given extension ID.
 * If running inside piclaw, uses the DB-backed store.
 * Otherwise falls back to in-memory.
 */
export function createExtensionStorage(extensionId: string): ExtensionStorage {
  const runtimeStore = tryGetRuntimeStore();
  if (runtimeStore) {
    return new RuntimeBackedStorage(extensionId, runtimeStore);
  }
  return new InMemoryStorage(extensionId);
}
