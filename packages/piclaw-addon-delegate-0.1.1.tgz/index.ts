export { default } from "./delegate";
