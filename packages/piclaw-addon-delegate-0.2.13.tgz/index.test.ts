import { describe, expect, test } from "bun:test";
import { existsSync, mkdtempSync, readFileSync, rmSync, symlinkSync, writeFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { tmpdir } from "node:os";
import { fileURLToPath } from "node:url";

import delegateAddon, { assertApprovedDelegateModelAttempt, buildDelegateModelChain, buildDelegateStatusUpdate, buildModelCandidates, captureRuntimeCatalog, classifyDelegateFailure, classifyModel, delegateProcessFailure, delegateStatusModelHint, describeImageCapability, delegateTaskPreview, getCurrentTier, getDelegateWorkspaceRoot, getExecutableCatalog, inspectDelegateFile, invalidateExecutableCatalog, isProviderAuthError, isRetryableDelegateFailure, mergeExecutableRuntimeMetadata, normalizeConfig, parseDelegateJsonOutput, parsePiListModelsOutput, prepareDelegateFile, providerSummaries, resolveDelegateCliCommand, runDelegateProcess, runtimeModelToAvailable, selectModel, validateDelegateResponseModel, validateExplicitDelegateModel } from "./delegate.ts";
import { buildProviderModePatch, resolveProviderMode } from "./web/index.ts";

const addonDir = dirname(fileURLToPath(import.meta.url));

describe("delegate addon", () => {
  test("exports an extension entrypoint", () => {
    expect(typeof delegateAddon).toBe("function");
  });

  test("compat storage avoids runtime source imports", () => {
    const source = readFileSync(resolve(addonDir, "compat", "extension-kv.ts"), "utf8");
    expect(source).not.toContain("require(");
    expect(source).not.toContain("piclaw/runtime/src");
  });

  test("delegate task previews are compact and single-line", () => {
    const preview = delegateTaskPreview("  Review\n\nthis long task and summarize the important findings for the user  ", 32);
    expect(preview).toBe("Review this long task and summa…");
  });

  test("delegate surfaces progress and timeline feedback guidance", () => {
    const source = readFileSync(resolve(addonDir, "delegate.ts"), "utf8");
    expect(source).toContain("setWorkingMessage");
    expect(source).toContain("setStatus?.(DELEGATE_STATUS_KEY");
    expect(source).toContain("clearDelegateProgress(ctx)");
    expect(source).toContain("visible one-sentence timeline update");
    expect(source).toContain("what you are delegating");
  });

  test("delegate status exposes model hint and prompt arguments", () => {
    const prompt = "  Summarize\n\nthis file and list the important decisions for Rui  ";
    expect(buildDelegateStatusUpdate("openai/gpt-5.4-mini", prompt)).toBe(
      "Delegate model: openai/gpt-5.4-mini\nArguments: Summarize this file and list the important decisions for Rui",
    );
    expect(delegateStatusModelHint({ model: "anthropic/claude-sonnet-4.6", prompt })).toBe("anthropic/claude-sonnet-4.6");
    expect(delegateStatusModelHint({ prompt }, { output_preview: buildDelegateStatusUpdate("openai/gpt-5.4-mini", prompt) })).toBe("openai/gpt-5.4-mini");
    expect(buildDelegateStatusUpdate("openai/gpt-5.4-mini", prompt, 2, 3)).toStartWith("Delegate (2 of 3) model:");
    expect(delegateStatusModelHint({ prompt }, { output_preview: buildDelegateStatusUpdate("openai/gpt-5.4-mini", prompt, 2, 3) })).toBe("openai/gpt-5.4-mini");
    expect(delegateStatusModelHint({ prompt }, { output_preview: "Delegate (2) model: openai/gpt-5.4-mini\nArguments: legacy count" })).toBe("openai/gpt-5.4-mini");
    expect(delegateStatusModelHint({ model: "old/model" }, { outputPreview: "Delegate (12 of 14) model: openai/gpt-5.4-mini\nArguments: fixture" })).toBe("openai/gpt-5.4-mini");
  });

  test("parses pi model list output", () => {
    const models = parsePiListModelsOutput(`provider        model              context  max-out  thinking  images
openai-codex    gpt-5.4-mini       272K     128K     yes       yes
anthropic       claude-sonnet-4.6  200K     32K      yes       yes
`);
    expect(models).toEqual([
      { provider: "openai-codex", id: "gpt-5.4-mini", fullId: "openai-codex/gpt-5.4-mini", context: "272K", maxOut: "128K", thinking: "yes", images: "yes", contextWindow: 272_000, maxOutputTokens: 128_000, reasoning: true, supportsImages: true, catalogSource: "cli" },
      { provider: "anthropic", id: "claude-sonnet-4.6", fullId: "anthropic/claude-sonnet-4.6", context: "200K", maxOut: "32K", thinking: "yes", images: "yes", contextWindow: 200_000, maxOutputTokens: 32_000, reasoning: true, supportsImages: true, catalogSource: "cli" },
    ]);
  });

  test("executable catalog cache expires explicitly, retries failures, and preserves last good data", async () => {
    const dir = mkdtempSync(join(tmpdir(), "delegate-catalog-"));
    const previousCli = process.env.PI_DELEGATE_CLI;
    try {
      const script = resolve(dir, "catalog.ts");
      const counter = resolve(dir, "count.txt");
      const failMarker = resolve(dir, "fail");
      const fixture = resolve(addonDir, "fixtures/cli-models-29.txt");
      writeFileSync(script, `
        import { existsSync, readFileSync, writeFileSync } from "node:fs";
        const counter = ${JSON.stringify(counter)};
        const count = existsSync(counter) ? Number(readFileSync(counter, "utf8")) : 0;
        writeFileSync(counter, String(count + 1));
        if (existsSync(${JSON.stringify(failMarker)})) { console.error("fixture discovery failed"); process.exit(2); }
        process.stdout.write(readFileSync(${JSON.stringify(fixture)}, "utf8"));
      `);
      process.env.PI_DELEGATE_CLI = `${process.execPath} ${script}`;
      const fresh = await getExecutableCatalog(true);
      expect(fresh).toMatchObject({ stale: false, lastError: null });
      expect(fresh.models).toHaveLength(29);
      expect(readFileSync(counter, "utf8")).toBe("1");
      const cached = await getExecutableCatalog(false);
      expect(cached.refreshedAt).toBe(fresh.refreshedAt);
      expect(readFileSync(counter, "utf8")).toBe("1");

      writeFileSync(failMarker, "fail");
      invalidateExecutableCatalog();
      const stale = await getExecutableCatalog(false);
      expect(stale).toMatchObject({ stale: true, lastError: "fixture discovery failed" });
      expect(stale.models).toHaveLength(29);
      expect(readFileSync(counter, "utf8")).toBe("2");
      const retried = await getExecutableCatalog(false);
      expect(retried.models).toHaveLength(29);
      expect(readFileSync(counter, "utf8")).toBe("3");
    } finally {
      if (previousCli === undefined) delete process.env.PI_DELEGATE_CLI;
      else process.env.PI_DELEGATE_CLI = previousCli;
      rmSync(dir, { recursive: true, force: true });
    }
  });

  test("cancellation interrupts executable-model discovery before delegation", async () => {
    const dir = mkdtempSync(join(tmpdir(), "delegate-discovery-abort-"));
    const previousCli = process.env.PI_DELEGATE_CLI;
    try {
      const script = resolve(dir, "slow-catalog.ts");
      writeFileSync(script, "await Bun.sleep(5000); console.log('Provider Model Context MaxOut Thinking Images');");
      process.env.PI_DELEGATE_CLI = `${process.execPath} ${script}`;
      invalidateExecutableCatalog();
      let tool: any;
      delegateAddon({
        on() {},
        getActiveTools() { return []; },
        setActiveTools() {},
        registerTool(candidate: any) { if (candidate.name === "delegate") tool = candidate; },
      });
      const controller = new AbortController();
      setTimeout(() => controller.abort(), 50);
      const started = Date.now();
      await expect(tool.execute("abort-discovery", { prompt: "never runs", timeout_sec: 10 }, controller.signal, undefined, {
        model: { provider: "github-copilot", id: "gpt-5.6-sol" },
        modelRegistry: { async refresh() {}, getAvailable() { return []; } },
      })).rejects.toThrow(/aborted/i);
      expect(Date.now() - started).toBeLessThan(1_000);
    } finally {
      if (previousCli === undefined) delete process.env.PI_DELEGATE_CLI;
      else process.env.PI_DELEGATE_CLI = previousCli;
      rmSync(dir, { recursive: true, force: true });
    }
  });

  test("tool execution rejects an explicit unapproved provider before child launch", async () => {
    const dir = mkdtempSync(join(tmpdir(), "delegate-unapproved-spawn-"));
    const previousCli = process.env.PI_DELEGATE_CLI;
    try {
      const script = resolve(dir, "delegate-cli.ts");
      const launchMarker = resolve(dir, "launched.txt");
      writeFileSync(script, `
        import { writeFileSync } from "node:fs";
        if (process.argv.includes("--list-models")) {
          console.log("provider model context max-out thinking images");
          console.log("openai-codex gpt-5.4 272K 128K yes yes");
          process.exit(0);
        }
        writeFileSync(${JSON.stringify(launchMarker)}, process.argv.join(" "));
      `);
      process.env.PI_DELEGATE_CLI = `${process.execPath} ${script}`;
      invalidateExecutableCatalog();
      let tool: any;
      delegateAddon({
        on() {},
        getActiveTools() { return []; },
        setActiveTools() {},
        registerTool(candidate: any) { if (candidate.name === "delegate") tool = candidate; },
      });
      await expect(tool.execute("unapproved", {
        prompt: "must not launch",
        model: "openai-codex/gpt-5.4",
      }, undefined, undefined, {
        model: { provider: "github-copilot", id: "gpt-5.6-sol" },
        modelRegistry: { getAvailable() { return [{ provider: "github-copilot", id: "gpt-5.6-sol" }]; } },
      })).rejects.toThrow("not in the approved provider list");
      expect(existsSync(launchMarker)).toBe(false);
    } finally {
      if (previousCli === undefined) delete process.env.PI_DELEGATE_CLI;
      else process.env.PI_DELEGATE_CLI = previousCli;
      invalidateExecutableCatalog();
      rmSync(dir, { recursive: true, force: true });
    }
  });

  test("model candidates require operator-approved providers and still apply default azure exclusions", () => {
    const models = [
      { provider: "github-copilot", id: "gpt-5.4-mini", fullId: "github-copilot/gpt-5.4-mini" },
      { provider: "openai", id: "gpt-5.4-mini", fullId: "openai/gpt-5.4-mini" },
      { provider: "anthropic", id: "claude-fable-5", fullId: "anthropic/claude-fable-5" },
      { provider: "anthropic", id: "claude-sonnet-4.6", fullId: "anthropic/claude-sonnet-4.6" },
      { provider: "azure-openai", id: "gpt-5.4-mini", fullId: "azure-openai/gpt-5.4-mini" },
    ];
    expect(buildModelCandidates(models, { searchable_providers: null, excluded_providers: null, excluded_models: [] })).toEqual([]);
    const candidates = buildModelCandidates(models, { searchable_providers: ["github-copilot", "openai", "anthropic", "azure-openai"], excluded_providers: null, excluded_models: [] });
    expect(candidates.some((candidate) => candidate.id === "openai/gpt-5.4-mini" && candidate.tier === 2)).toBe(true);
    expect(candidates.some((candidate) => candidate.id === "anthropic/claude-fable-5" && candidate.tier === 3)).toBe(true);
    expect(candidates.some((candidate) => candidate.id === "anthropic/claude-sonnet-4.6" && candidate.tier === 3)).toBe(true);
    expect(candidates.some((candidate) => candidate.provider.startsWith("azure-"))).toBe(false);
  });

  test("provider and model exclusions constrain the approved candidate list", () => {
    const models = [
      { provider: "github-copilot", id: "gpt-5-mini", fullId: "github-copilot/gpt-5-mini" },
      { provider: "github-copilot", id: "gpt-5.4-mini", fullId: "github-copilot/gpt-5.4-mini" },
      { provider: "openai", id: "gpt-5.4-mini", fullId: "openai/gpt-5.4-mini" },
      { provider: "azure-openai", id: "gpt-5.4-mini", fullId: "azure-openai/gpt-5.4-mini" },
      { provider: "openai-codex", id: "gpt-5.4", fullId: "openai-codex/gpt-5.4" },
    ];
    const allProviders = ["github-copilot", "openai", "azure-openai", "openai-codex"];
    const includeAzure = buildModelCandidates(models, { searchable_providers: allProviders, excluded_providers: [], excluded_models: [] });
    expect(includeAzure.some((candidate) => candidate.id === "azure-openai/gpt-5.4-mini")).toBe(true);

    const excludeOpenAi = buildModelCandidates(models, { searchable_providers: allProviders, excluded_providers: ["openai"], excluded_models: [] });
    expect(excludeOpenAi.some((candidate) => candidate.provider === "openai")).toBe(false);

    const excludeMini = buildModelCandidates(models, { searchable_providers: allProviders, excluded_providers: [], excluded_models: ["*mini*"] });
    expect(excludeMini.some((candidate) => candidate.modelId.includes("mini"))).toBe(false);
    expect(excludeMini.some((candidate) => candidate.id === "openai-codex/gpt-5.4")).toBe(true);
    const chain = buildDelegateModelChain("code", 3, "github-copilot/gpt-5.5", excludeMini);
    expect(chain.every((id) => !id.includes("mini"))).toBe(true);
  });

  test("provider toggles constrain matching and preserve configured preference order", () => {
    const models = [
      { provider: "github-copilot", id: "gpt-5.4-mini", fullId: "github-copilot/gpt-5.4-mini" },
      { provider: "openai", id: "gpt-5.4-mini", fullId: "openai/gpt-5.4-mini" },
      { provider: "anthropic", id: "claude-sonnet-4.6", fullId: "anthropic/claude-sonnet-4.6" },
    ];
    const candidates = buildModelCandidates(models, { searchable_providers: ["anthropic"], excluded_providers: null, excluded_models: [] });
    expect(candidates.every((candidate) => candidate.provider === "anthropic")).toBe(true);
    expect(candidates.some((candidate) => candidate.id === "anthropic/claude-sonnet-4.6")).toBe(true);
    expect(buildModelCandidates(models, { searchable_providers: [], excluded_providers: null, excluded_models: [] })).toEqual([]);
    const ordered = buildModelCandidates(models, { searchable_providers: ["openai", "github-copilot"], excluded_providers: [], excluded_models: [] });
    expect(ordered.filter((candidate) => candidate.modelId === "gpt-5.4-mini").map((candidate) => candidate.provider)).toEqual(["openai", "github-copilot"]);
  });

  test("deterministic classification does not cross major model variants", () => {
    expect(classifyModel("openai/gpt-5.4-mini")).toMatchObject({ status: "classified", tier: 2, family: "gpt", rule: "gpt-mini", confidence: "exact-policy" });
    expect(classifyModel("openai/gpt-5.4")).toMatchObject({ status: "classified", tier: 3, family: "gpt", rule: "gpt-5-4", confidence: "exact-policy" });
    expect(classifyModel("openai/mystery-9000")).toMatchObject({ status: "unclassified", tier: null, rule: null, confidence: "none" });
    const candidates = buildModelCandidates([
      { provider: "openai", id: "gpt-5.4", fullId: "openai/gpt-5.4" },
    ], { searchable_providers: ["openai"], excluded_providers: null, excluded_models: [] });
    expect(candidates).toHaveLength(1);
    expect(candidates[0]).toMatchObject({ id: "openai/gpt-5.4", tier: 3, sourceId: "gpt-5-4", matchScore: 100 });
  });

  test("Astra policy covers exact direct and routed IDs without accepting unknown variants", () => {
    const expected: Record<string, [number, string]> = {
      "github-copilot/gpt-6-astra": [3, "gpt-6-astra"],
      "openai-codex/gpt-6-astra": [3, "gpt-6-astra"],
      "openai/gpt-6-astra": [3, "gpt-6-astra"],
      "openrouter/openai/gpt-6-astra": [3, "gpt-6-astra"],
      "openrouter/openai/gpt-6-astra:batch": [3, "gpt-6-astra"],
      "openrouter/openai/gpt-6-astra-pro": [4, "gpt-6-astra-pro"],
      "openrouter/openai/gpt-6-astra-pro:batch": [4, "gpt-6-astra-pro"],
      "openai/gpt-6-astra-pro": [4, "gpt-6-astra-pro"],
      "azure-openai/GPT_6_ASTRA": [3, "gpt-6-astra"],
    };
    for (const [id, [tier, policyRule]] of Object.entries(expected)) {
      expect(classifyModel(id)).toMatchObject({ status: "classified", tier, family: "gpt", rule: policyRule, confidence: "exact-policy" });
    }
    for (const id of ["gpt-6", "gpt-6-other", "gpt-6-astra-mini", "gpt-6-astra-pro-preview", "gpt-6-astra:unknown", "gpt-6-astral", "other/gpt-6-astra"]) {
      expect(classifyModel(`openrouter/${id}`)).toMatchObject({ status: "unclassified", tier: null });
    }
  });

  test("Astra current model enables tier-capped automatic selection without bypassing approval", () => {
    const current = { provider: "github-copilot", id: "gpt-6-astra" };
    const maxTier = getCurrentTier({ model: current });
    expect(maxTier).toBe(3);
    const models = [current,
      { provider: "github-copilot", id: "gpt-5.4-mini" },
      { provider: "github-copilot", id: "claude-sonnet-5" },
      { provider: "openrouter", id: "openai/gpt-6-astra-pro" },
      { provider: "github-copilot", id: "claude-opus-4.8" },
    ].map(model => ({ ...model, fullId: `${model.provider}/${model.id}` }));
    const config = { searchable_providers: ["github-copilot", "openrouter"], excluded_providers: [], excluded_models: [] };
    const candidates = buildModelCandidates(models, config);
    expect(buildModelCandidates(models)).toEqual([]);
    expect(selectModel("quick", maxTier!, "github-copilot/gpt-6-astra", candidates)).toBe("github-copilot/gpt-5.4-mini");
    expect(selectModel("judge", maxTier!, "github-copilot/gpt-6-astra", candidates)).toBe("github-copilot/claude-sonnet-5");
    const chain = buildDelegateModelChain("code", maxTier!, "github-copilot/gpt-6-astra", candidates, 10);
    expect(chain).toContain("github-copilot/gpt-6-astra");
    expect(chain.every(id => candidates.find(candidate => candidate.id === id)!.tier <= 3)).toBe(true);
    expect(validateExplicitDelegateModel("github-copilot/gpt-6-astra", models, models, config).approved).toBe(true);
    expect(validateExplicitDelegateModel("github-copilot/gpt-6-astra", models, models, { ...config, searchable_providers: [] }).approved).toBe(false);
    expect(validateExplicitDelegateModel("github-copilot/gpt-6-astra", models, models, { ...config, excluded_models: ["*astra*"] }).approved).toBe(false);
    expect(validateExplicitDelegateModel("github-copilot/gpt-6-astra", models.slice(1), models, config).approved).toBe(false);
    expect(getCurrentTier({ model: { provider: "github-copilot", id: "gpt-6-unknown" } })).toBeNull();
  });

  test("Astra automatic tool execution reaches an approved child and retains fail-closed guards", async () => {
    const dir = mkdtempSync(join(tmpdir(), "delegate-astra-execute-"));
    const previousCli = process.env.PI_DELEGATE_CLI;
    const globals = globalThis as Record<string, any>;
    const previousRegistrar = globals.__piclaw_registerAddonConfigApi;
    let configApi: any;
    try {
      const marker = resolve(dir, "launches.txt");
      const script = resolve(dir, "cli.ts");
      writeFileSync(script, `
        import { appendFileSync } from "node:fs";
        if (process.argv.includes("--list-models")) {
          console.log("provider model context max-out thinking images");
          console.log("github-copilot gpt-5.4-mini 272K 128K yes yes");
          process.exit(0);
        }
        await Bun.stdin.text();
        const model = process.argv[process.argv.indexOf("--model") + 1];
        appendFileSync(${JSON.stringify(marker)}, model + "\\n");
        console.log(JSON.stringify({type:"message_end", message:{role:"assistant", provider:"github-copilot", model:"gpt-5.4-mini", content:[{type:"text",text:"ASTRA_AUTO_OK"}], stopReason:"stop"}}));
      `);
      process.env.PI_DELEGATE_CLI = `${process.execPath} ${script}`;
      globals.__piclaw_registerAddonConfigApi = (_addon: string, action: string, handlers: any) => { if (action === "config") configApi = handlers; };
      // A fresh module gives this test an isolated in-memory config and catalog.
      const module = await import(`./delegate.ts?astra-execute=${encodeURIComponent(dir)}`);
      globals.__piclaw_registerAddonConfigApi = previousRegistrar;
      let tool: any;
      module.default({ on() {}, registerTool(value: any) { tool = value; } });
      await configApi.set({ searchable_providers: ["github-copilot"] });
      const ctx = { model: { provider: "github-copilot", id: "gpt-6-astra" }, modelRegistry: { getAvailable() { return []; } } };
      const result = await tool.execute("astra-auto", { prompt: "fixture only", task_category: "quick", tools: "read" }, undefined, undefined, ctx);
      expect(result.content).toEqual([{ type: "text", text: expect.stringContaining("ASTRA_AUTO_OK") }]);
      expect(readFileSync(marker, "utf8")).toBe("github-copilot/gpt-5.4-mini\n");
      await expect(tool.execute("unknown", { prompt: "must not launch" }, undefined, undefined, { ...ctx, model: { provider: "github-copilot", id: "gpt-6-unknown" } })).rejects.toThrow("unclassified current model");
      await configApi.set({ searchable_providers: [] });
      await expect(tool.execute("denied", { prompt: "must not launch" }, undefined, undefined, ctx)).rejects.toThrow("No approved executable");
      expect(readFileSync(marker, "utf8")).toBe("github-copilot/gpt-5.4-mini\n");
    } finally {
      if (previousRegistrar === undefined) delete globals.__piclaw_registerAddonConfigApi;
      else globals.__piclaw_registerAddonConfigApi = previousRegistrar;
      if (previousCli === undefined) delete process.env.PI_DELEGATE_CLI;
      else process.env.PI_DELEGATE_CLI = previousCli;
      rmSync(dir, { recursive: true, force: true });
    }
  });

  test("classifies every current runtime and executable fixture exactly once", () => {
    const runtimeFixture = JSON.parse(readFileSync(resolve(addonDir, "fixtures/runtime-models-42.json"), "utf8")) as {
      current: string;
      models: Array<{ label: string; provider: string; id: string }>;
    };
    const runtimeClassifications = runtimeFixture.models.map((model) => classifyModel(model));
    expect(runtimeClassifications.filter((classification) => classification.status === "unclassified")).toEqual([]);
    const runtimeCandidates = buildModelCandidates(runtimeFixture.models.map((model) => ({ ...model, fullId: model.label })), {
      searchable_providers: [...new Set(runtimeFixture.models.map((model) => model.provider))],
      excluded_providers: [],
      excluded_models: [],
    });
    expect(runtimeCandidates).toHaveLength(runtimeFixture.models.length);
    expect(new Set(runtimeCandidates.map((candidate) => candidate.id)).size).toBe(runtimeCandidates.length);

    const executableModels = parsePiListModelsOutput(readFileSync(resolve(addonDir, "fixtures/cli-models-29.txt"), "utf8"));
    const executableCandidates = buildModelCandidates(executableModels, { searchable_providers: [...new Set(executableModels.map((model) => model.provider))], excluded_providers: [], excluded_models: [] });
    expect(executableModels).toHaveLength(29);
    expect(executableCandidates).toHaveLength(29);
    expect(new Set(executableCandidates.map((candidate) => candidate.id)).size).toBe(29);
    expect(executableCandidates.every((candidate) => candidate.classificationConfidence === "exact-policy")).toBe(true);
  });

  test("ordered policy covers the current named families and provider variants", () => {
    const expected: Record<string, [number, string]> = {
      "openai-codex/gpt-5.5": [3, "gpt-5-5"],
      "openai-codex/gpt-5.6-sol": [3, "gpt-5-6"],
      "github-copilot/claude-sonnet-5": [3, "claude-sonnet-5"],
      "github-copilot/claude-opus-4.8": [5, "claude-opus"],
      "github-copilot/gemini-3.5-flash": [2, "gemini-flash"],
      "github-copilot/mai-code-1-flash-picker": [2, "mai-code-flash"],
      "cerebras/gemma-4-31b": [2, "gemma"],
      "ollama/qwen3.5:35b": [2, "qwen"],
      "azure-openai/gpt-5-4-pro": [4, "gpt-pro"],
      "azure-foundry/deepseek-v4-flash": [2, "deepseek-flash"],
    };
    for (const [id, [tier, policyRule]] of Object.entries(expected)) {
      expect(classifyModel(id)).toMatchObject({ status: "classified", tier, rule: policyRule });
    }
  });

  test("runtime metadata enriches exact executable models and unknown current models fail closed", async () => {
    const runtimeModel = {
      provider: "github-copilot",
      id: "gpt-5.6-sol",
      name: "GPT-5.6 Sol",
      contextWindow: 272_000,
      maxTokens: 128_000,
      reasoning: true,
      input: ["text", "image"],
    };
    expect(runtimeModelToAvailable(runtimeModel)).toMatchObject({ fullId: "github-copilot/gpt-5.6-sol", contextWindow: 272_000, maxOutputTokens: 128_000, reasoning: true, supportsImages: true, catalogSource: "runtime" });
    const snapshot = await captureRuntimeCatalog({ model: runtimeModel, modelRegistry: { async refresh() {}, getAvailable: () => [runtimeModel, runtimeModel] } });
    expect(snapshot.models).toHaveLength(1);
    expect(snapshot.currentModel?.fullId).toBe("github-copilot/gpt-5.6-sol");
    const merged = mergeExecutableRuntimeMetadata([
      { provider: "github-copilot", id: "gpt-5.6-sol", fullId: "github-copilot/gpt-5.6-sol", contextWindow: 200_000, maxOutputTokens: 64_000, reasoning: false, supportsImages: false, catalogSource: "cli" },
      { provider: "ollama", id: "qwen3.5:35b", fullId: "ollama/qwen3.5:35b", contextWindow: 32_000, supportsImages: false, catalogSource: "cli" },
    ], snapshot.models);
    expect(merged[0]).toMatchObject({ contextWindow: 272_000, maxOutputTokens: 128_000, reasoning: true, supportsImages: true, catalogSource: "cli" });
    expect(merged[1]).toMatchObject({ contextWindow: 32_000, supportsImages: false, catalogSource: "cli" });
    expect(getCurrentTier({ model: runtimeModel })).toBe(3);
    expect(getCurrentTier({ model: { provider: "custom", id: "unknown-model" } })).toBeNull();
  });

  test("runtime catalog passively reads one coherent snapshot and preserves last-good data", async () => {
    const freshModel = { provider: "github-copilot", id: "gpt-5.6-sol", input: ["text", "image"] };
    let refreshes = 0;
    let reads = 0;
    const ctx = {
      model: freshModel,
      modelRegistry: {
        async refresh() { refreshes++; },
        getAvailable() {
          reads++;
          return [freshModel];
        },
      },
    };

    const fresh = await captureRuntimeCatalog(ctx);
    expect(refreshes).toBe(0);
    expect(reads).toBe(1);
    expect(fresh.models.map((model) => model.fullId)).toEqual(["github-copilot/gpt-5.6-sol"]);

    const retained = await captureRuntimeCatalog({
      model: freshModel,
      modelRegistry: {
        async refresh() { refreshes++; },
        getAvailable() { throw new Error("registry unavailable"); },
      },
    }, fresh);
    expect(refreshes).toBe(0);
    expect(retained.models).toEqual(fresh.models);
    expect(retained.currentModel?.fullId).toBe("github-copilot/gpt-5.6-sol");
  });

  test("workspace root follows Piclaw configuration and standalone cwd", () => {
    expect(getDelegateWorkspaceRoot({ PICLAW_WORKSPACE: "/workspace" }, "/tmp")).toBe("/workspace");
    expect(getDelegateWorkspaceRoot({}, process.cwd())).toBe(process.cwd());
  });

  test("file inspection accepts only Pi-native raster formats and rejects unsupported binaries", () => {
    const workspaceTempRoot = getDelegateWorkspaceRoot();
    const dir = mkdtempSync(join(workspaceTempRoot, ".delegate-files-"));
    try {
      const fixtures: Array<[string, Buffer, string]> = [
        ["image.png", Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), "PNG"],
        ["image.jpg", Buffer.from([0xff, 0xd8, 0xff, 0xe0]), "JPEG"],
        ["image.gif", Buffer.from("GIF89a", "ascii"), "GIF"],
        ["image.webp", Buffer.from("RIFF0000WEBP", "ascii"), "WebP"],
        ["image.bmp", Buffer.from("BM", "ascii"), "BMP"],
      ];
      for (const [name, content, format] of fixtures) {
        const path = resolve(dir, name);
        writeFileSync(path, content);
        expect(inspectDelegateFile(path)).toEqual({ kind: "image", format });
      }
      const rejected: Array<[string, Buffer, string]> = [
        ["document.pdf", Buffer.from("%PDF-1.7", "ascii"), "PDF"],
        ["drawing.svg", Buffer.from("<svg viewBox=\"0 0 1 1\"></svg>", "utf8"), "SVG"],
        ["archive.zip", Buffer.from([0x50, 0x4b, 0x03, 0x04]), "ZIP archive"],
        ["scan.tiff", Buffer.from([0x49, 0x49, 0x2a, 0x00]), "TIFF"],
      ];
      for (const [name, content, format] of rejected) {
        const path = resolve(dir, name);
        writeFileSync(path, content);
        expect(inspectDelegateFile(path)).toMatchObject({ kind: "unsupported", format });
      }
      const fakePng = resolve(dir, "fake.png");
      writeFileSync(fakePng, "plain text");
      expect(inspectDelegateFile(fakePng)).toMatchObject({ kind: "unsupported", format: "invalid image" });
      const text = resolve(dir, "notes.md");
      writeFileSync(text, "hello\n");
      expect(inspectDelegateFile(text)).toEqual({ kind: "text", format: "text" });
      expect(prepareDelegateFile(text)).toMatchObject({ resolved: text, size: 6, inspection: { kind: "text" } });

      const outsideLink = resolve(dir, "outside.txt");
      symlinkSync("/etc/hosts", outsideLink);
      expect(() => prepareDelegateFile(outsideLink)).toThrow("Path outside workspace");

      const fifo = resolve(dir, "blocking.fifo");
      const mkfifo = Bun.spawnSync(["mkfifo", fifo]);
      expect(mkfifo.exitCode).toBe(0);
      const started = Date.now();
      expect(() => prepareDelegateFile(fifo)).toThrow("regular files");
      expect(Date.now() - started).toBeLessThan(250);
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });

  test("image capability diagnostics distinguish explicit non-support from unknown metadata", () => {
    expect(describeImageCapability({ id: "provider/no-vision", supportsImages: false })).toBe("provider/no-vision (images=no)");
    expect(describeImageCapability({ id: "provider/unknown", supportsImages: null })).toBe("provider/unknown (image capability unknown)");
    expect(describeImageCapability({ id: "provider/vision", supportsImages: true })).toBeNull();
  });

  test("explicit model selection cannot bypass the approved model list", () => {
    const executable = [
      { provider: "openai-codex", id: "gpt-5.4", fullId: "openai-codex/gpt-5.4" },
      { provider: "github-copilot", id: "gpt-5-mini", fullId: "github-copilot/gpt-5-mini" },
      { provider: "github-copilot", id: "gpt-5.4-mini", fullId: "github-copilot/gpt-5.4-mini" },
      { provider: "custom", id: "mystery-9000", fullId: "custom/mystery-9000" },
    ];
    const runtime = [
      ...executable,
      { provider: "github-copilot", id: "gpt-5.6-sol", fullId: "github-copilot/gpt-5.6-sol" },
    ];
    const policy = { searchable_providers: ["github-copilot", "custom"], excluded_providers: [], excluded_models: ["*mini*"] };

    expect(validateExplicitDelegateModel("openai-codex/gpt-5.4", executable, runtime, policy)).toMatchObject({ model: null, approved: false });
    expect(validateExplicitDelegateModel("openai-codex/gpt-5.4", executable, runtime, policy).error).toContain("not in the approved provider list");
    for (const model of ["github-copilot/gpt-5-mini", "github-copilot/gpt-5.4-mini"]) {
      expect(validateExplicitDelegateModel(model, executable, runtime, policy)).toMatchObject({ model: null, approved: false });
      expect(validateExplicitDelegateModel(model, executable, runtime, policy).error).toContain("matches a configured model exclusion");
    }
    expect(validateExplicitDelegateModel("custom/mystery-9000", executable, runtime, { ...policy, excluded_models: [] }).error).toContain("not in the ordered approved-model policy");
    expect(validateExplicitDelegateModel("github-copilot/gpt-5.6-sol", executable, runtime, policy).error).toContain("available in Piclaw but not executable");
    expect(validateExplicitDelegateModel("unknown/missing", executable, runtime, policy).error).toContain("not available in the child Pi CLI catalog");
    expect(validateExplicitDelegateModel("GPT-5.4", executable, runtime, policy).error).toContain("exact approved provider/model ID");

    const approvedPolicy = { searchable_providers: ["openai-codex"], excluded_providers: [], excluded_models: [] };
    expect(validateExplicitDelegateModel("openai-codex/gpt-5.4", executable, runtime, approvedPolicy)).toEqual({ model: executable[0], approved: true, error: null });
    const approvedCandidates = buildModelCandidates(executable, approvedPolicy);
    expect(() => assertApprovedDelegateModelAttempt("openai-codex/gpt-5.4", approvedCandidates)).not.toThrow();
    expect(() => assertApprovedDelegateModelAttempt("github-copilot/gpt-5-mini", approvedCandidates)).toThrow("refused unapproved model attempt");
  });

  test("disclosed provider response models must also be approved", () => {
    const approved = buildModelCandidates([
      { provider: "openrouter", id: "approved-model", fullId: "openrouter/approved-model" },
      { provider: "openrouter", id: "gpt-5.4", fullId: "openrouter/gpt-5.4" },
    ], { searchable_providers: ["openrouter"], excluded_providers: [], excluded_models: [] });
    // The synthetic unclassified request is not itself a launch candidate; the
    // helper is tested independently of pre-spawn enforcement here.
    expect(validateDelegateResponseModel("openrouter/request-alias", "openrouter", null, approved)).toBeNull();
    expect(validateDelegateResponseModel("openrouter/request-alias", "openrouter", "gpt-5.4", approved)).toBeNull();
    expect(validateDelegateResponseModel("openrouter/request-alias", "openrouter", "blocked-model", approved)).toContain("not in the approved Delegate model list");
    expect(validateDelegateResponseModel("openrouter/request-alias", "openrouter", "other/blocked-model", approved)).toContain("other/blocked-model");
  });

  test("judge selection crosses families only when a valid candidate exists", () => {
    const mixed = buildModelCandidates([
      { provider: "github-copilot", id: "gpt-5.4", fullId: "github-copilot/gpt-5.4" },
      { provider: "github-copilot", id: "claude-sonnet-4.6", fullId: "github-copilot/claude-sonnet-4.6" },
    ], { searchable_providers: ["github-copilot"], excluded_providers: [], excluded_models: [] });
    expect(selectModel("judge", 3, "github-copilot/gpt-5.5", mixed)).toBe("github-copilot/claude-sonnet-4.6");
    const sameFamily = mixed.filter((candidate) => candidate.family === "gpt");
    expect(selectModel("judge", 3, "github-copilot/gpt-5.5", sameFamily)).toBe("github-copilot/gpt-5.4");
  });

  test("delegate resolves a runnable CLI command", () => {
    const cli = resolveDelegateCliCommand();
    expect(cli.command.length).toBeGreaterThan(0);
    expect(Array.isArray(cli.argsPrefix)).toBe(true);
    expect(cli.label.length).toBeGreaterThan(0);
  });

  test("delegate runs the Pi CLI through the current runtime instead of node PATH", () => {
    const cliPath = "/opt/pi/dist/cli.js";
    const cli = resolveDelegateCliCommand({
      env: { PATH: "/bin", BUN_INSTALL: "/missing" },
      platform: "linux",
      execPath: "/runtime/bun",
      resolvePackageCli: () => cliPath,
      exists: (path) => path === cliPath,
      isExecutable: () => false,
    });
    expect(cli).toEqual({
      command: "/runtime/bun",
      argsPrefix: [cliPath],
      label: `/runtime/bun ${cliPath}`,
    });
  });

  test("delegate PATH fallback handles Windows shims without POSIX executable bits", () => {
    const cli = resolveDelegateCliCommand({
      env: { PATH: "C:\\Tools;C:\\Windows", PATHEXT: ".CMD;.EXE" },
      platform: "win32",
      execPath: "C:\\Runtime\\bun.exe",
      resolvePackageCli: () => null,
      exists: () => false,
      isExecutable: (path, platform) => platform === "win32" && /pi\.CMD$/i.test(path),
    });
    expect(cli.command).toMatch(/pi\.CMD$/i);
    expect(cli.argsPrefix).toEqual([]);
  });

  test("provider modes partition discovered providers into Search or Exclude", () => {
    const discovered = ["github-copilot", "openai-codex", "ollama"];
    const searchable = new Set(["github-copilot", "openai-codex"]);
    expect(resolveProviderMode("github-copilot", searchable)).toBe("search");
    expect(resolveProviderMode("ollama", searchable)).toBe("exclude");

    const searchPatch = buildProviderModePatch("ollama", "search", discovered, searchable);
    expect(searchPatch).toEqual({
      searchable_providers: ["github-copilot", "openai-codex", "ollama"],
      excluded_providers: [],
    });
    expect(resolveProviderMode("ollama", new Set(searchPatch.searchable_providers))).toBe("search");

    const excludePatch = buildProviderModePatch("openai-codex", "exclude", discovered, searchable);
    expect(excludePatch).toEqual({
      searchable_providers: ["github-copilot"],
      excluded_providers: ["openai-codex", "ollama"],
    });
    const preserveOrder = buildProviderModePatch("github-copilot", "search", ["openai", "github-copilot", "ollama"], new Set(["openai", "github-copilot"]));
    expect(preserveOrder.searchable_providers).toEqual(["openai", "github-copilot"]);
    expect(preserveOrder.excluded_providers).toEqual(["ollama"]);
  });

  test("provider config normalization removes legacy overlaps and summaries preserve preference order", () => {
    expect(normalizeConfig({
      searchable_providers: ["openai", "github-copilot", "ollama"],
      excluded_providers: ["github-copilot"],
      excluded_models: [],
    })).toMatchObject({
      searchable_providers: ["openai", "ollama"],
      excluded_providers: ["github-copilot"],
    });

    const models = [
      { provider: "github-copilot", id: "gpt-5.4", fullId: "github-copilot/gpt-5.4" },
      { provider: "openai", id: "gpt-5.4", fullId: "openai/gpt-5.4" },
      { provider: "ollama", id: "qwen3", fullId: "ollama/qwen3" },
      { provider: "anthropic", id: "claude-sonnet-5", fullId: "anthropic/claude-sonnet-5" },
    ];
    expect(providerSummaries(models, {
      searchable_providers: ["openai", "github-copilot"],
      excluded_providers: [],
      excluded_models: [],
    }).map((provider) => provider.provider)).toEqual(["openai", "github-copilot", "anthropic", "ollama"]);
    expect(providerSummaries(models, {
      searchable_providers: null,
      excluded_providers: [],
      excluded_models: [],
    }).map((provider) => provider.provider)).toEqual(["github-copilot", "anthropic", "openai", "ollama"]);
  });

  test("delegate settings pane uses provider radio modes and exposes model exclusions and refresh", () => {
    const source = readFileSync(resolve(addonDir, "web/index.ts"), "utf8");
    const css = readFileSync(resolve(addonDir, "web/styles.ts"), "utf8");
    expect(source).toContain('class="delegate-settings"');
    expect(source).toContain('for="delegate-provider-filter"');
    expect(source).toContain('aria-describedby="delegate-exclusions-help"');
    expect(source).toContain('style="max-height:180px"');
    expect(source).toContain('style="max-height:190px"');
    expect(source).not.toContain('minWidth: "14.8rem"');
    expect(source).not.toContain('const buttonStyle');
    expect(css).toContain('@layer delegate-settings-fallback');
    expect(source).toContain('from "./styles.ts"');
    expect(source).toContain('role="radiogroup"');
    expect(source).toContain('type="radio"');
    expect(source).not.toContain('type="checkbox"');
    expect(source).toContain('["approved", "exclude"]');
    expect(source).not.toContain('"ignore"');
    expect(source).toContain("buildProviderModePatch");
    expect(source).toContain("const optimisticConfig = { ...config, ...patch }");
    expect(source).toContain("setConfig(optimisticConfig)");
    expect(source).toContain("setConfig(previousConfig)");
    expect(source).toContain("await load(false, true)");
    expect(source).toContain("setConfig(nextConfig)");
    expect(source).toContain("Refresh failed:");
    expect(source).toContain("Filter providers");
    expect(source).toContain("Approved providers");
    expect(source).toContain("No provider is approved by default");
    expect(source).toContain("Approved delegate models");
    expect(source).toContain("whether selected automatically, requested explicitly by an agent, or used as a fallback");
    expect(source).toContain("Excluded model patterns");
    expect(source).toContain("Hard model exclusions");
    expect(source).toContain("explicit model selection");
    expect(source).toContain("Save exclusions");
    expect(source).toContain("Refresh");
    expect(source).toContain("models");
  });

  test("equal-id matches prefer the github-copilot reference provider over other providers", () => {
    // Regression: the @github session (github-copilot/gpt-5.5) delegated to
    // openai-codex/gpt-5.4 which has no usable key. The github-copilot equivalent
    // must rank first when scores tie.
    const models = [
      { provider: "openai-codex", id: "gpt-5.4", fullId: "openai-codex/gpt-5.4" },
      { provider: "github-copilot", id: "gpt-5.4", fullId: "github-copilot/gpt-5.4" },
    ];
    const candidates = buildModelCandidates(models, { searchable_providers: ["github-copilot", "openai-codex"], excluded_providers: null, excluded_models: [] });
    const tier3 = candidates.filter((candidate) => candidate.tier === 3 && candidate.modelId === "gpt-5.4");
    expect(tier3[0]?.id).toBe("github-copilot/gpt-5.4");
  });

  test("automatic selection never climbs above the category target tier", () => {
    const candidates = buildModelCandidates([
      { provider: "github-copilot", id: "claude-sonnet-5", fullId: "github-copilot/claude-sonnet-5" },
      { provider: "github-copilot", id: "claude-opus-4.8", fullId: "github-copilot/claude-opus-4.8" },
    ], { searchable_providers: ["github-copilot"], excluded_providers: [], excluded_models: [] });
    expect(selectModel("quick", 5, "github-copilot/claude-opus-4.8", candidates)).toBeNull();
    expect(buildDelegateModelChain("quick", 5, "github-copilot/claude-opus-4.8", candidates)).toEqual([]);
  });

  test("model chain puts the github-copilot pick first and keeps other providers as fallbacks", () => {
    const models = [
      { provider: "openai-codex", id: "gpt-5.4", fullId: "openai-codex/gpt-5.4" },
      { provider: "github-copilot", id: "gpt-5.4", fullId: "github-copilot/gpt-5.4" },
      { provider: "github-copilot", id: "gpt-5.4-mini", fullId: "github-copilot/gpt-5.4-mini" },
    ];
    const candidates = buildModelCandidates(models, { searchable_providers: ["github-copilot", "openai-codex"], excluded_providers: null, excluded_models: [] });
    const chain = buildDelegateModelChain("code", 3, "github-copilot/gpt-5.5", candidates);
    expect(chain[0]).toBe("github-copilot/gpt-5.4");
    expect(chain).toContain("openai-codex/gpt-5.4");
    expect(new Set(chain).size).toBe(chain.length); // distinct entries
  });

  test("isProviderAuthError matches credential failures", () => {
    expect(isProviderAuthError("No API key for provider: openai-codex")).toBe(true);
    expect(isProviderAuthError("Provider not authenticated")).toBe(true);
    expect(isProviderAuthError("unauthorized")).toBe(true);
    expect(isProviderAuthError("Process exited with code 1")).toBe(false);
    expect(isProviderAuthError("")).toBe(false);
  });

  test("fallback taxonomy retries only setup, auth, and unavailable-model failures", () => {
    const expected = [
      ["No API key for provider openai", "auth", true],
      ["unknown model gpt-x", "model-unavailable", true],
      ["provider foo not found", "provider-setup", true],
      ["rate limit exceeded", "execution", false],
      ["No valid JSON events were emitted", "protocol", false],
      ["timed out after 10s", "timeout", false],
    ] as const;
    for (const [message, kind, retryable] of expected) {
      expect(classifyDelegateFailure(message)).toBe(kind);
      expect(isRetryableDelegateFailure(kind)).toBe(retryable);
    }
  });

  test("parses structured JSON events, usage, model, errors, and bounded output", () => {
    const message = {
      role: "assistant",
      content: [{ type: "text", text: "done" }],
      provider: "github-copilot",
      model: "gpt-5.4-mini",
      responseModel: "routed-mini",
      stopReason: "stop",
      responseId: "response-1",
      timestamp: 1,
      usage: { input: 10, output: 4, cacheRead: 2, cacheWrite: 0, reasoning: 1, totalTokens: 16, cost: { total: 0.001 } },
    };
    const parsed = parseDelegateJsonOutput([
      JSON.stringify({ type: "session", id: "ephemeral-id" }),
      JSON.stringify({ type: "tool_execution_start", toolCallId: "1", toolName: "read", args: {} }),
      JSON.stringify({ type: "tool_execution_end", toolCallId: "1", toolName: "read", isError: false }),
      JSON.stringify({ type: "message_end", message }),
      JSON.stringify({ type: "turn_end", message, toolResults: [] }),
    ].join("\n"));
    expect(parsed).toMatchObject({ text: "done", provider: "github-copilot", model: "gpt-5.4-mini", responseModel: "routed-mini", stopReason: "stop", sessionId: "ephemeral-id", toolCallCount: 1, malformedEventCount: 0 });
    expect(parsed.usage).toMatchObject({ input: 10, output: 4, cacheRead: 2, reasoning: 1, totalTokens: 16, cost: 0.001 });
    expect(delegateProcessFailure(parsed)).toBeNull();

    const partialFailure = { ...parsed, exitCode: 1, stderr: "provider crashed" };
    expect(delegateProcessFailure(partialFailure)).toContain("Process exited with code 1");
    expect(delegateProcessFailure(partialFailure)).toContain("provider crashed");

    const errorMessage = { ...message, responseId: "response-2", content: [], stopReason: "error", errorMessage: "unknown model" };
    const errorResult = parseDelegateJsonOutput(JSON.stringify({ type: "message_end", message: errorMessage }));
    expect(delegateProcessFailure(errorResult)).toContain("unknown model");

    const largeMessage = { ...message, responseId: "response-3", content: [{ type: "text", text: "x".repeat(120_000) }] };
    const largeResult = parseDelegateJsonOutput(JSON.stringify({ type: "message_end", message: largeMessage }));
    expect(largeResult.outputTruncated).toBe(true);
    expect(largeResult.text.length).toBe(100_000);
  });

  test("runs JSON mode with progress and no persistent-session flags", async () => {
    const dir = mkdtempSync(join(tmpdir(), "delegate-runner-"));
    try {
      const script = resolve(dir, "fixture.ts");
      writeFileSync(script, `
        await Bun.stdin.text();
        const usage = { input: 2, output: 1, cacheRead: 0, cacheWrite: 0, totalTokens: 3, cost: { total: 0 } };
        console.log(JSON.stringify({ type: "session", id: "fixture-session" }));
        console.log(JSON.stringify({ type: "tool_execution_start", toolCallId: "1", toolName: "read", args: {} }));
        console.log(JSON.stringify({ type: "tool_execution_end", toolCallId: "1", toolName: "read", isError: false }));
        console.log(JSON.stringify({ type: "message_end", message: { role: "assistant", content: [{ type: "text", text: "fixture response" }], provider: "test", model: "fixture", usage, stopReason: "stop", timestamp: 1 } }));
      `);
      const progress: string[] = [];
      const run = await runDelegateProcess(
        ["--mode", "json", "--no-session"],
        "fixture prompt",
        3_000,
        undefined,
        (event) => progress.push(event.message),
        { command: process.execPath, argsPrefix: [script] },
      );
      expect(run).toMatchObject({ text: "fixture response", exitCode: 0, model: "fixture", stopReason: "stop", toolCallCount: 1 });
      expect(progress).toEqual(["Running read", "Completed read"]);
      const source = readFileSync(resolve(addonDir, "delegate.ts"), "utf8");
      expect(source).toContain('["--mode", "json", "--no-session", "--no-extensions"');
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });

  test("timeout terminates the delegated process tree", async () => {
    const dir = mkdtempSync(join(tmpdir(), "delegate-timeout-"));
    try {
      const marker = resolve(dir, "orphan.txt");
      const childScript = resolve(dir, "child.ts");
      const parentScript = resolve(dir, "parent.ts");
      writeFileSync(childScript, `import { writeFileSync } from "node:fs"; await Bun.sleep(700); writeFileSync(${JSON.stringify(marker)}, "orphan");`);
      writeFileSync(parentScript, `import { spawn } from "node:child_process"; spawn(process.execPath, [${JSON.stringify(childScript)}], { stdio: "ignore" }); setInterval(() => {}, 1000);`);
      await expect(runDelegateProcess([], "", 100, undefined, undefined, { command: process.execPath, argsPrefix: [parentScript] })).rejects.toThrow("timed out");
      await Bun.sleep(900);
      expect(existsSync(marker)).toBe(false);
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });

  test("abort signals terminate the delegated child", async () => {
    const dir = mkdtempSync(join(tmpdir(), "delegate-abort-"));
    try {
      const script = resolve(dir, "wait.ts");
      writeFileSync(script, "setInterval(() => {}, 1000);");
      const controller = new AbortController();
      setTimeout(() => controller.abort(), 50);
      await expect(runDelegateProcess([], "", 3_000, controller.signal, undefined, { command: process.execPath, argsPrefix: [script] })).rejects.toThrow("Aborted");
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });


  test("parallel Delegate calls keep stable ordinals and growing per-session totals until the last exit", async () => {
    const dir = mkdtempSync(join(tmpdir(), "delegate-ordinal-"));
    const previousCli = process.env.PI_DELEGATE_CLI;
    const globals = globalThis as any;
    const previousRegistrar = globals.__piclaw_registerAddonConfigApi;
    const controllers: AbortController[] = [];
    const jobs: Promise<any>[] = [];
    try {
      const cli = join(dir, "cli.ts");
      writeFileSync(cli, `import {existsSync,writeFileSync} from 'node:fs';
        if(process.argv.includes('--list-models')) {
          console.log('provider model context max-out thinking images');
          console.log('github-copilot gpt-6-sol 1M 128K yes yes');
          console.log('github-copilot gpt-6-luna 1M 128K yes yes');
          process.exit(0);
        }
        const prompt=await Bun.stdin.text();
        const key=prompt.match(/fixture-key:([a-z]+)/)[1];
        const model=process.argv[process.argv.indexOf('--model')+1];
        writeFileSync(${JSON.stringify(dir)}+'/'+key+'-'+model.split('/')[1], 'started');
        if(key==='fallback'&&model.endsWith('sol')) {
          console.log(JSON.stringify({type:'message_end',message:{role:'assistant',content:[],stopReason:'error',errorMessage:'No API key for provider'}}));process.exit(1);
        }
        let retried=false;
        while(!existsSync(${JSON.stringify(dir)}+'/'+key+'.finish')) {
          if(!retried&&existsSync(${JSON.stringify(dir)}+'/'+key+'.retry')) {
            console.log(JSON.stringify({type:'auto_retry_start',attempt:1,maxAttempts:3}));
            retried=true;
          }
          await Bun.sleep(5);
        }
        if(key==='error'){console.error('fixture child failure');process.exit(2);}
        console.log(JSON.stringify({type:'message_end',message:{role:'assistant',provider:'github-copilot',model:model.split('/')[1],content:[{type:'text',text:'OK'}],stopReason:'stop'}}));
      `);
      process.env.PI_DELEGATE_CLI = `${process.execPath} ${cli}`;
      let api: any;
      globals.__piclaw_registerAddonConfigApi = (_id: string, action: string, handler: any) => { if (action === 'config') api = handler; };
      const module = await import(`./delegate.ts?ordinal-test=${encodeURIComponent(dir)}`);
      globals.__piclaw_registerAddonConfigApi = previousRegistrar;
      await api.set({searchable_providers:['github-copilot'],excluded_providers:[],excluded_models:[]});
      const makeSession = () => {
        let tool: any;
        module.default({on(){},registerTool(value: any){tool=value;}});
        const working: Array<string|undefined> = [], statuses: Array<string|undefined> = [];
        const ctx = { model:{provider:'github-copilot',id:'gpt-6-sol'},modelRegistry:{getAvailable(){return [];}},ui:{
          setWorkingMessage(text: string|undefined){working.push(text);},
          setStatus(_key: string,text: string|undefined){statuses.push(text);},
        }};
        return {tool,ctx,working,statuses};
      };
      const a=makeSession(), other=makeSession();
      const start = (session: ReturnType<typeof makeSession>, key: string, params: any = {}, brokenUpdate = false) => {
        const updates: string[] = [];
        const controller=new AbortController();controllers.push(controller);
        const done=session.tool.execute(key,{prompt:`fixture-key:${key}`,task_category:'code',tools:'read',timeout_sec:10,...params},controller.signal,(update:any)=>{
          if(brokenUpdate)throw Error('closed UI');updates.push(update.content[0].text);
        },session.ctx).then((value:any)=>({value}), (error:Error)=>({error}));
        jobs.push(done);return {updates,controller,done};
      };
      const started = async (key: string, model='gpt-6-sol') => {
        const deadline=Date.now()+3000;
        while(!existsSync(join(dir,`${key}-${model}`))&&Date.now()<deadline)await Bun.sleep(5);
        expect(existsSync(join(dir,`${key}-${model}`))).toBe(true);
      };
      const first=start(a,'first');await started('first');expect(first.updates.at(-1)).toContain('Delegate (1 of 1) model:');
      const second=start(a,'second');await started('second');
      expect(first.updates.at(-1)).toContain('Delegate (1 of 2) model:');expect(second.updates.at(-1)).toContain('Delegate (2 of 2) model:');
      const third=start(a,'third');await started('third');
      expect(first.updates.at(-1)).toContain('Delegate (1 of 3) model:');
      expect(second.updates.at(-1)).toContain('Delegate (2 of 3) model:');
      expect(third.updates.at(-1)).toContain('Delegate (3 of 3) model:');
      const foreign=start(other,'error');await started('error');
      expect(foreign.updates.at(-1)).toContain('Delegate (1 of 1) model:');expect(a.working.at(-1)).toContain('Delegate (3 of 3):');
      const denied=start(a,'denied',{model:'unapproved/unknown'});expect((await denied.done).error).toBeTruthy();
      expect(a.working.at(-1)).toContain('Delegate (3 of 3):');
      // Out-of-order completion cannot shrink the group or renumber survivors.
      writeFileSync(join(dir,'second.finish'),'');expect((await second.done).value).toBeTruthy();
      const secondUpdateCount=second.updates.length;
      expect(first.updates.at(-1)).toContain('Delegate (1 of 3) model:');
      expect(third.updates.at(-1)).toContain('Delegate (3 of 3) model:');
      // New calls join the existing group; fallback attempts keep the same ordinal.
      const fallback=start(a,'fallback');await started('fallback','gpt-6-luna');
      expect(fallback.updates.some(text=>text.includes('Delegate (4 of 4) model: github-copilot/gpt-6-sol'))).toBe(true);
      expect(fallback.updates.at(-1)).toContain('Delegate (4 of 4) model: github-copilot/gpt-6-luna');
      expect(first.updates.at(-1)).toContain('Delegate (1 of 4) model:');
      expect(third.updates.at(-1)).toContain('Delegate (3 of 4) model:');
      // Actual child retry progress also retains the ordinal and current total.
      writeFileSync(join(dir,'third.retry'),'');
      const retryDeadline=Date.now()+3000;
      while(!third.updates.at(-1)?.includes('Progress: Provider retry')&&Date.now()<retryDeadline)await Bun.sleep(5);
      expect(third.updates.at(-1)).toContain('Delegate (3 of 4) model:');
      expect(third.updates.at(-1)).toContain('Progress: Provider retry 1/3');
      writeFileSync(join(dir,'fallback.finish'),'');expect((await fallback.done).value).toBeTruthy();
      writeFileSync(join(dir,'first.finish'),'');expect((await first.done).value).toBeTruthy();
      expect(third.updates.at(-1)).toContain('Delegate (3 of 4) model:');expect(a.working.at(-1)).toContain('Delegate (3 of 4):');
      expect(a.statuses.at(-1)).toContain('Delegate (3 of 4):');
      expect(a.working).not.toContain(undefined);
      writeFileSync(join(dir,'error.finish'),'');expect((await foreign.done).error).toBeTruthy();
      expect(other.working.at(-1)).toBeUndefined();expect(a.working.at(-1)).toContain('Delegate (3 of 4):');
      const broken=start(a,'broken',{},true);await started('broken');
      expect(third.updates.at(-1)).toContain('Delegate (3 of 5) model:');
      expect(third.updates.at(-1)).toContain('Progress: Provider retry 1/3');
      writeFileSync(join(dir,'broken.finish'),'');expect((await broken.done).value).toBeTruthy();
      expect(a.working.at(-1)).toContain('Delegate (3 of 5):');
      expect(second.updates).toHaveLength(secondUpdateCount);
      third.controller.abort();expect((await third.done).error).toBeTruthy();
      expect(a.working.at(-1)).toBeUndefined();expect(a.statuses.at(-1)).toBeUndefined();
      // Timeout cleans up its group so the next call starts from one again.
      const timeout=start(a,'timeout');await started('timeout');expect((await timeout.done).error?.message).toMatch(/timed out/i);
      expect(timeout.updates.at(-1)).toContain('Delegate (1 of 1) model:');
      expect(a.working.at(-1)).toBeUndefined();
      // Discovery is cached, but the launch command can still fail. Its slot must clear.
      process.env.PI_DELEGATE_CLI = join(dir, 'missing-cli');
      const spawnFailure=start(a,'spawnfailure');expect((await spawnFailure.done).error).toBeTruthy();
      expect(spawnFailure.updates.at(-1)).toContain('Delegate (1 of 1) model:');
      expect(a.working.at(-1)).toBeUndefined();expect(a.statuses.at(-1)).toBeUndefined();
      process.env.PI_DELEGATE_CLI = `${process.execPath} ${cli}`;
      const final=start(a,'final');await started('final');expect(final.updates.at(-1)).toContain('Delegate (1 of 1) model:');
      writeFileSync(join(dir,'final.finish'),'');expect((await final.done).value).toBeTruthy();
      expect(a.working.at(-1)).toBeUndefined();expect(a.statuses.at(-1)).toBeUndefined();
    } finally {
      controllers.forEach(controller=>controller.abort());await Promise.all(jobs);
      globals.__piclaw_registerAddonConfigApi=previousRegistrar;
      if(previousCli===undefined)delete process.env.PI_DELEGATE_CLI;else process.env.PI_DELEGATE_CLI=previousCli;
      invalidateExecutableCatalog();rmSync(dir,{recursive:true,force:true});
    }
  }, 20000);

  test("delegate package stays dependency-light for add-on installs", () => {
    const manifest = JSON.parse(readFileSync(resolve(addonDir, "package.json"), "utf8")) as {
      dependencies?: Record<string, string>;
      peerDependencies?: Record<string, string>;
    };
    expect(manifest.dependencies || {}).toEqual({});
    expect(manifest.peerDependencies || {}).toEqual({});
    const source = readFileSync(resolve(addonDir, "delegate.ts"), "utf8");
    expect(source).not.toContain(`@sinclair/${"typebox"}`);
    expect(source).not.toContain(`@earendil-works/${"pi-coding-agent"}`);
  });
});
