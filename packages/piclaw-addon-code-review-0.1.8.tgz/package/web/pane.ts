import { action, ApiError, requestId, loadReviewProfiles, reviewAuthor, type ReviewProfiles, escapeText as e } from "./api.ts";
const X =
  '<svg viewBox="0 0 16 16" width="12" height="12" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="m4 4 8 8m0-8-8 8"/></svg>';
const pathPrefix = "piclaw://addon/code-review/";
type DraftState = {
  body: string;
  threadId?: string;
  fileId: string;
  range?: { startLine: number; endLine: number };
  side: string;
  draftId?: string;
  version?: number;
  requestId: string;
  pending?: { body: string; requestId: string; expectedVersion?: number };
};
type PendingReply = {
  requestId: string;
  threadId: string;
  draftId?: string;
  draftVersion?: number;
};
const button = (name: string, label: string, title: string, extra = "") =>
  `<button type="button" data-action="${name}" title="${e(title)}" ${extra}>${label}</button>`;
/** One real pane. All mutations use authenticated APIs; no model runs are triggered by mounting. */
export class CodeReviewPane {
  private element: HTMLElement;
  private abort = new AbortController();
  private disposed = false;
  private dirtyCallback: ((value: boolean) => void) | null = null;
  private dirty = false;
  private reviewId: string;
  private review: any;
  private snapshots: any[] = [];
  private snapshotId = "";
  private files: any[] = [];
  private fileId = "";
  private content: any;
  private targets: any[] = [];
  private threads: any[] = [];
  private selected = new Set<string>();
  private detail = new Map<string, any>();
  private projections = new Map<string, any>();
  private fileScroll = new Map<string, number>();
  private selection: {
    startLine: number;
    endLine: number;
    side: string;
  } | null = null;
  private composer: DraftState | null = null;
  private pendingReply: PendingReply | null = null;
  private replyStorageAvailable = true;
  private externallyReconciledThreads = new Set<string>();
  private storageListener = (event: StorageEvent) => {
    if (event.key !== this.replyKey() || this.disposed) return;
    if (event.newValue === null && this.pendingReply && event.oldValue) {
      try {
        const previous = JSON.parse(event.oldValue);
        if (previous.requestId === this.pendingReply.requestId)
          this.externallyReconciledThreads.add(this.pendingReply.threadId);
      } catch { /* A malformed marker grants no authority. */ }
    }
    this.pendingReply = this.readPendingReply();
    this.render();
  };
  private draftTimer: ReturnType<typeof setTimeout> | undefined;
  private previewTimer: ReturnType<typeof setTimeout> | undefined;
  private savedDrafts: any[] = [];
  private savingDraft = false;
  private draftPromise: Promise<void> | null = null;
  private editMessage: any = null;
  private draftEpoch = 0;
  private busy = false;
  private pendingPayload: Record<string, unknown> | null = null;
  private sendPreview: {
    items: Array<{
      threadId: string;
      version: number;
      assignmentEpoch: number;
      anchor: { snapshotFileId: string };
    }>;
  } | null = null;
  private commentThreadVersion: number | undefined;
  private view: "source" | "unified" | "split" = "source";
  private wrap = false;
  private showFiles = false;
  private drawer: "threads" | "send" | null = null;
  private sendIntent: string | null = null;
  private sendThreadId: string | null = null;
  private summary = "";
  private activeTarget: any = null;
  private status = "";
  private fileFilter = "";
  private unresolvedFilesOnly = false;
  private threadFilter = "all";
  private page = 0;
  private loadEpoch = 0;
  private filesEpoch = 0;
  private loading = false;
  private observer: ResizeObserver;
  private moreMenu = false;
  private previewEpoch = 0;
  private previewLoading = false;
  private collapsedThreads = new Set<string>();
  private loadError = "";
  private profiles: ReviewProfiles = {};
  private avatarError = (event: Event) => { const image = event.target; if (image instanceof HTMLImageElement && image.closest(".cr-avatar")) image.remove(); };
  private fileDrafts = new Map<string, DraftState>();
  private sourceSelection = new Map<
    string,
    { startLine: number; endLine: number; side: string }
  >();
  private drawerFocus: HTMLElement | null = null;
  private threadPageAfter = "";
  private hasMoreThreads = false;
  private moreMessages = new Map<string, boolean>();
  private contextExpanded = false;
  private selectedThreadReads = new Map<string, any>();
  constructor(container: HTMLElement, context: any) {
    this.reviewId = String(context.path || "").slice(pathPrefix.length);
    if (!/^[\w-]+$/.test(this.reviewId)) throw Error("Invalid review path.");
    this.pendingReply = this.readPendingReply();
    this.element = container.ownerDocument.createElement("section");
    this.element.className = "cr-pane";
    this.element.dataset.skin = [
      ...container.ownerDocument.querySelectorAll<HTMLLinkElement>(
        "link[href]",
      ),
    ].some((link) => link.href.includes("/static/classic/"))
      ? "classic"
      : "visual";
    this.element.setAttribute("aria-label", "Code Review");
    container.append(this.element);
    this.element.addEventListener("click", this.click);
    this.element.addEventListener("change", this.change);
    this.element.addEventListener("input", this.input);
    this.element.addEventListener("keydown", this.keydown);
    this.element.addEventListener("copy", this.copySource);
    this.element.addEventListener("error", this.avatarError, true);
    this.element.ownerDocument.defaultView?.addEventListener("storage", this.storageListener);
    this.observer = new ResizeObserver((entries) => {
      const width = entries[0]?.contentRect.width ?? 1200;
      this.element.dataset.narrow = String(width < 720);
      this.element.dataset.medium = String(width < 1100);
      if (width < 1100 && this.view === "split") {
        this.view = "unified";
        this.render();
      }
    });
    this.observer.observe(this.element);
    this.render();
    void this.load();
  }
  getContent() {
    return undefined;
  }
  isDirty() {
    return this.dirty;
  }
  onDirtyChange(callback: (value: boolean) => void) {
    this.dirtyCallback = callback;
  }
  focus() {
    if (!this.review) void this.load();
    else this.element.querySelector<HTMLElement>("button,select")?.focus();
  }
  resize() {}
  exportHostTransferState() {
    return {
      reviewId: this.reviewId,
      fileId: this.fileId,
      snapshotId: this.snapshotId,
      view: this.view,
      scroll: this.element.querySelector(".cr-source")?.scrollTop || 0,
    };
  }
  async beforeDetachFromHost() {
    await this.persistDraft();
    if (this.dirty)
      throw Error(
        "Save or explicitly discard the comment draft before detaching.",
      );
  }
  dispose() {
    if (this.disposed) return;
    this.disposed = true;
    this.abort.abort();
    clearTimeout(this.previewTimer);
    clearTimeout(this.draftTimer);
    this.observer.disconnect();
    this.element.removeEventListener("error", this.avatarError, true);
    this.element.ownerDocument.defaultView?.removeEventListener("storage", this.storageListener);
    this.element.remove();
  }
  private setDirty(value: boolean) {
    this.dirty = value;
    this.dirtyCallback?.(value);
  }
  private replyKey() { return `piclaw.code-review.pending-reply.${this.reviewId}`; }
  private readPendingReply(): PendingReply | null {
    try {
      const stored = localStorage.getItem(this.replyKey());
      if (!stored) return null;
      const value = JSON.parse(stored);
      if (!value || typeof value.requestId !== "string" || !/^[\w-]{1,256}$/.test(value.requestId)
          || typeof value.threadId !== "string" || !/^thread_[\w-]{1,256}$/.test(value.threadId))
        throw Error("Invalid pending reply marker.");
      return { requestId: value.requestId, threadId: value.threadId,
        ...(typeof value.draftId === "string" ? { draftId: value.draftId } : {}),
        ...(Number.isSafeInteger(value.draftVersion) ? { draftVersion: value.draftVersion } : {}) };
    } catch {
      this.replyStorageAvailable = false;
      this.status = "Pending reply marker is unreadable. Clear browser site data or restore it before sending another reply.";
      return null;
    }
  }
  private savePendingReply(value: PendingReply) {
    if (!this.replyStorageAvailable)
      throw Error("Browser recovery storage is unavailable; do not send a reply with an untracked acknowledgement.");
    const existing = this.readPendingReply() ?? this.pendingReply;
    if (existing && existing.requestId !== value.requestId)
      throw Error("Reconcile or dismiss the earlier reply before posting another.");
    // Only correlation IDs: this marker is shared by same-origin tabs, never source or reply text.
    try { localStorage.setItem(this.replyKey(), JSON.stringify(value)); }
    catch {
      this.replyStorageAvailable = false;
      throw Error("Browser recovery storage is unavailable; reply was not sent.");
    }
    this.pendingReply = value;
  }
  private clearPendingReply(requestId: string) {
    if (this.readPendingReply()?.requestId === requestId)
      localStorage.removeItem(this.replyKey());
    if (this.pendingReply?.requestId === requestId) this.pendingReply = null;
  }
  private async reconcileReply(pending: PendingReply): Promise<boolean> {
    const receipt = await this.api<{ committed: boolean; messageId?: string }>("replyReceipt", {
      requestId: pending.requestId, threadId: pending.threadId,
    });
    if (!receipt.committed) {
      this.status = "No committed reply found. Keep the saved draft and retry it explicitly if needed.";
      return false;
    }
    this.status = "";
    await this.reloadThreads();
    if (pending.draftId && pending.draftVersion !== undefined)
      try {
        await this.api("deleteDraft", {
          draftId: pending.draftId, expectedVersion: pending.draftVersion, requestId: requestId(),
        });
        this.savedDrafts = await this.api("drafts");
      } catch {
        this.status = "Reply committed. The saved draft changed or could not be removed; inspect it before deleting.";
      }
    if (!this.status) this.status = "Reply committed. No work was queued or replayed.";
    if (this.composer?.requestId === pending.requestId) {
      clearTimeout(this.draftTimer);
      this.fileDrafts.delete(this.composer.fileId);
      this.draftEpoch++;
      this.composer = null;
      this.editMessage = null;
      this.setDirty(false);
    }
    this.clearPendingReply(pending.requestId);
    return true;
  }
  private async api<T = any>(
    name: string,
    payload: Record<string, unknown> = {},
  ) {
    return action<T>(
      name,
      { reviewId: this.reviewId, ...payload },
      this.abort.signal,
    );
  }
  private fail(error: unknown) {
    if (this.disposed || (error as Error)?.name === "AbortError") return;
    this.status = (error as Error)?.message || "Review action failed.";
    this.render();
  }
  private async load() {
    if (this.disposed) return;
    this.loading = true;
    this.pendingReply = this.readPendingReply();
    try {
      [
        this.review,
        this.targets,
        this.snapshots,
        this.threads,
        this.savedDrafts,
        this.profiles,
      ] = await Promise.all([
        this.api("review"),
        this.api("targets"),
        this.api("snapshots"),
        this.api("threads"),
        this.api("drafts"),
        loadReviewProfiles(this.abort.signal),
      ]);
      const target = JSON.parse(this.review.target_json);
      this.activeTarget ??= target;
      this.hasMoreThreads = this.threads.length === 50;
      this.threadPageAfter = this.threads.at(-1)?.id || "";
      this.snapshotId ||= this.snapshots[0]?.id || "";
      this.loadError = "";
      await this.loadFiles();
    } catch (error) {
      this.loadError = (error as Error).message;
      this.fail(error);
    } finally {
      this.loading = false;
      this.render();
    }
  }
  private async loadFiles() {
    const epoch = ++this.filesEpoch;
    // Invalidate any older file/projection request as soon as the snapshot changes.
    ++this.loadEpoch;
    const snapshotId = this.snapshotId;
    if (!snapshotId) return;
    const files = await this.api<any[]>("files", { snapshotId });
    if (epoch !== this.filesEpoch || snapshotId !== this.snapshotId || this.disposed) return;
    this.files = files;
    if (!files.some((f) => f.id === this.fileId))
      this.fileId = files[0]?.id || "";
    this.page = 0;
    await this.loadContent();
  }
  private async loadContent() {
    const epoch = ++this.loadEpoch;
    if (!this.fileId) {
      this.content = null;
      return;
    }
    const fileId = this.fileId;
    const response = await this.api("file", {
      fileId,
      offset: this.page * 300,
      limit: 300,
    });
    if (epoch !== this.loadEpoch || this.disposed) return;
    this.content = response;
    this.view =
      response.change_kind === "source"
        ? "source"
        : this.view === "source"
          ? "unified"
          : this.view;
    this.projections.clear();
    for (const thread of this.threads) {
      try {
        const projection = await this.api("projection", {
          threadId: thread.id,
          fileId,
        });
        if (epoch !== this.loadEpoch) return;
        this.projections.set(thread.id, projection);
      } catch {
        /* Other-file or unavailable projection stays out of this view. */
      }
    }
    // Only expand open discussions mounted on this bounded source page.
    const visible = this.threadRows().filter((thread) => {
      if (thread.state !== "open" || this.collapsedThreads.has(thread.id) || this.detail.has(thread.id)) return false;
      if (thread.anchor.scope === "file") return true;
      const projection = this.projections.get(thread.id);
      const side = projection?.side || thread.anchor.side;
      const line = projection?.endLine ?? thread.anchor.endLine;
      return response.diff
        ? response.diff.some((row: any) => (side === "old" ? row.oldLine : row.newLine) === line)
        : response.new.lines.some((row: any) => row.number === line);
    });
    for (let i = 0; i < visible.length; i += 4) {
      await Promise.all(visible.slice(i, i + 4).map(async (thread) => {
        const data = await this.api("thread", { threadId: thread.id });
        if (epoch !== this.loadEpoch || fileId !== this.fileId || this.disposed) return;
        this.detail.set(thread.id, data);
        this.moreMessages.set(thread.id, data.messages.length === 100);
        this.selectedThreadReads.set(thread.id, data);
      }));
      if (epoch !== this.loadEpoch || fileId !== this.fileId || this.disposed) return;
    }
    this.render();
  }
  private async reloadThreads() {
    this.threads = await this.api("threads");
    this.hasMoreThreads = this.threads.length === 50;
    this.threadPageAfter = this.threads.at(-1)?.id || "";
    for (const thread of this.threads) {
      if (this.detail.has(thread.id)) {
        const data = await this.api("thread", { threadId: thread.id });
        this.detail.set(thread.id, data);
        this.moreMessages.set(thread.id, data.messages.length === 100);
        this.selectedThreadReads.set(thread.id, data);
      }
    }
    for (const id of this.selected)
      if (!this.threads.some((t) => t.id === id && t.state === "open"))
        this.selected.delete(id);
    const snapshotId = this.snapshotId;
    const epoch = this.filesEpoch;
    const files = await this.api<any[]>("files", { snapshotId });
    if (epoch !== this.filesEpoch || snapshotId !== this.snapshotId || this.disposed) return;
    this.files = files;
    await this.loadContent();
  }
  private async openThread(threadId: string) {
    const data = await this.api("thread", { threadId });
    this.detail.set(threadId, data);
    this.moreMessages.set(threadId, data.messages.length === 100);
    this.selectedThreadReads.set(threadId, data);
    this.render();
  }
  private relevant(thread: any) {
    const anchor = thread.anchor;
    const p = this.projections.get(thread.id);
    return (
      anchor.snapshotFileId === this.fileId ||
      p?.status === "exact" ||
      p?.status === "moved"
    );
  }
  private threadRows() {
    return this.threads.filter(
      (t) => this.relevant(t) && t.state !== "deleted",
    );
  }
  private hasTargetMismatch() {
    return [...this.selected].some((id) => {
      const thread = this.threads.find((t) => t.id === id);
      return !thread || thread.target.chatId !== this.activeTarget?.chatId ||
        thread.target.incarnation !== this.activeTarget?.incarnation;
    });
  }
  private deliveryLabel(thread: any) {
    const summary = thread.summary;
    return summary?.deliveryState === "prepared" || summary?.deliveryState === "attempting" ? "Queued"
      : summary?.deliveryState === "unknown" ? "Delivery uncertain"
      : summary?.deliveryState === "rejected" ? "Failed"
      : summary?.unsent ? "Unsent"
      : summary?.deliveryState === "accepted" ? "Queued" : "Unsent";
  }
  private deliveryHtml(thread: any) {
    const work = thread.summary?.workState;
    return `<small class="cr-delivery" title="Delivery is separate from concern resolution.">${e(this.deliveryLabel(thread))}${work && work !== "not_started" ? ` · ${e(work.replaceAll("_", " "))}` : ""}</small>${thread.summary?.deliveryState === 'unknown' && thread.summary.dispatchId ? button('reconcile','Check delivery','Record a delivery outcome only after checking evidence; never resend automatically.',`data-dispatch="${e(thread.summary.dispatchId)}"`) : ''}`;
  }
  private threadLocation(thread: any) {
    const anchor = thread.anchor;
    return anchor.scope === "file" ? "Whole file" : `${anchor.side} ${anchor.startLine === anchor.endLine ? `line ${anchor.startLine}` : `lines ${anchor.startLine}–${anchor.endLine}`}`;
  }
  private evidenceHtml(message: any) {
    if (!message.resolution || message.deleted) return "";
    const reference = (value: string) => {
      try {
        const url = new URL(value);
        if (["https:", "http:"].includes(url.protocol))
          return `<a href="${e(url.href)}" target="_blank" rel="noopener noreferrer" title="Open resolution evidence">${e(value)}</a>`;
      } catch { /* Local references remain text, never authority or executable links. */ }
      return `<code>${e(value)}</code>`;
    };
    return `<section class="cr-evidence" aria-label="Resolution evidence"><strong>Resolution evidence</strong><small>Addressed guidance v${e(message.resolution.addressedVersion)}</small><ul>${message.resolution.evidence.map((value: string) => `<li>${reference(value)}</li>`).join("")}</ul></section>`;
  }
  private authorHtml(kind: unknown, id: unknown): string {
    const author = reviewAuthor(kind, id, this.profiles, this.targets);
    const initial = Array.from(author.name)[0]?.toUpperCase() || '?';
    return `<span class="cr-author"><span class="cr-avatar" aria-hidden="true"><span>${e(initial)}</span>${author.avatar ? `<img src="${e(author.avatar)}" alt="" referrerpolicy="no-referrer">` : ''}</span><strong class="cr-author-name">${e(author.name)}</strong></span>`;
  }
  private syncUnsent() {
    this.selected = new Set(this.threads.filter(t => t.state === 'open' && t.summary?.unsent && !t.summary?.outstanding
      && t.target.chatId === this.activeTarget?.chatId && t.target.incarnation === this.activeTarget?.incarnation).map(t => t.id));
  }
  private threadHtml(thread: any) {
    const data = this.detail.get(thread.id),
      anchor = thread.anchor,
      p = this.projections.get(thread.id);
    const first =
      thread.summary?.body ?? data?.messages?.find((m: any) => m.body)?.body ?? "Comment deleted";
    const location =
      anchor.scope === "file"
        ? "Whole file"
        : `${p?.side || anchor.side} lines ${p?.startLine ?? anchor.startLine}–${p?.endLine ?? anchor.endLine}`;
    return `<article class="cr-thread" id="cr-${thread.id}"><header><strong>${e(thread.state)}</strong><span class="cr-muted">${e(location)}${p?.status === "moved" ? " · moved since review" : ""}</span>${button("expand", "Discussion", data ? "Collapse this discussion." : "Load public messages and replies.", `data-thread="${thread.id}" aria-expanded="${Boolean(data)}"`)}</header>${data ? `<div class="cr-messages">${data.messages.map((m: any) => `<div class="cr-message"><div class="cr-message-meta">${this.authorHtml(m.author_kind, m.author_id)} <small>${e(m.updated_at)}${m.version > 1 ? " · edited" : ""}</small>${m.author_kind === "operator" && !m.deleted ? `<details class="cr-message-options"><summary title="Edit or delete your message; neither sends agent work." aria-label="Message actions">⋯</summary><div class="cr-message-actions">${button("edit", "Edit", "Edit your message; this does not send updated instructions.", `data-message="${m.id}" data-thread="${thread.id}"`)}${button("delete-message", "Delete", "Delete this message body while retaining its replies.", `data-message="${m.id}" data-thread="${thread.id}" data-settings-button="danger"`)}</div></details>` : ""}</div><div class="cr-message-body">${m.html ?? e(m.body ?? "Comment deleted")}</div></div>`).join("")}</div>${this.moreMessages.get(thread.id) ? button("more-messages", "More replies", "Load the next bounded page of this thread.", `data-thread="${thread.id}"`) : ""}<footer>${button("reply", "Reply", thread.state === "resolved" ? "Reopen this thread before replying." : "Write a reply without starting agent work.", `data-thread="${thread.id}" ${thread.state === "resolved" ? "disabled" : ""}`)}${button(thread.state === "resolved" ? "reopen" : "resolve", thread.state === "resolved" ? "Reopen" : "Resolve", "Change concern state explicitly; queued work is not cancelled.", `data-thread="${thread.id}"`)}${button("send-thread", "Send thread", "Preview this concern before sending to its bound local agent.", `data-thread="${thread.id}" ${thread.state !== "open" ? "disabled" : ""}`)}${button("reassign", "Reassign", "Bind this thread explicitly to the selected toolbar target; old work is not cancelled.", `data-thread="${thread.id}"`)}${button("delete-thread", "Delete thread", "Confirm removing this discussion; already delivered work cannot be recalled.", `data-thread="${thread.id}" data-settings-button="danger"`)}</footer>` : `<div class="cr-message cr-muted">${e(first)}</div>`}</article>`;
  }
  private codeLine(
    side: string,
    line: number | null,
    kind: string,
    text: string,
    oldLine?: number | null,
  ) {
    if (line === null) return '<div class="cr-line cr-blank"></div>';
    const lines =
      side === "old" ? this.content.old.lines : this.content.new.lines;
    const token = lines.find((x: any) => x.number === line);
    const html = token?.text === text ? token.html : e(text);
    const sel =
      this.selection?.side === side &&
      line >= this.selection.startLine &&
      line <= this.selection.endLine;
    const unified = oldLine !== undefined;
    return `<div class="cr-line ${unified ? "cr-diff-line" : ""} ${kind} ${sel ? "selected" : ""}" data-line="${line}" data-side="${side}"><button data-action="line-comment" data-side="${side}" data-line="${line}" title="Add guidance on ${side} line ${line}. No work starts until sent." aria-label="Comment on line ${line}" data-settings-button="unstyled">+</button>${unified ? `<span class="cr-old-line" title="Old-side line ${oldLine ?? "absent"}">${oldLine ?? ""}</span>` : ""}<button data-action="select-line" data-line="${line}" data-side="${side}" aria-label="Select ${side} line ${line}" title="Select this line; Shift-click or select another line to extend the range." data-settings-button="unstyled">${unified && kind === "deleted" ? "" : line}</button><span aria-hidden="true">${kind === "added" ? "+" : kind === "deleted" ? "−" : ""}</span><code>${html}</code></div>`;
  }
  private codeHtml() {
    if (!this.content)
      return '<p class="cr-empty">No source is available for this snapshot.</p>';
    const c = this.content,
      rows =
        c.diff ||
        c.new.lines.map((line: any) => ({
          kind: "context",
          oldLine: null,
          newLine: line.number,
          text: line.text,
        }));
    const mounted = new Set<string>();
    let html = "";
    if (!rows.length || (c.diff && rows.every((row: any) => row.kind === "context")))
      return '<p class="cr-empty">No changes in this comparison.</p>' +
        this.threadRows().filter((thread) => thread.anchor.scope === "file")
          .map((thread) => this.threadHtml(thread)).join("");
    const visible = new Set<number>();
    if (!this.contextExpanded && this.view !== "source") {
      rows.forEach((r: any, i: number) => {
        if (r.kind !== "context")
          for (
            let j = Math.max(0, i - 3);
            j <= Math.min(rows.length - 1, i + 3);
            j++
          )
            visible.add(j);
      });
      for (const t of this.threadRows()) {
        const p = this.projections.get(t.id),
          line = p?.endLine ?? t.anchor.endLine;
        const index = rows.findIndex(
          (r: any) => r.oldLine === line || r.newLine === line,
        );
        if (index >= 0)
          for (
            let j = Math.max(0, index - 2);
            j <= Math.min(rows.length - 1, index + 2);
            j++
          )
            visible.add(j);
      }
    }
    let skipped = 0;
    const flush = () => {
      if (skipped) {
        html += button(
          "expand-context",
          `Show ${skipped} unchanged lines`,
          "Expand bounded context from the current immutable snapshots.",
          'class="cr-expand" data-settings-button="unstyled"',
        );
        skipped = 0;
      }
    };
    for (const [index, row] of rows.entries()) {
      if (
        this.view !== "source" &&
        !this.contextExpanded &&
        !visible.has(index)
      ) {
        skipped++;
        continue;
      }
      flush();
      const side =
        this.view === "source"
          ? "source"
          : row.kind === "deleted"
            ? "old"
            : "new";
      if (this.view === "split")
        html += `<div class="cr-pair">${this.codeLine("old", row.oldLine, row.kind, row.text)}${this.codeLine("new", row.newLine, row.kind, row.text)}</div>`;
      else
        html += this.codeLine(
          side,
          row.kind === "deleted" ? row.oldLine : row.newLine,
          row.kind,
          row.text,
          this.view === "unified" ? row.oldLine : undefined,
        );
      for (const thread of this.threadRows()) {
        if (mounted.has(thread.id)) continue;
        const anchor = thread.anchor,
          p = this.projections.get(thread.id),
          end = p?.endLine ?? anchor.endLine,
          ts = p?.side || anchor.side;
        if (
          anchor.scope === "range" &&
          end === (ts === "old" ? row.oldLine : row.newLine)
        ) {
          html += this.threadHtml(thread);
          mounted.add(thread.id);
        }
      }
    }
    flush();
    for (const thread of this.threadRows())
      if (!mounted.has(thread.id) && thread.anchor.scope === "file")
        html += this.threadHtml(thread);
    return html;
  }
  private render() {
    if (this.disposed) return;
    if (this.drawer !== "send") this.syncUnsent();
    const active = this.element.ownerDocument.activeElement as HTMLInputElement;
    const focusId =
      active?.closest(".cr-pane") === this.element ? active.id : "";
    const selectionStart = active?.selectionStart,
      selectionEnd = active?.selectionEnd;
    const previousScroll =
      this.element.querySelector(".cr-source")?.scrollTop ||
      this.fileScroll.get(this.fileId) ||
      0;
    if (!this.review) {
      this.element.innerHTML = `<div class="cr-empty">${e(this.loadError || "Loading review…")}${this.loadError ? button("load", "Retry", "Retry loading this review without sending work.") : ""}</div>`;
      return;
    }
    const c = this.content,
      path = c?.new_path || c?.old_path || this.review.focus_path,
      snapshot = this.snapshots.find((s) => s.id === this.snapshotId);
    const fileRows = this.files.filter((f) =>
      (f.new_path || f.old_path || "")
        .toLowerCase()
        .includes(this.fileFilter.toLowerCase()) && (!this.unresolvedFilesOnly || f.stats?.openThreads > 0),
    );
    this.element.innerHTML = `<div class="cr-toolbar">${button("files", "Files", "Show the files in this review.")}<select id="cr-snapshot" title="Choose an immutable saved-source or Git comparison snapshot.">${this.snapshots.map((s) => `<option value="${s.id}" ${s.id === this.snapshotId ? "selected" : ""} title="${e(s.mode + " captured " + s.captured_at)}">${e(s.mode + " · " + s.captured_at.slice(11, 19))}</option>`).join("")}</select><span class="cr-grow"></span><select id="cr-target" title="Choose a local target. Existing thread assignments require explicit reassignment.">${this.targets.map((t) => `<option value="${e(t.chatJid)}" ${t.chatJid === this.activeTarget?.chatId ? "selected" : ""}>${e(t.label)}</option>`).join("")}</select>${button("threads", `Threads (${this.threads.length})`, "Browse saved open, resolved and outdated concerns.")}${button("send", `Send to agent${this.selected.size ? " (" + this.selected.size + ")" : ""}`, this.selected.size ? "Send new or updated discussions to this agent." : "No unsent discussions for this agent.", `data-settings-button="primary" ${!this.selected.size ? "disabled" : ""}`)}<div class="cr-options">${button("options", "⋯", "View and capture options.", 'data-settings-button="icon" aria-label="View options"')}${this.moreMenu ? `<div class="cr-menu">${button("refresh", "Refresh saved source", "Capture the newest saved bytes; comments retain original anchors.")}${button("wrap", "Wrap long lines", "Toggle visual wrapping without changing saved source.")}${button("layout", this.view === "split" ? "Unified diff" : "Split diff", "Switch diff layout; unavailable in source mode.", this.view === "source" ? "disabled" : "")}${button("staged", "Staged changes", "Capture HEAD to index without staging or writing source.")}${button("unstaged", "Working changes", "Capture index to saved worktree, including untracked text files.")}${button("history", "Recent commits", "Select a bounded file-history commit to review.")}${button("add-file", "Add file", "Add another saved workspace file to this review explicitly.")}${button("drafts", `Drafts (${this.savedDrafts.length})`, "Restore an acknowledged private comment draft.")}</div>` : ""}</div></div>
  ${this.status ? `<div class="cr-status" role="status">${e(this.status)}${button("dismiss", X, "Dismiss status.", 'data-settings-button="icon" aria-label="Dismiss status"')}</div>` : ""}
  ${this.pendingReply ? `<div class="cr-pending-reply" role="status">Reply acknowledgement uncertain. Check the saved receipt before sending another reply. ${button("reconcile-reply", "Reconcile reply", "Read the authorised reply receipt; never resend automatically.")}${button("dismiss-reply", "Dismiss", "Forget only this browser's pending reply marker; preserve saved drafts and replies.")}</div>` : ""}
  ${!this.replyStorageAvailable ? `<div class="cr-recovery-error" role="alert">Pending reply marker is unreadable. No reply was sent. ${button("clear-recovery", "Clear browser marker", "Forget only the unreadable local marker after confirming; saved drafts and published replies remain.")}</div>` : ""}
  <div class="cr-body"><nav class="cr-files ${this.showFiles ? "open" : ""}" ${this.files.length < 2 && !this.showFiles ? "hidden" : ""}><header>Files ${button("files", X, "Close the file list.", 'data-settings-button="icon" aria-label="Close file list"')}</header><input id="cr-filter" value="${e(this.fileFilter)}" placeholder="Filter paths" title="Filter paths in this snapshot without deleting anything.">${fileRows.map((f) => button("file", `<span>${e(f.new_path || f.old_path)}</span><small>${e(f.change_kind)}</small>`, "View this saved file without sending its comments.", `data-file="${f.id}" class="${f.id === this.fileId ? "active" : ""}" data-settings-button="unstyled"`)).join("")}</nav>
  <main class="cr-main"><header class="cr-file-header"><strong>${e(path)}</strong><span class="cr-grow cr-muted">${e(snapshot?.mode || "")} · ${e((c?.new_hash || c?.old_hash || "").slice(0, 10))} · ${e(c?.new?.language || "text")}${c?.new && !c.new.highlighted ? " (plain)" : ""}</span>${c?.currentSource && c.currentSource.status !== "unchanged" ? `<span class="cr-current-source" role="status" title="Saved review content remains unchanged; current source was checked separately.">Current saved file: ${e(c.currentSource.status)}</span>` : ""}${button("file-comment", "Comment on file", "Create guidance about the whole file without selecting lines.")}</header><div class="cr-source ${this.wrap ? "wrap" : ""}" tabindex="0">${this.codeHtml()}</div>
  <div class="cr-pagination">${button("previous", "Previous lines", "Load the previous bounded source/diff page.", this.page === 0 ? "disabled" : "")}<span>${this.page * 300 + 1}–${this.page * 300 + (c?.diff?.length ?? c?.new?.lines.length ?? 0)}</span>${button("next", "Next lines", "Load the next bounded source/diff page.", (this.page + 1) * 300 >= (c?.diffTotal || Math.max(c?.old.total || 0, c?.new.total || 0)) ? "disabled" : "")}</div>
  ${this.selection ? `<div class="cr-selection">${e(this.selection.side)} lines ${this.selection.startLine}–${this.selection.endLine}${button("range-comment", "Add comment", "Comment on the selected saved range.")}${button("clear-range", "Clear", "Clear selection only; comments remain.")}${button("reanchor", "Re-anchor thread", "Explicitly map a chosen thread to this selected range.")}</div>` : ""}
  ${this.composer ? `<section class="cr-composer"><strong>${this.editMessage ? "Edit message" : this.composer.threadId ? "Reply" : this.composer.range ? "Range comment" : "File comment"}</strong><textarea id="cr-body" title="Write public guidance; posting does not send it to an agent." placeholder="What should change or be checked?">${e(this.composer.body)}</textarea><footer><small>${this.dirty ? "Draft not yet saved" : "Draft saved"}</small><span class="cr-grow"></span>${button("cancel", "Cancel", "Discard this unpublished text with confirmation if needed.")}${button("post", this.editMessage ? "Save edit" : "Post comment", "Save guidance without queueing agent work.", 'data-settings-button="primary"')}</footer></section>` : ""}</main></div>
  ${
    this.drawer
      ? `<div class="cr-backdrop" data-action="close-drawer"></div><aside class="cr-drawer" role="dialog" aria-modal="true" aria-label="Review threads"><header><strong>${this.drawer === "send" ? "Send review" : "Threads"}</strong>${button("close-drawer", X, "Close without sending; keep the selection.", 'data-settings-button="icon" aria-label="Close review drawer"')}</header><select id="cr-thread-filter" title="Filter concerns without changing their state.">${["all", "open", "resolved", "outdated"].map((v) => `<option value="${v}" ${v === this.threadFilter ? "selected" : ""}>${v[0].toUpperCase()+v.slice(1)}</option>`).join("")}</select>${this.threads
          .filter(
            (t) =>
              this.threadFilter === "all" ||
              this.threadFilter === t.state ||
              (this.threadFilter === "pending" && t.state === "open" && t.summary?.unsent) ||
              (this.threadFilter === "outdated" && !this.relevant(t)),
          )
          .map(
            (t) =>
              `<div class="cr-drawer-item" data-thread-id="${t.id}"><strong>${e(t.state)}</strong><small>${e(t.id.slice(-8))} · ${e(t.anchor.side)} ${t.anchor.startLine ?? "file"}${this.projections.get(t.id)?.status === "missing" ? " · outdated (not mapped)" : this.projections.get(t.id)?.status === "ambiguous" ? " · ambiguous (not mapped)" : ""}</small>${button("jump", "Open discussion", "Reveal original source and public messages.", `data-thread="${t.id}"`)}</div>`,
          )
          .join(
            "",
          )}${this.hasMoreThreads ? button("more-threads", "More threads", "Load the next bounded page of review concerns.") : ""}${this.drawer === "send" ? `<section class="cr-send-preview" aria-label="Updated discussions and saved source versions">${this.sendPreview ? `<strong>Updated discussions (${this.sendPreview.items.length})</strong><ol>${this.sendPreview.items.map((item) => `<li data-preview-thread="${e(item.threadId)}"><code title="Thread ID">${e(item.threadId)}</code><small>Guidance v${e(item.version)} · assignment ${e(item.assignmentEpoch)}</small><small>Snapshot file <code title="Saved snapshot file ID">${e(item.anchor.snapshotFileId)}</code></small></li>`).join("")}</ol>` : `<p>${this.previewLoading ? "Updating the selection…" : "No unsent discussions for this agent."}</p>`}</section><textarea id="cr-summary" title="Optional overall instruction sent with selected thread references." placeholder="Overall guidance (optional)">${e(this.summary)}</textarea><p>Queue to ${e(this.activeTarget?.label)} behind current work. No interruption.</p>${!this.sendPreview && !this.previewLoading && this.selected.size && !this.hasTargetMismatch() ? button("refresh-send-preview", "Retry preview", "Retry checking saved guidance without sending work.") : ""}${button("confirm-send", "Send to agent", "Queue one review; replies and resolutions remain per thread.", `data-settings-button="primary" ${!this.sendPreview || !this.selected.size ? "disabled" : ""}`)}` : ""}</aside>`
      : ""
  }`;
    const toolbar = this.element.querySelector(".cr-toolbar")!;
    this.element.querySelector("#cr-thread-filter")?.insertAdjacentHTML("beforeend", `<option value="pending" ${this.threadFilter === "pending" ? "selected" : ""} title="Open concerns not yet sent to their current target.">Unsent</option>`);
    const modes = [["source", "Saved file"], ["unstaged", "Unstaged changes"], ["staged", "Staged changes"], ["commit", "Commit comparison"]];
    toolbar.insertAdjacentHTML("afterbegin", `<select id="cr-source-mode" aria-label="Review source" title="Choose saved source or a Git comparison; source remains read-only.">${modes.map(([value, label]) => `<option value="${value}" ${snapshot?.mode === value ? "selected" : ""} ${value !== "source" && this.review.gitAvailable === false ? "disabled" : ""} title="${e(value !== "source" && this.review.gitAvailable === false ? "Git is unavailable for this file." : label)}">${label}</option>`).join("")}</select>`);
    const snapshotPicker = this.element.querySelector<HTMLSelectElement>("#cr-snapshot");
    this.element.querySelector<HTMLSelectElement>("#cr-source-mode")!.disabled = this.busy;
    if (snapshotPicker) {
      snapshotPicker.setAttribute("aria-label", "Saved snapshot");
      const history = this.element.ownerDocument.createElement("details");
      history.className = "cr-snapshot-history";
      history.innerHTML = '<summary title="Browse immutable saved versions without changing source.">Saved versions</summary>';
      this.element.querySelector(".cr-file-header")?.append(history);
      history.append(snapshotPicker);
    }
    for (const name of ["staged", "unstaged", "history"])
      this.element.querySelector(`.cr-menu [data-action=${name}]`)?.remove();
    const targetPicker = this.element.querySelector<HTMLSelectElement>("#cr-target")!;
    targetPicker.setAttribute("aria-label", "Agent target");
    const targetLabel = this.element.ownerDocument.createElement("label");
    targetLabel.className = "cr-target-label";
    targetLabel.textContent = "To ";
    targetPicker.before(targetLabel);
    targetLabel.append(targetPicker);
    this.element.querySelector("#cr-filter")?.insertAdjacentHTML("afterend", `<label class="cr-unresolved-filter"><input id="cr-unresolved-files" type="checkbox" title="Show only files with open concerns; does not change their state." ${this.unresolvedFilesOnly ? "checked" : ""}>Open concerns only</label>`);
    for (const file of fileRows) {
      const row = this.element.querySelector(`[data-action=file][data-file="${file.id}"]`);
      if (row && file.stats) row.insertAdjacentHTML("beforeend", `<span class="cr-file-stats"><small>${e(file.stats.openThreads)} open</small><span class="cr-file-add">+${e(file.stats.added ?? "?")}</span><span class="cr-file-del">−${e(file.stats.deleted ?? "?")}</span></span>`);
    }
    const fileHeader = this.element.querySelector(".cr-file-header");
    const identity = fileHeader?.querySelector(".cr-grow");
    if (identity) identity.textContent = `${snapshot?.mode === "source" ? "Saved source" : snapshot?.mode === "unstaged" ? "Index → saved worktree" : snapshot?.mode === "staged" ? "HEAD → index" : `${snapshot?.base?.slice(0, 8) ?? "parent"} → ${snapshot?.head?.slice(0, 8) ?? "commit"}`} · ${c?.new?.total ?? c?.old?.total ?? 0} lines · ${(c?.new_hash || c?.old_hash || "").slice(0, 10)}`;
    if (fileHeader) fileHeader.insertAdjacentHTML("beforeend", `<small class="cr-file-kind" title="Highlighting is presentation only.">${e(c?.change_kind === "source" ? "Saved file" : c?.change_kind ?? "")} · ${e(c?.new?.language || c?.old?.language || "text")}${c?.new && !c.new.highlighted ? " (plain)" : ""}</small>`);
    const drawerHeader = this.element.querySelector(".cr-drawer > header");
    const threadFilter = this.element.querySelector<HTMLSelectElement>("#cr-thread-filter");
    if (threadFilter) {
      const filters = this.element.ownerDocument.createElement("details");
      filters.className = "cr-thread-filters";
      filters.innerHTML = '<summary title="Filter discussions without changing or sending them.">Filter discussions</summary>';
      threadFilter.before(filters);
      filters.append(threadFilter);
      filters.hidden = this.drawer === "send";
    }
    drawerHeader?.insertAdjacentHTML("afterend", `<p class="cr-drawer-intro">${this.drawer === "send" ? "New or updated discussions for this agent will be queued together." : "New or updated discussions are included automatically when you send."}</p>`);
    const queueHelp = this.element.querySelector(".cr-drawer > textarea + p");
    if (queueHelp) {
      queueHelp.className = "cr-queue-help";
      queueHelp.insertAdjacentHTML("afterbegin", `<strong>To ${e(this.activeTarget?.label)} · ${this.selected.size} selected</strong>`);
    }
    this.element.querySelector("#cr-summary")?.insertAdjacentHTML("beforebegin", '<label class="cr-summary-label" for="cr-summary">Overall guidance <small>(optional)</small></label>');
    const preview = this.element.querySelector(".cr-send-preview");
    if (preview && this.sendPreview) {
      const details = this.element.ownerDocument.createElement("details");
      details.className = "cr-preview-details";
      details.innerHTML = '<summary title="Inspect exact guidance versions and saved snapshot IDs before sending.">Versions and saved-source references</summary>';
      preview.before(details);
      details.append(preview);
    }
    if (this.drawer === "send" && this.hasTargetMismatch()) {
      const warning = this.element.ownerDocument.createElement("p");
      warning.className = "cr-target-warning";
      warning.setAttribute("role", "status");
      warning.textContent = "Selection has a different bound target. Reassign explicitly or send separate batches.";
      this.element.querySelector(".cr-drawer > header")?.after(warning);
      const confirm = this.element.querySelector<HTMLButtonElement>("[data-action=confirm-send]");
      if (confirm) {
        confirm.disabled = true;
        confirm.title = warning.textContent;
      }
    }
    // Public bounded summaries cover collapsed/resolved/off-page discussions.
    for (const thread of this.threads) {
      const article = this.element.querySelector<HTMLElement>(`#cr-${thread.id}`);
      const header = article?.querySelector("header");
      if (header) header.insertAdjacentHTML("beforeend", this.deliveryHtml(thread));
      if (article && !this.detail.has(thread.id)) {
        const summary = article.querySelector(".cr-message");
        if (summary) summary.insertAdjacentHTML("afterbegin", `<div class="cr-summary-author">${this.authorHtml(thread.summary?.authorKind, thread.summary?.authorId)} <small>on this snapshot</small></div>`);
        const footer = this.element.ownerDocument.createElement("footer");
        footer.innerHTML = `${button("reply", "Reply", "Read current guidance and reply without sending agent work.", `data-thread="${thread.id}" ${thread.state === "resolved" ? "disabled" : ""}`)}${button(thread.state === "resolved" ? "reopen" : "resolve", thread.state === "resolved" ? "Reopen" : "Resolve", "Change concern state explicitly; discussion history is retained.", `data-thread="${thread.id}"`)}${button("send-thread", "Send thread", "Preview only this thread before explicit queue confirmation.", `data-thread="${thread.id}" ${thread.state !== "open" ? "disabled" : ""}`)}`;
        const expand = article.querySelector("[data-action=expand]");
        if (expand) footer.append(expand);
        article.append(footer);
      }
      const messages = this.detail.get(thread.id)?.messages ?? [];
      article?.querySelectorAll(".cr-message").forEach((element, index) => {
        if (messages[index]) element.insertAdjacentHTML("beforeend", this.evidenceHtml(messages[index]));
      });
      const item = this.element.querySelector<HTMLInputElement>(`.cr-drawer .cr-drawer-item[data-thread-id="${thread.id}"]`)?.closest(".cr-drawer-item");
      if (item) {
        const location = item.querySelector("small");
        if (location) {
          const status = this.projections.get(thread.id)?.status;
          location.textContent = `${this.threadLocation(thread)} · ${thread.state} · ${this.deliveryLabel(thread)}${status === "missing" ? " · outdated (not mapped)" : status === "ambiguous" ? " · ambiguous (not mapped)" : !this.relevant(thread) ? " · original context" : ""}`;
          location.setAttribute("title", `Thread ${thread.id}`);
        }
        item.insertAdjacentHTML("afterbegin", `${this.authorHtml(thread.summary?.authorKind, thread.summary?.authorId)}<strong class="cr-thread-path">${e(thread.summary?.filePath ?? "Original source")}</strong>`);
        item.insertAdjacentHTML("beforeend", `<p class="cr-thread-summary">${e(thread.summary?.body ?? "Comment deleted")}</p>`);
      }
    }
    const source = this.element.querySelector(".cr-source");
    if (source) source.scrollTop = previousScroll;
    if (this.drawer && !focusId)
      this.element.querySelector<HTMLElement>(".cr-drawer button")?.focus();
    for (const option of this.element.querySelectorAll<HTMLOptionElement>(
      "option",
    ))
      if (!option.title)
        option.title = option.textContent || "Choose this option.";
    if (focusId) {
      const next = this.element.querySelector<HTMLElement>(
        "#" + CSS.escape(focusId),
      );
      next?.focus();
      if (
        next instanceof HTMLTextAreaElement ||
        next instanceof HTMLInputElement
      )
        try {
          next.setSelectionRange(selectionStart, selectionEnd);
        } catch {}
    }
  }
  private compose(threadId?: string) {
    this.draftEpoch++;
    const range = this.selection
      ? { startLine: this.selection.startLine, endLine: this.selection.endLine }
      : undefined;
    if (this.composer?.body)
      this.fileDrafts.set(this.composer.fileId, this.composer);
    this.composer = {
      body: "",
      fileId: this.fileId,
      threadId,
      range: threadId ? undefined : range,
      side: this.selection?.side || (this.view === "source" ? "source" : "new"),
      requestId: requestId(),
    };
    if (this.selection && !threadId) this.composer.side = this.selection.side;
    this.editMessage = null;
    this.commentThreadVersion = threadId
      ? this.threads.find((t) => t.id === threadId)?.version
      : undefined;
    this.setDirty(false);
    this.render();
    this.element.querySelector<HTMLTextAreaElement>("#cr-body")?.focus();
  }
  private async persistDraft() {
    if (this.draftPromise) return this.draftPromise;
    this.draftPromise = this.writeDraft().finally(() => {
      this.draftPromise = null;
    });
    return this.draftPromise;
  }
  private async writeDraft() {
    clearTimeout(this.draftTimer);
    if (!this.composer || !this.dirty || this.savingDraft || this.editMessage)
      return;
    const draft = this.composer,
      epoch = this.draftEpoch;
    draft.pending ??= {
      body: draft.body,
      requestId: requestId(),
      expectedVersion: draft.version,
    };
    const pending = draft.pending,
      body = pending.body;
    this.savingDraft = true;
    try {
      const saved = await this.api("draft", {
        draftId: draft.draftId,
        threadId: draft.threadId,
        ...(!draft.threadId
          ? { fileId: draft.fileId, side: draft.side, range: draft.range }
          : {}),
        body,
        expectedVersion: pending.expectedVersion,
        requestId: pending.requestId,
      });
      draft.draftId = saved.draftId;
      draft.version = saved.version;
      draft.pending = undefined;
      this.fileDrafts.set(draft.fileId, draft);
      if (epoch === this.draftEpoch && this.composer === draft) {
        this.setDirty(draft.body !== body);
        if (this.dirty)
          this.draftTimer = setTimeout(() => void this.persistDraft(), 500);
        this.render();
      }
    } catch (error) {
      this.fail(error);
    } finally {
      this.savingDraft = false;
    }
  }
  private click = (event: Event) => {
    const el = (event.target as Element).closest<HTMLElement>("[data-action]");
    if (!el || el.matches(":disabled") || this.busy) return;
    event.preventDefault();
    this.busy = true;
    const modes = this.element.querySelector<HTMLSelectElement>("#cr-source-mode");
    if (modes) modes.disabled = true;
    void this.perform(el.dataset.action!, el)
      .catch((error) => this.fail(error))
      .finally(() => {
        this.busy = false;
        const modes = this.element.querySelector<HTMLSelectElement>("#cr-source-mode");
        if (modes) modes.disabled = false;
      });
  };
  private async perform(name: string, el: HTMLElement) {
    const t = () => this.threads.find((t) => t.id === el.dataset.thread);
    if (name !== "options") this.moreMenu = false;
    // Switching composer/anchor never hides unacknowledged text or an in-flight draft write.
    if (
      [
        "line-comment",
        "range-comment",
        "file-comment",
        "reply",
        "edit",
        "drafts",
        "history",
        "add-file",
        "jump",
        "refresh",
        "staged",
        "unstaged",
      ].includes(name)
    ) {
      await this.persistDraft();
      if (this.dirty)
        throw Error(
          "Save or explicitly discard the pending comment before changing its context.",
        );
      if (this.composer?.body)
        this.fileDrafts.set(this.composer.fileId, this.composer);
    }
    switch (name) {
      case "load":
        await this.load();
        return;
      case "dismiss":
        this.status = "";
        break;
      case "dismiss-reply":
        if (this.pendingReply && confirm("Forget the pending reply marker? Saved drafts and published replies remain unchanged."))
          this.clearPendingReply(this.pendingReply.requestId);
        break;
      case "clear-recovery":
        if (!confirm("Clear the unreadable browser marker? Check saved replies and drafts first; this does not delete them.")) break;
        localStorage.removeItem(this.replyKey());
        this.replyStorageAvailable = true;
        this.pendingReply = null;
        this.status = "Browser marker cleared. Review saved replies and drafts before posting again.";
        break;
      case "reconcile-reply": {
        const pending = this.readPendingReply() ?? this.pendingReply;
        if (!pending) return;
        await this.reconcileReply(pending);
        break;
      }
      case "options":
        this.moreMenu = !this.moreMenu;
        break;
      case "files":
        this.showFiles = !this.showFiles;
        break;
      case "file":
        await this.persistDraft();
        if (this.dirty)
          throw Error(
            "Save or discard the current comment before changing file.",
          );
        this.fileScroll.set(
          this.fileId,
          this.element.querySelector(".cr-source")?.scrollTop || 0,
        );
        if (this.composer) this.fileDrafts.set(this.fileId, this.composer);
        if (this.selection)
          this.sourceSelection.set(this.fileId, this.selection);
        this.fileId = el.dataset.file!;
        this.page = 0;
        this.selection = this.sourceSelection.get(this.fileId) || null;
        this.composer = this.fileDrafts.get(this.fileId) || null;
        this.draftEpoch++;
        await this.loadContent();
        return;
      case "expand-context":
        this.contextExpanded = true;
        break;
      case "wrap":
        this.wrap = !this.wrap;
        break;
      case "layout":
        this.view = this.view === "split" ? "unified" : "split";
        break;
      case "previous":
        this.page = Math.max(0, this.page - 1);
        await this.loadContent();
        return;
      case "next":
        this.page++;
        await this.loadContent();
        return;
      case "line-comment":
        this.selection = {
          startLine: Number(el.dataset.line),
          endLine: Number(el.dataset.line),
          side: el.dataset.side!,
        };
        this.compose();
        return;
      case "select-line": {
        const line = Number(el.dataset.line),
          side = el.dataset.side!;
        this.selection =
          this.selection?.side === side
            ? {
                side,
                startLine: Math.min(this.selection.startLine, line),
                endLine: Math.max(this.selection.endLine, line),
              }
            : { side, startLine: line, endLine: line };
        break;
      }
      case "clear-range":
        this.selection = null;
        break;
      case "file-comment":
        this.selection = null;
        this.compose();
        return;
      case "range-comment":
        this.compose();
        return;
      case "threads":
        this.drawerFocus = el;
        this.drawer = "threads";
        break;
      case "close-drawer":
        clearTimeout(this.previewTimer);
        ++this.previewEpoch;
        this.previewLoading = false;
        this.drawer = null;
        this.sendThreadId = null;
        this.sendIntent = null;
        this.sendPreview = null;
        this.pendingPayload = null;
        break;
      case "more-threads": {
        const rows = await this.api("threads", { after: this.threadPageAfter });
        this.threads.push(...rows);
        this.threadPageAfter = rows.at(-1)?.id || this.threadPageAfter;
        this.hasMoreThreads = rows.length === 50;
        await this.loadContent();
        return;
      }
      case "more-messages": {
        const data = this.detail.get(t().id);
        const next = await this.api("thread", {
          threadId: t().id,
          after: data.messages.at(-1)?.ordinal || 0,
        });
        this.detail.set(t().id, {
          ...next,
          messages: [...data.messages, ...next.messages],
        });
        this.moreMessages.set(t().id, next.messages.length === 100);
        break;
      }
      case "expand":
        if (this.detail.has(el.dataset.thread!)) {
          this.collapsedThreads.add(el.dataset.thread!);
          this.detail.delete(el.dataset.thread!);
        } else {
          this.collapsedThreads.delete(el.dataset.thread!);
          await this.openThread(el.dataset.thread!);
        }
        break;
      case "jump": {
        await this.persistDraft();
        if (this.dirty)
          throw Error("Save the comment draft before navigating.");
        const thread = t();
        this.drawer = null;
        await this.openThread(thread.id);
        const data = this.detail.get(thread.id);
        if (data.source.snapshotId !== this.snapshotId) {
          this.snapshotId = data.source.snapshotId;
          this.fileId = thread.anchor.snapshotFileId;
          await this.loadFiles();
        } else this.fileId = thread.anchor.snapshotFileId;
        this.page = Math.floor(
          Math.max(0, (thread.anchor.endLine || 1) - 1) / 300,
        );
        await this.loadContent();
        this.element
          .querySelector("#cr-" + thread.id)
          ?.scrollIntoView({ block: "center" });
        return;
      }
      case "reply":
        if (t().state === "resolved") throw Error("Reopen this concern first.");
        if (!this.detail.has(t().id)) await this.openThread(t().id);
        this.compose(t().id);
        this.commentThreadVersion =
          this.selectedThreadReads.get(t().id)?.version ?? t().version;
        return;
      case "edit": {
        const thread = t();
        const message = this.detail
          .get(thread.id)
          ?.messages.find((m: any) => m.id === el.dataset.message);
        this.compose(thread.id);
        this.editMessage = message;
        this.composer!.body = message.body;
        this.render();
        return;
      }
      case "cancel":
        clearTimeout(this.draftTimer);
        await this.draftPromise;
        if (this.composer?.pending) {
          this.status = "Draft acknowledgement is uncertain. Retry saving before discarding its persisted copy.";
          this.render();
          this.element.querySelector<HTMLTextAreaElement>("#cr-body")?.focus();
          return;
        }
        if (this.composer?.body && !confirm("Discard this unposted text?")) {
          // The dialog can restore focus to the button after this task.
          // Restore the draft after the current click finishes rendering.
          setTimeout(() => this.element.querySelector<HTMLTextAreaElement>("#cr-body")?.focus(), 0);
          return;
        }
        if (this.composer?.draftId)
          await this.api("deleteDraft", {
            draftId: this.composer.draftId,
            expectedVersion: this.composer.version,
            requestId: requestId(),
          });
        if (this.composer) this.fileDrafts.delete(this.composer.fileId);
        this.draftEpoch++;
        this.composer = null;
        this.editMessage = null;
        this.setDirty(false);
        break;
      case "post": {
        if (!this.composer?.body.trim()) throw Error("Write guidance first.");
        clearTimeout(this.draftTimer);
        await this.draftPromise;
        const draft = this.composer;
        if (draft.pending)
          throw Error(
            "Draft acknowledgement is uncertain; save it again before posting.",
          );
        if (this.editMessage)
          await this.api("edit", {
            messageId: this.editMessage.id,
            expectedVersion: this.editMessage.version,
            body: draft.body,
            requestId: draft.requestId,
          });
        else if (draft.threadId) {
          const previous = this.readPendingReply() ?? this.pendingReply;
          if (previous && previous.requestId !== draft.requestId) {
            const committed = await this.reconcileReply(previous);
            if (!committed)
              throw Error("Reconcile or dismiss the earlier reply before posting another.");
            if (this.pendingReply || this.readPendingReply())
              throw Error("Reconcile or dismiss the earlier reply before posting another.");
            if (this.composer !== draft) return;
            const latest = await this.api<{ version: number }>("thread", { threadId: draft.threadId, limit: 1 });
            this.commentThreadVersion = latest.version;
          }
          if (!previous && this.externallyReconciledThreads.has(draft.threadId)) {
            const latest = await this.api<{ version: number }>("thread", { threadId: draft.threadId, limit: 1 });
            this.commentThreadVersion = latest.version;
          }
          this.savePendingReply({
            requestId: draft.requestId,
            threadId: draft.threadId,
            ...(draft.draftId ? { draftId: draft.draftId, draftVersion: draft.version } : {}),
          });
          await this.api("reply", {
            threadId: draft.threadId,
            expectedVersion: this.commentThreadVersion,
            body: draft.body,
            requestId: draft.requestId,
          });
          this.clearPendingReply(draft.requestId);
          this.externallyReconciledThreads.delete(draft.threadId);
          this.status = "";
        } else
          await this.api("comment", {
            fileId: draft.fileId,
            side: draft.side,
            range: draft.range,
            body: draft.body,
            requestId: draft.requestId,
          });
        if (draft.draftId)
          try {
            await this.api("deleteDraft", {
              draftId: draft.draftId,
              expectedVersion: draft.version,
              requestId: requestId(),
            });
          } catch {
            this.status = "Comment saved. The draft changed or could not be removed; inspect saved drafts before deleting.";
          }
        this.fileDrafts.delete(draft.fileId);
        this.draftEpoch++;
        this.composer = null;
        this.editMessage = null;
        this.setDirty(false);
        if (!this.status) this.status = "Comment saved. No agent work queued.";
        await this.reloadThreads();
        return;
      }
      case "delete-message":
        if (confirm("Delete your message body and retain replies?")) {
          const message = this.detail
            .get(t().id)
            .messages.find((m: any) => m.id === el.dataset.message);
          await this.api("deleteMessage", {
            messageId: message.id,
            expectedVersion: message.version,
            confirm: true,
            requestId: requestId(),
          });
          await this.reloadThreads();
        }
        return;
      case "delete-thread":
        if (
          confirm(
            "Delete this discussion? Already delivered work cannot be recalled.",
          )
        ) {
          await this.api("deleteThread", {
            threadId: t().id,
            expectedVersion: t().version,
            confirm: true,
            requestId: requestId(),
          });
          this.detail.delete(t().id);
          await this.reloadThreads();
        }
        return;
      case "resolve": {
        await this.api("resolve", {
          threadId: t().id,
          expectedVersion: t().version,
          explanation: "",
          fileId: this.fileId,
          requestId: requestId(),
        });
        await this.reloadThreads();
        return;
      }
      case "reopen":
        await this.api("reopen", {
          threadId: t().id,
          expectedVersion: t().version,
          requestId: requestId(),
        });
        await this.reloadThreads();
        return;
      case "reassign":
        if (confirm(`Reassign this concern to ${this.activeTarget.label}?`)) {
          await this.api("reassign", {
            threadId: t().id,
            target: this.activeTarget,
            expectedVersion: t().version,
            requestId: requestId(),
          });
          await this.reloadThreads();
        }
        return;
      case "send-thread":
        this.selected.clear();
        this.selected.add(t().id);
        this.sendThreadId = t().id;
        this.activeTarget = t().target; // fall through
      case "send":
      case "refresh-send-preview": {
        if (name === 'send') this.sendThreadId = null;
        const previewEpoch = ++this.previewEpoch;
        this.previewLoading = true;
        this.sendPreview = null;
        this.sendIntent = null;
        this.pendingPayload = null;
        try {
        if (name !== "send-thread") {
          let rows: any[] = [], after = "";
          for (;;) { const page = await this.api<any[]>("threads", {after}); rows.push(...page); if (page.length < 50) break; after = page.at(-1).id; }
          this.threads = rows;
          if (this.sendThreadId) this.selected = new Set(rows.some(t => t.id === this.sendThreadId && t.state === 'open') ? [this.sendThreadId] : []);
          else this.syncUnsent();
        }
        if (previewEpoch !== this.previewEpoch || this.disposed) return;
        if (!this.selected.size) throw Error("No unsent discussions for this agent.");
        if (this.selected.size > 50) this.selected = new Set([...this.selected].slice(0,50));
        if (this.hasTargetMismatch()) {
          this.drawer = "send";
          this.status = "";
          break;
        }
        const payload = {
          target: { ...this.activeTarget },
          items: this.selectionItems(),
          summary: this.summary,
        };
        this.pendingPayload = payload;
        const preview = await this.api<typeof this.sendPreview>("preview", payload);
        // Selection/target may change while the inert preview request is in flight.
        if (this.pendingPayload !== payload || previewEpoch !== this.previewEpoch || this.disposed) return;
        this.sendPreview = preview;
        this.sendIntent = requestId();
        this.drawer = "send";
        this.status = "";
        } catch (error) {
          if (previewEpoch === this.previewEpoch && error instanceof ApiError && error.code === "already_queued") {
            this.drawer = "send";
            this.status = error.message;
          } else throw error;
        } finally {
          if (previewEpoch === this.previewEpoch) { this.previewLoading = false; this.render(); }
        }
        break;
      }
      case "confirm-send": {
        if (this.hasTargetMismatch()) throw Error("Reassign selected threads explicitly or send separate batches.");
        const intent = this.sendIntent;
        if (!intent || !this.pendingPayload || !this.sendPreview)
          throw Error("Preview the review before sending.");
        let result;
        try {
          result = await this.api("send", {
            ...this.pendingPayload,
            summary: this.summary,
            requestId: intent,
          });
        } catch (error) {
          // A known version conflict cannot have queued anything. Refresh the
          // preview, but require another explicit confirmation of the new content.
          if (error instanceof ApiError && error.code === "conflict") {
            await this.perform("refresh-send-preview", el);
            this.status = "Guidance changed. Review the updated selection, then send again if intended.";
            this.render();
            return;
          }
          throw error;
        }
        const attempt = result.attempts.at(-1);
        this.status = attempt.state === "accepted" ? "Queued" : attempt.state === "rejected" ? "Failed" : "Delivery uncertain. Check the discussion before retrying.";
        this.drawer = null;
        this.selected.clear();
        this.sendIntent = null;
        this.sendPreview = null;
        this.pendingPayload = null;
        await this.reloadThreads();
        break;
      }
      case "refresh":
      case "staged":
      case "unstaged": {
        if (this.dirty)
          throw Error(
            "Save the pending comment draft before capturing a new source.",
          );
        const mode = name === "refresh" ? "source" : name;
        this.review = await this.api("review");
        const capture = await this.api("capture", {
          source: {
            path: this.review.focus_path,
            mode,
            includeUntracked: true,
          },
          requestId: requestId(),
        });
        this.snapshots = await this.api("snapshots");
        this.snapshotId = capture.snapshotId;
        this.fileId = "";
        await this.reloadThreads();
        await this.loadFiles();
        return;
      }
      case "history": {
        let skip = 0;
        let row: any;
        for (;;) {
          const rows = await this.api<any[]>("history", {
            path: this.review.focus_path,
            limit: 20,
            skip,
          });
          if (!rows.length) throw Error("No further file history is available.");
          const pick = prompt(
            rows.map((r, i) =>
              `${i + 1}. ${r.commit.slice(0, 8)} ${r.subject}${r.path ? ` · ${r.path}${r.previousPath ? ` ← ${r.previousPath}` : ""}` : ""}`,
            ).join("\n") + `\nCommits ${skip + 1}–${skip + rows.length}. Enter a number${rows.length === 20 && skip + 20 < 10000 ? ", or N for older commits" : ""}.`,
          );
          if (pick === null) return;
          if (pick.trim().toLowerCase() === "n" && rows.length === 20 && skip + 20 < 10000) {
            skip += 20;
            continue;
          }
          const number = Number(pick);
          if (!Number.isSafeInteger(number) || number < 1 || number > rows.length)
            throw Error("Select a listed commit or the next history page.");
          row = rows[number - 1];
          break;
        }
        let parent;
        if (row.parents.length > 1) {
          const number = prompt(
            row.parents
              .map((p: string, i: number) => `${i + 1}. ${p}`)
              .join("\n") + "\nParent number",
          );
          if (number === null) return;
          parent = row.parents[Number(number) - 1];
          if (!parent) throw Error("Select a listed parent.");
        }
        const capture = await this.api("capture", {
          source: {
            path: row.path ?? this.review.focus_path,
            mode: "commit",
            commit: row.commit,
            parent,
          },
          requestId: requestId(),
        });
        this.snapshots = await this.api("snapshots");
        this.snapshotId = capture.snapshotId;
        await this.loadFiles();
        return;
      }
      case "add-file": {
        const path = prompt("Saved workspace-relative file path");
        if (!path) return;
        const capture = await this.api("addFile", {
          path,
          snapshotId: this.snapshotId,
          requestId: requestId(),
        });
        this.snapshots = await this.api("snapshots");
        this.snapshotId = capture.snapshotId;
        this.fileId = "";
        await this.loadFiles();
        return;
      }
      case "drafts": {
        this.savedDrafts = await this.api("drafts");
        const pick = prompt(
          this.savedDrafts
            .map((d: any, i: number) => `${i + 1}. ${d.body.slice(0, 80)}`)
            .join("\n") + "\nDraft number",
        );
        if (pick === null) return;
        const draft = this.savedDrafts[Number(pick) - 1];
        if (!draft) throw Error("Select a saved draft.");
        const anchor = draft.anchor_json ? JSON.parse(draft.anchor_json) : null;
        if (anchor && anchor.snapshotFileId !== this.fileId)
          throw Error("Open the draft’s original file snapshot first.");
        this.commentThreadVersion = draft.thread_id
          ? this.threads.find((t) => t.id === draft.thread_id)?.version
          : undefined;
        this.composer = {
          body: draft.body,
          fileId: this.fileId,
          threadId: draft.thread_id || undefined,
          side: anchor?.side || "source",
          range:
            anchor?.scope === "range"
              ? { startLine: anchor.startLine, endLine: anchor.endLine }
              : undefined,
          draftId: draft.id,
          version: draft.version,
          requestId: requestId(),
        };
        this.draftEpoch++;
        break;
      }
      case "retry": {
        if (!confirm("Retry this definitively rejected send?")) return;
        const result = await this.api("retry", {
          dispatchId: el.dataset.dispatch,
          requestId: requestId(),
        });
        this.status = "Retry outcome: " + result.attempts.at(-1).state;
        await this.reloadThreads();
        break;
      }
      case "reconcile": {
        const receipt = await this.api("dispatch", {dispatchId: el.dataset.dispatch}),
          last = receipt.attempts.at(-1);
        const decision = prompt(
          "After checking host receipts, type accepted or rejected. Cancel if still unknown.",
        );
        if (decision === null) return;
        if (!["accepted", "rejected"].includes(decision))
          throw Error(
            "Use accepted or rejected only when evidence establishes it.",
          );
        const evidence = prompt(
          "Public evidence or receipt reference supporting this decision",
        );
        if (!evidence) return;
        await this.api("reconcile", {
          dispatchId: receipt.id,
          attemptId: last.id,
          decision,
          evidence,
          confirm: true,
          requestId: requestId(),
        });
        await this.reloadThreads();
        break;
      }
      case "reanchor": {
        if (!this.selection) throw Error("Select a saved range.");
        const id = prompt("Thread ID to re-anchor");
        if (!id) return;
        const thread = this.threads.find((t) => t.id === id);
        if (!thread) throw Error("Choose a thread in this review.");
        if (
          !confirm(
            thread.state === "resolved"
              ? "Reopen and re-anchor this concern?"
              : "Re-anchor this concern?",
          )
        )
          return;
        await this.api("reanchor", {
          threadId: id,
          fileId: this.fileId,
          side: this.selection.side,
          range: {
            startLine: this.selection.startLine,
            endLine: this.selection.endLine,
          },
          reopen: thread.state === "resolved",
          confirm: true,
          expectedVersion: thread.version,
          requestId: requestId(),
        });
        await this.reloadThreads();
        return;
      }
    }
    this.render();
  }
  private selectionItems() {
    return [...this.selected].map((id) => {
      const t = this.threads.find((t) => t.id === id);
      return { threadId: id, version: t.version };
    });
  }
  private change = (event: Event) => {
    const el = event.target as HTMLInputElement;
    if (
      !["cr-target", "cr-snapshot", "cr-source-mode", "cr-thread-filter", "cr-unresolved-files"].includes(el.id)
    )
      return;
    void (async () => {
      if (el.id === "cr-source-mode") {
        if (this.busy) { this.render(); return; }
        const mode = el.value;
        if (!["source", "unstaged", "staged", "commit"].includes(mode)) return;
        this.busy = true;
        el.disabled = true;
        try { await this.perform(mode === "source" ? "refresh" : mode === "commit" ? "history" : mode, el); }
        finally { this.busy = false; this.render(); }
        return;
      }
      if (el.id === "cr-unresolved-files") {
        this.unresolvedFilesOnly = el.checked;
      } else if (el.id === "cr-target") {
        ++this.previewEpoch;
        this.previewLoading = false;
        const selected = this.targets.find((t) => t.chatJid === el.value);
        this.activeTarget = {
          chatId: selected.chatJid,
          incarnation: selected.incarnation,
          label: selected.label,
        };
        this.sendIntent = null;
        this.sendPreview = null;
        this.pendingPayload = null;
      } else if (el.id === "cr-snapshot") {
        if (this.dirty) throw Error("Save the comment draft first.");
        this.snapshotId = el.value;
        await this.loadFiles();
      } else if (el.id === "cr-thread-filter") this.threadFilter = el.value;
      this.render();
      if (this.drawer === "send" && el.id === "cr-target") {
        this.syncUnsent();
        if (this.selected.size) await this.perform("refresh-send-preview", el);
      }
    })().catch((error) => this.fail(error));
  };
  private input = (event: Event) => {
    const el = event.target as HTMLInputElement;
    if (el.id === "cr-body" && this.composer) {
      this.composer.body = el.value;
      this.composer.requestId = requestId();
      this.setDirty(true);
      clearTimeout(this.draftTimer);
      this.draftTimer = setTimeout(() => void this.persistDraft(), 500);
    } else if (el.id === "cr-summary") {
      this.summary = el.value;
      if (this.drawer === "send") {
        clearTimeout(this.previewTimer);
        ++this.previewEpoch;
        this.sendIntent = null;
        this.sendPreview = null;
        this.pendingPayload = null;
        this.previewLoading = true;
        this.render();
        this.previewTimer = setTimeout(() => {
          if (!this.disposed && this.drawer === "send")
            void this.perform("refresh-send-preview", el).catch((error) => this.fail(error));
        }, 250);
      }
    } else if (el.id === "cr-filter") {
      this.fileFilter = el.value;
      this.render();
    }
  };
  private copySource = (event: ClipboardEvent) => {
    const selection = this.element.ownerDocument.getSelection();
    const source = this.element.querySelector(".cr-source");
    if (!source || !selection || selection.isCollapsed || !event.clipboardData ||
        !source.contains(selection.anchorNode) || !source.contains(selection.focusNode)) return;
    const range = selection.getRangeAt(0);
    const rows = [...source.querySelectorAll<HTMLElement>(".cr-line[data-line]")].filter((row) =>
      range.intersectsNode(row.querySelector("code")!),
    );
    if (!rows.length) return;
    const copied = rows.map((row) => {
      const code = row.querySelector("code")!;
      const selected = range.cloneRange();
      selected.selectNodeContents(code);
      if (code.contains(range.startContainer))
        selected.setStart(range.startContainer, range.startOffset);
      if (code.contains(range.endContainer))
        selected.setEnd(range.endContainer, range.endOffset);
      return selected.toString();
    }).join("\n");
    event.clipboardData.setData("text/plain", copied);
    event.preventDefault();
  };
  private keydown = (event: KeyboardEvent) => {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "s") {
      event.preventDefault();
      void this.persistDraft();
    }
    if (event.key === "Tab" && this.drawer) {
      const nodes = [
        ...this.element.querySelectorAll<HTMLElement>(
          ".cr-drawer button:not(:disabled),.cr-drawer input:not(:disabled),.cr-drawer select,.cr-drawer textarea",
        ),
      ].filter((n) => n.offsetParent !== null);
      const first = nodes[0],
        last = nodes.at(-1);
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last?.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first?.focus();
      }
    }
    if (event.key === "Escape") {
      const messageMenu = this.element.querySelector<HTMLDetailsElement>(".cr-message-options[open]");
      if (messageMenu) {
        event.preventDefault();
        event.stopPropagation();
        messageMenu.open = false;
        messageMenu.querySelector<HTMLElement>("summary")?.focus();
        return;
      }
      if (this.moreMenu || this.drawer) {
        event.preventDefault();
        event.stopPropagation();
        if (this.moreMenu) {
          this.moreMenu = false;
          this.render();
        } else {
          clearTimeout(this.previewTimer);
          ++this.previewEpoch;
          this.previewLoading = false;
          this.pendingPayload = null;
          this.sendPreview = null;
          this.sendIntent = null;
          this.drawer = null;
          this.render();
          this.element.querySelector<HTMLElement>("[data-action=threads]")?.focus();
        }
      }
    }
  };
}
export const reviewPane = {
  id: "code-review",
  label: "Code Review",
  capabilities: ["readonly"],
  placement: "tabs",
  canHandle(context: any) {
    return typeof context.path === "string" &&
      context.path.startsWith(pathPrefix)
      ? 100
      : false;
  },
  mount(container: HTMLElement, context: any) {
    return new CodeReviewPane(container, context);
  },
};
