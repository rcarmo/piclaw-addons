import { ReviewDatabase, id, now } from "./database.js";
import { createAnchor, projectAnchor } from "./anchors.js";
import {
  LIMITS,
  ReviewError,
  type DeliveryState,
  type ReviewIdentity,
  type LocalTarget,
  type SourceCapture,
  type OriginalAnchor,
  type Mutation,
  type WorkState,
  REVIEW_DISPATCH_ADDON_ID,
} from "./contracts.js";
import {
  boundedText,
  hashText,
  identity,
  operator,
  pageSize,
  stableJson,
  target,
  validId,
  version,
} from "./validation.js";
export interface ReviewRecord {
  id: string;
  owner_id: string;
  workspace_id: string;
  worktree_id: string;
  title: string;
  focus_path: string;
  target_json: string;
  version: number;
  created_at: string;
  updated_at: string;
}
export interface ThreadRecord {
  id: string;
  review_id: string;
  anchor_json: string;
  state: "open" | "resolved" | "deleted";
  target_json: string;
  assignment_epoch: number;
  version: number;
  created_at: string;
  updated_at: string;
}
export interface SnapshotFileRecord {
  id: string;
  snapshot_id: string;
  review_id: string;
  old_path: string | null;
  new_path: string | null;
  old_hash: string | null;
  new_hash: string | null;
  file_identity: string | null;
  change_kind: string;
}
interface MessageRecord {
  id: string;
  thread_id: string;
  review_id: string;
  ordinal: number;
  author_id: string;
  author_kind: string;
  version: number;
  deleted: number;
  created_at: string;
  updated_at: string;
}
interface ThreadSummary {
  body: string | null;
  authorKind: "operator" | "agent" | null;
  authorId: string | null;
  unsent: boolean;
  outstanding: boolean;
  messageCount: number;
  filePath: string | null;
  deliveryState: DeliveryState | null;
  dispatchId: string | null;
  workState: WorkState | null;
  hasUnsentGuidance: boolean;
}
interface MessageResolution {
  fileId: string;
  evidence: string[];
  addressedVersion: number;
}
interface AgentDispatchReferenceScope {
  dispatchId: string;
  reviewId: string;
  threadIds: ReadonlySet<string>;
  fileIds: ReadonlySet<string>;
  assignmentEpochs: ReadonlyMap<string, number>;
}
export interface ReviewSettings {
  retentionDays: number | null;
}
export interface ReviewCleanupResult extends ReviewSettings {
  deletedCount: number;
  deletedReviewIds: string[];
}
const RETENTION_REVIEW_LIMIT = 100;
export class ReviewStore {
  readonly database: ReviewDatabase;
  constructor(path: string) {
    this.database = new ReviewDatabase(path);
  }
  close() {
    this.database.close();
  }
  protected workspaceScope(who: ReviewIdentity) {
    operator(who);
    return {
      ownerId: who.ownerId,
      workspaceId: validId(who.workspaceId, "workspace"),
    };
  }
  protected retentionDays(value: unknown): number | null {
    if (value === null || value === undefined) return null;
    if (
      !Number.isInteger(value) ||
      Number(value) < 1 ||
      Number(value) > 3650
    )
      throw new ReviewError(
        "invalid_input",
        "Retention days must be null or an integer from 1 to 3650.",
      );
    return Number(value);
  }
  protected settings(ownerId: string, workspaceId: string): ReviewSettings {
    return {
      retentionDays:
        this.database.get<{ retention_days: number | null }>(
          "SELECT retention_days FROM review_settings WHERE owner_id=? AND workspace_id=?",
          ownerId,
          workspaceId,
        )?.retention_days ?? null,
    };
  }
  protected agentScopeUnavailable(): never {
    throw new ReviewError(
      "context_unavailable",
      "Verified review dispatch scope is unavailable.",
      403,
    );
  }
  protected dispatchScope(
    who: ReviewIdentity,
  ): AgentDispatchReferenceScope | null {
    // Public tool/API entry requires a host reference in scopeForAction.
    // Bare identities remain useful to internal store callers and fixtures.
    if (who.kind !== "agent" || !who.reference) return null;
    const reference = who.reference;
    if (
      reference?.addonId !== REVIEW_DISPATCH_ADDON_ID ||
      !reference.intentId
    )
      this.agentScopeUnavailable();
    const row = this.database.get<{
      review_id: string;
      target_json: string;
    }>(
      "SELECT d.review_id,d.target_json FROM dispatches d JOIN reviews r ON r.id=d.review_id WHERE d.id=? AND r.owner_id=? AND (? IS NULL OR r.workspace_id=?) AND EXISTS(SELECT 1 FROM attempts a WHERE a.dispatch_id=d.id AND a.state IN ('attempting','accepted','unknown'))",
      reference.intentId,
      who.ownerId,
      who.workspaceId ?? null,
      who.workspaceId ?? null,
    );
    if (!row) return this.missing();
    const selected = JSON.parse(row.target_json) as LocalTarget;
    if (
      selected.chatId !== who.chatId ||
      selected.incarnation !== who.chatIncarnation
    )
      return this.missing();
    const items = this.database.all<{
      thread_id: string;
      snapshot_file_id: string;
      assignment_epoch: number;
    }>(
      "SELECT thread_id,snapshot_file_id,assignment_epoch FROM dispatch_items WHERE dispatch_id=? ORDER BY ordinal",
      reference.intentId,
    );
    return {
      dispatchId: reference.intentId,
      reviewId: row.review_id,
      threadIds: new Set(items.map((item) => item.thread_id)),
      fileIds: new Set(items.map((item) => item.snapshot_file_id)),
      assignmentEpochs: new Map(
        items.map((item) => [item.thread_id, item.assignment_epoch] as const),
      ),
    };
  }
  /** Compare durable event order, not timestamps or agent reply versions. */
  protected hasNewGuidance(threadId: string, dispatchId: string): boolean {
    return !!this.database.get(
      `SELECT 1 FROM events e LEFT JOIN messages m ON m.id=json_extract(e.data_json,'$.messageId')
       WHERE e.thread_id=? AND e.cursor>(SELECT cursor FROM events WHERE dispatch_id=? AND kind='dispatch.prepared' LIMIT 1)
       AND (e.kind IN ('thread.reopened','thread.reanchored') OR
         (e.kind IN ('message.created','message.edited','message.deleted') AND m.author_kind='operator')) LIMIT 1`,
      threadId, dispatchId,
    );
  }
  protected hasNewerSubmission(dispatchId: string, threadId: string, epoch: number, includePrepared = false): boolean {
    return !!this.database.get(
      `SELECT 1 FROM dispatch_items i JOIN dispatches d ON d.id=i.dispatch_id
       JOIN attempts a ON a.dispatch_id=d.id AND a.number=(SELECT MAX(number) FROM attempts WHERE dispatch_id=d.id)
       WHERE i.thread_id=? AND i.assignment_epoch=? AND d.rowid>(SELECT rowid FROM dispatches WHERE id=?)
       AND (a.state IN ('attempting','accepted','unknown') OR (? AND a.state='prepared')) LIMIT 1`, threadId, epoch, dispatchId, includePrepared ? 1 : 0,
    );
  }
  protected missing(): never {
    throw new ReviewError("not_found", "Review record is unavailable.", 404);
  }
  protected mutation<T>(
    who: ReviewIdentity,
    m: Mutation,
    action: string,
    payload: unknown,
    run: () => T,
  ): T {
    identity(who);
    validId(m.requestId, "request ID");
    const digest = hashText(stableJson({ action, payload }));
    return this.database.transaction(() => {
      const existing = this.database.get<{
        payload_hash: string;
        result_json: string;
      }>(
        "SELECT * FROM request_receipts WHERE owner_id=? AND actor_id=? AND request_id=?",
        who.ownerId,
        who.actorId,
        m.requestId,
      );
      if (existing) {
        if (existing.payload_hash !== digest)
          throw new ReviewError(
            "conflict",
            "Request ID already has a different action or payload.",
            409,
          );
        const result = JSON.parse(existing.result_json);
        if (result.reviewDeleted && action !== 'deleteReview') return this.missing();
        return result as T;
      }
      const result = run(); // Store only IDs/versions: receipts never cache comment text.
      this.database.run(
        "INSERT INTO request_receipts VALUES(?,?,?,?,?,?,?)",
        who.ownerId,
        who.actorId,
        m.requestId,
        action,
        digest,
        JSON.stringify(result),
        now(),
      );
      return result;
    });
  }
  /** Body-free lookup for an operator whose reply acknowledgement was lost. */
  replyReceipt(who: ReviewIdentity, reviewId: string, requestId: string, threadId: string) {
    operator(who);
    this.own(who, reviewId);
    validId(requestId, "request ID");
    const thread = this.thread(who, threadId, true);
    if (thread.review_id !== reviewId) this.missing();
    const receipt = this.database.get<{ result_json: string }>(
      "SELECT result_json FROM request_receipts WHERE owner_id=? AND actor_id=? AND request_id=? AND action='reply'",
      who.ownerId, who.actorId, requestId,
    );
    if (!receipt) return { committed: false };
    const result = JSON.parse(receipt.result_json) as { threadId?: string; messageId?: string };
    if (result.threadId !== threadId || !result.messageId) this.missing();
    // Deleted messages can still have a body-free receipt, but never resurrect content.
    const message = this.database.get<{ id: string }>(
      "SELECT id FROM messages WHERE id=? AND thread_id=? AND review_id=?",
      result.messageId, threadId, reviewId,
    );
    if (!message) this.missing();
    return { committed: true, threadId, messageId: message.id };
  }
  protected event(
    who: ReviewIdentity,
    reviewId: string,
    kind: string,
    data: Record<string, unknown>,
    threadId: string | null = null,
    dispatchId: string | null = null,
  ) {
    if (!this.database.get("SELECT id FROM reviews WHERE id=?", reviewId)) return;
    this.database.run("UPDATE reviews SET updated_at=? WHERE id=?", now(), reviewId);
    this.database.run(
      "INSERT INTO events(review_id,thread_id,dispatch_id,actor_id,kind,data_json,created_at) VALUES(?,?,?,?,?,?,?)",
      reviewId,
      threadId,
      dispatchId,
      who.actorId,
      kind,
      JSON.stringify(data),
      now(),
    );
  }
  private ids(sql: string, ...params: any[]): string[] {
    return this.database
      .all<{ id: string }>(sql, ...params)
      .map((row) => row.id);
  }
  private purgeDeletedReviewReceipts(
    ownerId: string,
    reviewId: string,
  ) {
    const stale = {
      threadIds: new Set(this.ids("SELECT id FROM threads WHERE review_id=?", reviewId)),
      messageIds: new Set(this.ids("SELECT id FROM messages WHERE review_id=?", reviewId)),
      draftIds: new Set(this.ids("SELECT id FROM drafts WHERE review_id=?", reviewId)),
      dispatchIds: new Set(this.ids("SELECT id FROM dispatches WHERE review_id=?", reviewId)),
      snapshotIds: new Set(this.ids("SELECT id FROM snapshots WHERE review_id=?", reviewId)),
    };
    const receipts = this.database.all<{
      actor_id: string;
      request_id: string;
      result_json: string;
    }>(
      "SELECT actor_id,request_id,result_json FROM request_receipts WHERE owner_id=?",
      ownerId,
    );
    for (const receipt of receipts) {
      let result: Record<string, unknown> | null = null;
      try {
        const parsed = JSON.parse(receipt.result_json);
        if (parsed && typeof parsed === "object" && !Array.isArray(parsed))
          result = parsed as Record<string, unknown>;
      } catch {}
      if (!result) continue;
      const staleResult =
        result.reviewId === reviewId ||
        (typeof result.threadId === "string" && stale.threadIds.has(result.threadId)) ||
        (typeof result.messageId === "string" && stale.messageIds.has(result.messageId)) ||
        (typeof result.draftId === "string" && stale.draftIds.has(result.draftId)) ||
        (typeof result.dispatchId === "string" && stale.dispatchIds.has(result.dispatchId)) ||
        (typeof result.snapshotId === "string" && stale.snapshotIds.has(result.snapshotId));
      if (!staleResult) continue;
      this.database.run(
        "UPDATE request_receipts SET result_json=? WHERE owner_id=? AND actor_id=? AND request_id=?",
        JSON.stringify({reviewDeleted:true}),
        ownerId,
        receipt.actor_id,
        receipt.request_id,
      );
    }
  }
  protected own(who: ReviewIdentity, reviewId: string): ReviewRecord {
    identity(who);
    const scope = this.dispatchScope(who);
    validId(reviewId);
    const record = this.database.get<ReviewRecord>(
      "SELECT * FROM reviews WHERE id=? AND owner_id=?",
      reviewId,
      who.ownerId,
    );
    if (!record || (who.workspaceId && who.workspaceId !== record.workspace_id))
      return this.missing();
    if (scope && scope.reviewId !== reviewId) return this.missing();
    return record;
  }
  protected assigned(who: ReviewIdentity, thread: ThreadRecord): void {
    const scope = this.dispatchScope(who);
    this.own(who, thread.review_id);
    if (who.kind === "agent") {
      const selected = JSON.parse(thread.target_json) as LocalTarget;
      if (
        selected.chatId !== who.chatId ||
        selected.incarnation !== who.chatIncarnation
      )
        this.missing();
      if (scope && (
        scope.reviewId !== thread.review_id ||
        !scope.threadIds.has(thread.id) ||
        scope.assignmentEpochs.get(thread.id) !== thread.assignment_epoch ||
        this.hasNewerSubmission(scope.dispatchId, thread.id, thread.assignment_epoch)
      ))
        this.missing();
    }
  }
  protected thread(
    who: ReviewIdentity,
    threadId: string,
    includeDeleted = false,
  ): ThreadRecord {
    validId(threadId);
    const record = this.database.get<ThreadRecord>(
      "SELECT * FROM threads WHERE id=?",
      threadId,
    );
    if (!record || (!includeDeleted && record.state === "deleted"))
      return this.missing();
    this.assigned(who, record);
    return record;
  }
  protected epoch(
    who: ReviewIdentity,
    thread: ThreadRecord,
    expected?: number,
  ) {
    if (who.kind === "agent" && expected !== thread.assignment_epoch)
      throw new ReviewError("conflict", "Thread assignment changed.", 409);
  }
  protected file(
    who: ReviewIdentity,
    reviewId: string,
    fileId: string,
  ): SnapshotFileRecord {
    const scope = this.dispatchScope(who);
    this.own(who, reviewId);
    const file = this.database.get<SnapshotFileRecord>(
      "SELECT * FROM snapshot_files WHERE id=? AND review_id=?",
      fileId,
      reviewId,
    );
    if (!file) return this.missing();
    if (scope && (scope.reviewId !== reviewId || !scope.fileIds.has(fileId)))
      return this.missing();
    return file;
  }
  protected source(
    file: SnapshotFileRecord,
    side: "old" | "new" | "source",
  ): string {
    if (!["old", "new", "source"].includes(side))
      throw new ReviewError("invalid_anchor", "Unknown source side.");
    if (
      side === "source" &&
      file.change_kind !== "source" &&
      file.change_kind !== "unchanged"
    )
      throw new ReviewError(
        "invalid_anchor",
        "Diff anchors require old or new side.",
      );
    const hash = side === "old" ? file.old_hash : file.new_hash;
    if (!hash)
      throw new ReviewError(
        "invalid_anchor",
        "That snapshot side has no source.",
      );
    const row = this.database.get<{ text: string }>(
      "SELECT text FROM blobs WHERE review_id=? AND hash=?",
      file.review_id,
      hash,
    );
    if (!row) return this.missing();
    return row.text;
  }
  createReview(
    who: ReviewIdentity,
    input: {
      workspaceId: string;
      worktreeId: string;
      title: string;
      focusPath: string;
      target: LocalTarget;
    },
    m: Mutation,
  ) {
    operator(who);
    if (who.workspaceId && who.workspaceId !== input.workspaceId)
      throw new ReviewError(
        "scope_mismatch",
        "Review workspace does not match trusted context.",
        403,
      );
    validId(input.workspaceId);
    validId(input.worktreeId);
    boundedText(input.title, "title", 240);
    boundedText(input.focusPath, "path", 4096);
    target(input.target);
    return this.mutation(who, m, "createReview", input, () => {
      const reviewId = id("review"),
        time = now();
      this.database.run(
        "INSERT INTO reviews VALUES(?,?,?,?,?,?,?,1,?,?)",
        reviewId,
        who.ownerId,
        input.workspaceId,
        input.worktreeId,
        input.title,
        input.focusPath,
        JSON.stringify(input.target),
        time,
        time,
      );
      this.event(who, reviewId, "review.created", {});
      return { reviewId, version: 1 };
    });
  }
  createFromCapture(
    who: ReviewIdentity,
    input: { title: string; focusPath: string; target: LocalTarget },
    capture: SourceCapture,
    m: Mutation,
  ) {
    operator(who);
    return this.mutation(
      who,
      m,
      "createFromCapture",
      {
        ...input,
        workspaceId: capture.workspaceId,
        worktreeId: capture.worktreeId,
      },
      () => {
        const review = this.createReview(
          who,
          {
            ...input,
            workspaceId: capture.workspaceId,
            worktreeId: capture.worktreeId,
          },
          { requestId: m.requestId + "/review" },
        );
        const snapshot = this.capture(who, review.reviewId, capture, {
          requestId: m.requestId + "/snapshot",
        });
        return { ...review, ...snapshot };
      },
    );
  }
  listReviews(who: ReviewIdentity, limit?: number, after = "") {
    operator(who);
    return this.database.all<ReviewRecord>(
      "SELECT * FROM reviews WHERE owner_id=? AND (? IS NULL OR workspace_id=?) AND id>? ORDER BY id LIMIT ?",
      who.ownerId,
      who.workspaceId ?? null,
      who.workspaceId ?? null,
      after,
      pageSize(limit, LIMITS.threadPage),
    );
  }
  getReview(who: ReviewIdentity, reviewId: string) {
    operator(who);
    return this.own(who, reviewId);
  }
  getSettings(who: ReviewIdentity): ReviewSettings {
    const scope = this.workspaceScope(who);
    return this.settings(scope.ownerId, scope.workspaceId);
  }
  saveSettings(who: ReviewIdentity, retentionDays: unknown): ReviewSettings {
    operator(who);
    if (!who.workspaceId) throw new ReviewError('scope_mismatch', 'Workspace identity required.');
    const days = this.retentionDays(retentionDays);
    this.database.run('INSERT INTO review_settings(owner_id,workspace_id,retention_days,updated_at) VALUES(?,?,?,?) ON CONFLICT(owner_id,workspace_id) DO UPDATE SET retention_days=excluded.retention_days,updated_at=excluded.updated_at', who.ownerId, who.workspaceId, days, now());
    return {retentionDays:days};
  }
  cleanupOldReviews(who: ReviewIdentity, at = Date.now()): ReviewCleanupResult {
    const days = this.getSettings(who).retentionDays;
    if (days === null) return {retentionDays:days,deletedCount:0,deletedReviewIds:[]};
    const cutoff = new Date(at - days * 86400000).toISOString();
    return this.database.transaction(() => {
      const rows = this.database.all<ReviewRecord>(
        `SELECT r.* FROM reviews r WHERE r.owner_id=? AND r.workspace_id=? AND r.updated_at<?
        AND NOT EXISTS(SELECT 1 FROM events WHERE review_id=r.id AND created_at>=?)
        AND NOT EXISTS(SELECT 1 FROM drafts WHERE review_id=r.id AND updated_at>=?)
        AND NOT EXISTS(SELECT 1 FROM dispatches d JOIN attempts a ON a.dispatch_id=d.id
          WHERE d.review_id=r.id AND a.number=(SELECT MAX(number) FROM attempts WHERE dispatch_id=d.id)
          AND (a.state IN ('prepared','attempting','unknown') OR (a.state='accepted' AND EXISTS(
            SELECT 1 FROM dispatch_items i WHERE i.dispatch_id=d.id AND i.work_state IN ('not_started','in_progress','waiting_user','blocked')))))
        ORDER BY r.updated_at LIMIT ?`, who.ownerId,who.workspaceId,cutoff,cutoff,cutoff,RETENTION_REVIEW_LIMIT);
      for (const row of rows) this.deleteReview(who,{reviewId:row.id,expectedVersion:row.version,requestId:'retention-'+row.id});
      return {retentionDays:days,deletedCount:rows.length,deletedReviewIds:rows.map(r=>r.id)};
    });
  }
  /** Persisted opt-in policy grants only deletion of this add-on's own scoped records. */
  cleanupConfiguredReviews(workspaceId: string): number {
    let deleted = 0;
    for (const policy of this.database.all<{owner_id:string;workspace_id:string}>('SELECT owner_id,workspace_id FROM review_settings WHERE retention_days IS NOT NULL AND workspace_id=?', workspaceId)) {
      deleted += this.cleanupOldReviews({ownerId:policy.owner_id,actorId:policy.owner_id,workspaceId:policy.workspace_id,kind:'operator'}).deletedCount;
    }
    return deleted;
  }
  deleteReview(
    who: ReviewIdentity,
    input: { reviewId: string; expectedVersion?: number; requestId: string },
  ) {
    operator(who);
    return this.mutation(
      who,
      { requestId: input.requestId, expectedVersion: input.expectedVersion },
      "deleteReview",
      { reviewId: input.reviewId, version: input.expectedVersion, workspaceId: who.workspaceId },
      () => {
        const review = this.own(who, input.reviewId);
        version(review.version, input.expectedVersion);
        if (this.database.get("SELECT 1 FROM attempts a JOIN dispatches d ON d.id=a.dispatch_id WHERE d.review_id=? AND a.state='attempting' LIMIT 1", input.reviewId))
          throw new ReviewError('busy', 'A send is in progress. Wait for its outcome before deleting this review.', 409);
        this.purgeDeletedReviewReceipts(who.ownerId, input.reviewId);
        this.database.run(
          "DELETE FROM projections WHERE review_id=?",
          input.reviewId,
        );
        this.database.run(
          "DELETE FROM message_revisions WHERE message_id IN (SELECT id FROM messages WHERE review_id=?)",
          input.reviewId,
        );
        this.database.run("DELETE FROM messages WHERE review_id=?", input.reviewId);
        this.database.run("DELETE FROM drafts WHERE review_id=?", input.reviewId);
        this.database.run("DELETE FROM events WHERE review_id=?", input.reviewId);
        this.database.run(
          "DELETE FROM dispatch_items WHERE review_id=?",
          input.reviewId,
        );
        this.database.run(
          "DELETE FROM attempts WHERE dispatch_id IN (SELECT id FROM dispatches WHERE review_id=?)",
          input.reviewId,
        );
        this.database.run("DELETE FROM dispatches WHERE review_id=?", input.reviewId);
        this.database.run("DELETE FROM threads WHERE review_id=?", input.reviewId);
        this.database.run(
          "DELETE FROM snapshot_files WHERE review_id=?",
          input.reviewId,
        );
        this.database.run("DELETE FROM snapshots WHERE review_id=?", input.reviewId);
        this.database.run("DELETE FROM blobs WHERE review_id=?", input.reviewId);
        this.database.run(
          "DELETE FROM reviews WHERE id=? AND owner_id=?",
          input.reviewId,
          who.ownerId,
        );
        return { reviewId: input.reviewId, deleted: true };
      },
    );
  }
  setTarget(
    who: ReviewIdentity,
    reviewId: string,
    selected: LocalTarget,
    m: Mutation,
  ) {
    operator(who);
    this.own(who, reviewId);
    target(selected);
    return this.mutation(
      who,
      m,
      "setTarget",
      { reviewId, selected, version: m.expectedVersion },
      () => {
        const review = this.own(who, reviewId);
        version(review.version, m.expectedVersion);
        this.database.run(
          "UPDATE reviews SET target_json=?,version=version+1,updated_at=? WHERE id=?",
          JSON.stringify(selected),
          now(),
          reviewId,
        );
        this.event(who, reviewId, "review.target", { selected });
        return { reviewId, version: review.version + 1 };
      },
    );
  }
  capture(
    who: ReviewIdentity,
    reviewId: string,
    capture: SourceCapture,
    m: Mutation,
  ) {
    operator(who);
    const review = this.own(who, reviewId);
    if (
      review.workspace_id !== capture.workspaceId ||
      review.worktree_id !== capture.worktreeId
    )
      throw new ReviewError(
        "scope_mismatch",
        "Source does not belong to the review workspace/worktree.",
        409,
      );
    if (
      !["source", "staged", "unstaged", "commit"].includes(capture.mode) ||
      (capture.mode === "source" && !capture.files.length) ||
      capture.files.length > LIMITS.captureFiles
    )
      throw new ReviewError("limit", "Invalid or oversized source capture.");
    let bytes = 0;
    for (const file of capture.files) {
      for (const text of [file.oldText, file.newText])
        if (text !== null) {
          boundedText(text, "source", LIMITS.fileBytes, true);
          bytes += Buffer.byteLength(text);
          if (text.split("\n").length > LIMITS.fileLines)
            throw new ReviewError("limit", "Source exceeds line limit.");
        }
      for (const path of [file.oldPath, file.newPath])
        if (path !== null) boundedText(path, "path", 4096);
    }
    if (bytes > LIMITS.captureBytes)
      throw new ReviewError("limit", "Capture exceeds total byte limit.");
    return this.mutation(who, m, "capture", { reviewId, capture }, () => {
      const snapshotId = id("snapshot"),
        files: string[] = [];
      this.database.run(
        "INSERT INTO snapshots VALUES(?,?,?,?,?,?,?)",
        snapshotId,
        reviewId,
        capture.mode,
        capture.base,
        capture.head,
        capture.capturedAt,
        hashText(stableJson(capture)),
      );
      for (const file of capture.files) {
        const hashes = [file.oldText, file.newText].map((text) => {
          if (text === null) return null;
          const hash = hashText(text);
          this.database.run(
            "INSERT OR IGNORE INTO blobs VALUES(?,?,?,?)",
            reviewId,
            hash,
            text,
            Buffer.byteLength(text),
          );
          return hash;
        });
        const fileId = id("file");
        files.push(fileId);
        this.database.run(
          "INSERT INTO snapshot_files VALUES(?,?,?,?,?,?,?,?,?)",
          fileId,
          snapshotId,
          reviewId,
          file.oldPath,
          file.newPath,
          file.change,
          hashes[0],
          hashes[1],
          file.fileIdentity ?? null,
        );
      }
      this.event(who, reviewId, "snapshot.created", { snapshotId, files });
      return { snapshotId, files };
    });
  }
  addFile(
    who: ReviewIdentity,
    reviewId: string,
    snapshotId: string,
    capture: SourceCapture,
    m: Mutation,
  ) {
    operator(who);
    this.own(who, reviewId);
    if (capture.mode !== "source" || capture.files.length !== 1)
      throw new ReviewError(
        "invalid_input",
        "Add file requires one saved source file.",
      );
    const snap = this.database.get<{ mode: string }>(
      "SELECT mode FROM snapshots WHERE id=? AND review_id=?",
      snapshotId,
      reviewId,
    );
    if (!snap) return this.missing();
    if (snap.mode !== "source")
      throw new ReviewError(
        "invalid_input",
        "Add file is available for saved-source reviews only.",
      );
    return this.mutation(
      who,
      m,
      "addFile",
      { reviewId, snapshotId, capture },
      () => {
        const previous = this.snapshotFiles(who, reviewId, snapshotId).map(
          (f) => {
            const full = this.readFile(who, reviewId, f.id);
            return {
              oldPath: full.old_path,
              newPath: full.new_path,
              oldText: full.oldText,
              newText: full.newText,
              change: "source" as const,
              fileIdentity: full.file_identity,
            };
          },
        );
        const path = capture.files[0]!.newPath;
        if (previous.some((f) => f.newPath === path))
          throw new ReviewError(
            "conflict",
            "File already belongs to this snapshot.",
            409,
          );
        return this.capture(
          who,
          reviewId,
          { ...capture, files: [...previous, ...capture.files] },
          { requestId: m.requestId + "/capture" },
        );
      },
    );
  }
  listSnapshots(who: ReviewIdentity, reviewId: string, limit?: number) {
    operator(who);
    this.own(who, reviewId);
    return this.database.all(
      "SELECT * FROM snapshots WHERE review_id=? ORDER BY captured_at DESC,id DESC LIMIT ?",
      reviewId,
      pageSize(limit, LIMITS.threadPage),
    );
  }
  snapshotFiles(who: ReviewIdentity, reviewId: string, snapshotId: string) {
    operator(who);
    this.own(who, reviewId);
    return this.database.all<SnapshotFileRecord>(
      "SELECT * FROM snapshot_files WHERE review_id=? AND snapshot_id=? ORDER BY COALESCE(new_path,old_path),id",
      reviewId,
      snapshotId,
    );
  }
  readFile(who: ReviewIdentity, reviewId: string, fileId: string) {
    operator(who);
    const file = this.file(who, reviewId, fileId);
    const read = (hash: string | null) =>
      hash
        ? (this.database.get<{ text: string }>(
            "SELECT text FROM blobs WHERE review_id=? AND hash=?",
            reviewId,
            hash,
          )?.text ?? null)
        : null;
    return {
      ...file,
      oldText: read(file.old_hash),
      newText: read(file.new_hash),
    };
  }
  private trimSummaryBody(body: string): string {
    return Array.from(body).slice(0, 240).join("");
  }
  private anchorFilePath(reviewId: string, anchor: OriginalAnchor): string | null {
    const file = this.database.get<{
      old_path: string | null;
      new_path: string | null;
    }>(
      "SELECT old_path,new_path FROM snapshot_files WHERE review_id=? AND id=?",
      reviewId,
      anchor.snapshotFileId,
    );
    if (!file) return this.missing();
    return anchor.side === "old" ? file.old_path : file.new_path ?? file.old_path;
  }
  protected summaryForThread(thread: ThreadRecord, anchor: OriginalAnchor): ThreadSummary {
    const first = this.database.get<{
      body: string | null;
      author_kind: "operator" | "agent" | null;
      author_id: string;
    }>(
      "SELECT substr(r.body,1,240) AS body,m.author_kind,m.author_id FROM messages m JOIN message_revisions r ON r.message_id=m.id AND r.version=m.version WHERE m.thread_id=? AND m.deleted=0 AND r.body IS NOT NULL ORDER BY m.ordinal LIMIT 1",
      thread.id,
    );
    const counts = this.database.get<{ message_count: number }>(
      "SELECT COUNT(*) AS message_count FROM messages WHERE thread_id=? AND deleted=0",
      thread.id,
    );
    const selected = JSON.parse(thread.target_json) as LocalTarget;
    const dispatch = this.database.get<{
      dispatch_id: string;
      work_state: WorkState;
      delivery_state: DeliveryState;
    }>(
      "SELECT i.dispatch_id,i.work_state,a.state AS delivery_state FROM dispatch_items i JOIN dispatches d ON d.id=i.dispatch_id AND d.review_id=i.review_id JOIN attempts a ON a.dispatch_id=d.id AND a.number=(SELECT MAX(number) FROM attempts WHERE dispatch_id=d.id) WHERE i.thread_id=? AND i.assignment_epoch=? AND json_extract(d.target_json,'$.chatId')=? AND json_extract(d.target_json,'$.incarnation')=? ORDER BY d.rowid DESC LIMIT 1",
      thread.id,
      thread.assignment_epoch,
      selected.chatId,
      selected.incarnation,
    );
    return {
      body: first?.body ? this.trimSummaryBody(first.body) : null,
      authorKind: first?.author_kind ?? null,
      authorId: first?.author_id ?? null,
      unsent: thread.state === 'open' && (!dispatch || dispatch.delivery_state === 'rejected'
        || this.hasNewGuidance(thread.id, dispatch.dispatch_id) || ['failed','superseded'].includes(dispatch.work_state)),
      outstanding: Boolean(dispatch && (['prepared','attempting','unknown'].includes(dispatch.delivery_state)
        || (dispatch.delivery_state === 'accepted' && !this.hasNewGuidance(thread.id, dispatch.dispatch_id)
          && ['not_started','in_progress','waiting_user','blocked'].includes(dispatch.work_state)))),
      messageCount: counts?.message_count ?? 0,
      filePath: this.anchorFilePath(thread.review_id, anchor),
      deliveryState: dispatch?.delivery_state ?? null,
      dispatchId: dispatch?.dispatch_id ?? null,
      workState: dispatch?.work_state ?? null,
      hasUnsentGuidance: !dispatch || this.hasNewGuidance(thread.id, dispatch.dispatch_id),
    };
  }
  private resolutionByMessage(
    reviewId: string,
    threadId: string,
    messageIds: string[],
  ): Map<string, MessageResolution> {
    const resolutions = new Map<string, MessageResolution>();
    if (!messageIds.length) return resolutions;
    const placeholders = messageIds.map(() => "?").join(",");
    const rows = this.database.all<{
      message_id: string;
      data_json: string;
    }>(
      `SELECT json_extract(data_json,'$.messageId') AS message_id,data_json
       FROM events
       WHERE review_id=? AND thread_id=? AND kind='thread.resolved'
         AND json_extract(data_json,'$.messageId') IN (${placeholders})`,
      reviewId,
      threadId,
      ...messageIds,
    );
    for (const row of rows) {
      const data = JSON.parse(row.data_json) as {
        fileId?: unknown;
        evidence?: unknown;
        addressedVersion?: unknown;
      };
      if (
        typeof data.fileId !== "string" ||
        !Number.isSafeInteger(data.addressedVersion) ||
        !Array.isArray(data.evidence) ||
        data.evidence.some((entry) => typeof entry !== "string")
      )
        continue;
      const addressedVersion = data.addressedVersion as number;
      resolutions.set(row.message_id, {
        fileId: data.fileId,
        evidence: [...data.evidence],
        addressedVersion,
      });
    }
    return resolutions;
  }
  private append(who: ReviewIdentity, thread: ThreadRecord, body: string) {
    const messageId = id("message"),
      time = now();
    const last = this.database.get<{ n: number }>(
      "SELECT COALESCE(MAX(ordinal),0) AS n FROM messages WHERE thread_id=?",
      thread.id,
    )!;
    this.database.run(
      "INSERT INTO messages VALUES(?,?,?,?,?,?,1,0,?,?)",
      messageId,
      thread.id,
      thread.review_id,
      last.n + 1,
      who.actorId,
      who.kind,
      time,
      time,
    );
    this.database.run(
      "INSERT INTO message_revisions VALUES(?,1,?,?)",
      messageId,
      body,
      time,
    );
    return messageId;
  }
  private advance(thread: ThreadRecord) {
    this.database.run(
      "UPDATE threads SET version=version+1,updated_at=? WHERE id=?",
      now(),
      thread.id,
    );
  }
  createThread(
    who: ReviewIdentity,
    reviewId: string,
    input: {
      fileId: string;
      side: "source" | "old" | "new";
      range?: { startLine: number; endLine: number };
      body: string;
    },
    m: Mutation,
  ) {
    operator(who);
    this.own(who, reviewId);
    boundedText(input.body, "comment");
    return this.mutation(who, m, "createThread", { reviewId, input }, () => {
      const review = this.own(who, reviewId),
        file = this.file(who, reviewId, input.fileId),
        anchor = createAnchor(
          file.id,
          input.side,
          this.source(file, input.side),
          input.range,
        );
      const threadId = id("thread"),
        time = now();
      this.database.run(
        "INSERT INTO threads VALUES(?,?,?,'open',?,1,1,?,?)",
        threadId,
        reviewId,
        JSON.stringify(anchor),
        review.target_json,
        time,
        time,
      );
      const thread = this.thread(who, threadId),
        messageId = this.append(who, thread, input.body);
      this.event(
        who,
        reviewId,
        "thread.created",
        { messageId, version: 1 },
        threadId,
      );
      return { threadId, messageId, version: 1 };
    });
  }
  listThreads(
    who: ReviewIdentity,
    reviewId: string,
    options: { state?: string; after?: string; limit?: number } = {},
  ) {
    const scope = this.dispatchScope(who);
    if (scope) {
      if (scope.reviewId !== reviewId) return [];
    } else {
      this.own(who, reviewId);
    }
    const rows = scope
      ? this.database.all<ThreadRecord>(
          "SELECT t.* FROM dispatch_items i JOIN threads t ON t.id=i.thread_id AND t.review_id=i.review_id WHERE i.dispatch_id=? AND i.review_id=? AND t.state!='deleted' AND t.id>? AND (? IS NULL OR t.state=?) AND json_extract(t.target_json,'$.chatId')=? AND json_extract(t.target_json,'$.incarnation')=? AND t.assignment_epoch=i.assignment_epoch ORDER BY t.id LIMIT ?",
          scope.dispatchId,
          reviewId,
          options.after ?? "",
          options.state ?? null,
          options.state ?? null,
          who.chatId ?? "",
          who.chatIncarnation ?? "",
          pageSize(options.limit, LIMITS.threadPage),
        )
      : this.database.all<ThreadRecord>(
          "SELECT * FROM threads WHERE review_id=? AND state!='deleted' AND id>? AND (? IS NULL OR state=?) AND (?='operator' OR (json_extract(target_json,'$.chatId')=? AND json_extract(target_json,'$.incarnation')=?)) ORDER BY id LIMIT ?",
          reviewId,
          options.after ?? "",
          options.state ?? null,
          options.state ?? null,
          who.kind,
          who.chatId ?? "",
          who.chatIncarnation ?? "",
          pageSize(options.limit, LIMITS.threadPage),
        );
    return rows.map((row) => {
      const anchor = JSON.parse(row.anchor_json) as OriginalAnchor;
      return {
        ...row,
        anchor,
        target: JSON.parse(row.target_json),
        summary: this.summaryForThread(row, anchor),
      };
    });
  }
  getThread(who: ReviewIdentity, threadId: string, after = 0, limit?: number) {
    if (!Number.isSafeInteger(after) || after < 0)
      throw new ReviewError("invalid_input", "Invalid message cursor.");
    const thread = this.thread(who, threadId),
      anchor = JSON.parse(thread.anchor_json) as OriginalAnchor;
    const messages = this.database.all<MessageRecord & { body: string | null }>(
      "SELECT m.*,r.body FROM messages m JOIN message_revisions r ON r.message_id=m.id AND r.version=m.version WHERE m.thread_id=? AND m.ordinal>? ORDER BY m.ordinal LIMIT ?",
      thread.id,
      after,
      pageSize(limit, LIMITS.historyPage),
    );
    const resolutions = this.resolutionByMessage(
      thread.review_id,
      thread.id,
      messages.map((message) => message.id),
    );
    const file = this.file(who, thread.review_id, anchor.snapshotFileId);
    return {
      ...thread,
      anchor,
      target: JSON.parse(thread.target_json),
      messages: messages.map((message) => {
        if (message.deleted) return message;
        const resolution = resolutions.get(message.id);
        return resolution ? { ...message, resolution } : message;
      }),
      source: {
        fileId: file.id,
        snapshotId: file.snapshot_id,
        oldPath: file.old_path,
        newPath: file.new_path,
        blobSha256: anchor.blobSha256,
        fileIdentity: file.file_identity,
        selectedText: anchor.selectedText,
        contextBefore: anchor.contextBefore,
        contextAfter: anchor.contextAfter,
      },
    };
  }
  messageThreadId(messageId: string): string | null {
    validId(messageId, "message ID");
    return (
      this.database.get<{ thread_id: string }>(
        "SELECT thread_id FROM messages WHERE id=?",
        messageId,
      )?.thread_id ?? null
    );
  }
  reply(
    who: ReviewIdentity,
    threadId: string,
    body: string,
    m: Mutation,
    assignmentEpoch?: number,
    reopen = false,
  ) {
    this.thread(who, threadId);
    boundedText(body, "reply");
    return this.mutation(
      who,
      m,
      "reply",
      { threadId, body, version: m.expectedVersion, assignmentEpoch, reopen },
      () => {
        const thread = this.thread(who, threadId);
        version(thread.version, m.expectedVersion);
        this.epoch(who, thread, assignmentEpoch);
        if (thread.state === "resolved") {
          if (!reopen || who.kind !== "operator")
            throw new ReviewError(
              "resolved",
              "Explicit reopen-and-post required.",
              409,
            );
          this.database.run(
            "UPDATE threads SET state='open' WHERE id=?",
            threadId,
          );
          this.event(who, thread.review_id, "thread.reopened", {}, threadId);
        }
        const messageId = this.append(who, thread, body);
        this.advance(thread);
        this.event(
          who,
          thread.review_id,
          "message.created",
          { messageId, version: thread.version + 1 },
          threadId,
        );
        return { threadId, messageId, version: thread.version + 1 };
      },
    );
  }
  editMessage(
    who: ReviewIdentity,
    messageId: string,
    body: string | null,
    m: Mutation,
    assignmentEpoch?: number,
  ) {
    const message = this.database.get<MessageRecord>(
      "SELECT * FROM messages WHERE id=?",
      messageId,
    );
    if (!message) return this.missing();
    this.thread(who, message.thread_id, true);
    if (message.author_id !== who.actorId || message.author_kind !== who.kind)
      throw new ReviewError(
        "forbidden",
        "Only the message author can change it.",
        403,
      );
    if (body !== null) boundedText(body, "comment");
    return this.mutation(
      who,
      m,
      body === null ? "deleteMessage" : "editMessage",
      { messageId, body, version: m.expectedVersion, assignmentEpoch },
      () => {
        const current = this.database.get<MessageRecord>(
          "SELECT * FROM messages WHERE id=?",
          messageId,
        )!;
        const thread = this.thread(who, current.thread_id);
        this.epoch(who, thread, assignmentEpoch);
        version(current.version, m.expectedVersion);
        if (current.deleted)
          throw new ReviewError("deleted", "Message was deleted.", 409);
        if (body === null)
          this.database.run(
            "UPDATE message_revisions SET body=NULL WHERE message_id=?",
            messageId,
          );
        this.database.run(
          "INSERT INTO message_revisions VALUES(?,?,?,?)",
          messageId,
          current.version + 1,
          body,
          now(),
        );
        this.database.run(
          "UPDATE messages SET version=version+1,deleted=?,updated_at=? WHERE id=?",
          body === null ? 1 : 0,
          now(),
          messageId,
        );
        this.advance(thread);
        this.event(
          who,
          thread.review_id,
          body === null ? "message.deleted" : "message.edited",
          { messageId, version: current.version + 1 },
          thread.id,
        );
        return {
          messageId,
          version: current.version + 1,
          threadVersion: thread.version + 1,
        };
      },
    );
  }
  resolveThread(
    who: ReviewIdentity,
    threadId: string,
    input: {
      explanation: string;
      evidence?: string[];
      fileId: string;
      assignmentEpoch?: number;
    },
    m: Mutation,
  ) {
    this.thread(who, threadId);
    boundedText(input.explanation ?? '', "resolution explanation", LIMITS.commentBytes, who.kind === 'operator');
    if (
      input.evidence &&
      (input.evidence.length > 10 ||
        input.evidence.some(
          (s) =>
            typeof s !== "string" ||
            s.length > 2048 ||
            /^(?:javascript|data):/i.test(s),
        ))
    )
      throw new ReviewError("invalid_input", "Invalid evidence references.");
    return this.mutation(
      who,
      m,
      "resolve",
      { threadId, input, version: m.expectedVersion },
      () => {
        const thread = this.thread(who, threadId);
        version(thread.version, m.expectedVersion);
        this.epoch(who, thread, input.assignmentEpoch);
        this.file(who, thread.review_id, input.fileId);
        const projection = this.project(who, threadId, input.fileId);
        if (!["exact", "moved"].includes(projection.status))
          throw new ReviewError(
            "stale_source",
            "Resolution requires a verified source mapping; inspect or explicitly re-anchor first.",
            409,
          );
        if (thread.state !== "open")
          throw new ReviewError("resolved", "Thread is already resolved.", 409);
        const explanation = who.kind === 'operator' && !input.explanation?.trim() ? null : input.explanation;
        const messageId = explanation === null ? null : this.append(who, thread, explanation);
        this.database.run(
          "UPDATE threads SET state='resolved',version=version+1,updated_at=? WHERE id=?",
          now(),
          threadId,
        );
        this.event(
          who,
          thread.review_id,
          "thread.resolved",
          {
            messageId,
            fileId: input.fileId,
            evidence: input.evidence ?? [],
            addressedVersion: thread.version,
          },
          threadId,
        );
        return { threadId, messageId, version: thread.version + 1 };
      },
    );
  }
  reopen(who: ReviewIdentity, threadId: string, m: Mutation) {
    operator(who);
    this.thread(who, threadId);
    return this.mutation(
      who,
      m,
      "reopen",
      { threadId, version: m.expectedVersion },
      () => {
        const thread = this.thread(who, threadId);
        version(thread.version, m.expectedVersion);
        if (thread.state !== "resolved")
          throw new ReviewError(
            "conflict",
            "Only resolved threads can be reopened.",
            409,
          );
        this.database.run(
          "UPDATE threads SET state='open',version=version+1,updated_at=? WHERE id=?",
          now(),
          threadId,
        );
        this.event(who, thread.review_id, "thread.reopened", {}, threadId);
        return { threadId, version: thread.version + 1 };
      },
    );
  }
  reassign(
    who: ReviewIdentity,
    threadId: string,
    selected: LocalTarget,
    m: Mutation,
  ) {
    operator(who);
    this.thread(who, threadId);
    target(selected);
    return this.mutation(
      who,
      m,
      "reassign",
      { threadId, selected, version: m.expectedVersion },
      () => {
        const thread = this.thread(who, threadId);
        version(thread.version, m.expectedVersion);
        this.database.run(
          "UPDATE threads SET target_json=?,assignment_epoch=assignment_epoch+1,version=version+1,updated_at=? WHERE id=?",
          JSON.stringify(selected),
          now(),
          threadId,
        );
        this.event(
          who,
          thread.review_id,
          "thread.reassigned",
          { target: selected, epoch: thread.assignment_epoch + 1 },
          threadId,
        );
        return {
          threadId,
          version: thread.version + 1,
          assignmentEpoch: thread.assignment_epoch + 1,
        };
      },
    );
  }
  deleteThread(who: ReviewIdentity, threadId: string, m: Mutation) {
    operator(who);
    this.thread(who, threadId, true);
    return this.mutation(
      who,
      m,
      "deleteThread",
      { threadId, version: m.expectedVersion },
      () => {
        const thread = this.thread(who, threadId);
        version(thread.version, m.expectedVersion);
        this.database.run(
          "UPDATE message_revisions SET body=NULL WHERE message_id IN (SELECT id FROM messages WHERE thread_id=?)",
          threadId,
        );
        this.database.run(
          "UPDATE messages SET deleted=1 WHERE thread_id=?",
          threadId,
        );
        this.database.run("DELETE FROM drafts WHERE thread_id=?", threadId);
        this.database.run(
          "UPDATE threads SET state='deleted',version=version+1,updated_at=? WHERE id=?",
          now(),
          threadId,
        );
        this.event(
          who,
          thread.review_id,
          "thread.deleted",
          { version: thread.version + 1 },
          threadId,
        );
        return { threadId, version: thread.version + 1 };
      },
    );
  }
  saveDraft(
    who: ReviewIdentity,
    reviewId: string,
    input: {
      id?: string;
      threadId?: string;
      anchor?: OriginalAnchor;
      body: string;
    },
    m: Mutation,
  ) {
    operator(who);
    this.own(who, reviewId);
    boundedText(input.body, "draft", LIMITS.commentBytes, true);
    return this.mutation(
      who,
      m,
      "saveDraft",
      { reviewId, input, version: m.expectedVersion },
      () => {
        if (input.threadId) {
          const t = this.thread(who, input.threadId);
          if (t.review_id !== reviewId) this.missing();
        } else if (input.anchor) {
          const f = this.file(who, reviewId, input.anchor.snapshotFileId);
          const checked = createAnchor(
            f.id,
            input.anchor.side,
            this.source(f, input.anchor.side),
            input.anchor.scope === "file"
              ? undefined
              : {
                  startLine: input.anchor.startLine!,
                  endLine: input.anchor.endLine!,
                },
          );
          if (stableJson(checked) !== stableJson(input.anchor))
            throw new ReviewError(
              "invalid_anchor",
              "Draft anchor must match source.",
            );
        } else
          throw new ReviewError(
            "invalid_anchor",
            "Draft requires a thread or source anchor.",
          );
        const draftId = input.id ?? id("draft"),
          old = this.database.get<{
            version: number;
            owner_id: string;
            review_id: string;
          }>("SELECT * FROM drafts WHERE id=?", draftId);
        if (old) {
          if (old.owner_id !== who.ownerId || old.review_id !== reviewId)
            this.missing();
          version(old.version, m.expectedVersion);
        } else if (
          input.id ||
          (m.expectedVersion !== undefined && m.expectedVersion !== 0)
        )
          this.missing();
        if (old) {
          const binding = this.database.get<{
            thread_id: string | null;
            anchor_json: string | null;
          }>("SELECT thread_id,anchor_json FROM drafts WHERE id=?", draftId)!;
          if (
            binding.thread_id !== (input.threadId ?? null) ||
            binding.anchor_json !==
              (input.anchor ? JSON.stringify(input.anchor) : null)
          )
            throw new ReviewError(
              "conflict",
              "Draft anchor and reply target cannot silently change.",
              409,
            );
        }
        this.database.run(
          "INSERT INTO drafts VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET body=excluded.body,version=excluded.version,updated_at=excluded.updated_at",
          draftId,
          who.ownerId,
          reviewId,
          input.threadId ?? null,
          input.anchor ? JSON.stringify(input.anchor) : null,
          input.body,
          (old?.version ?? 0) + 1,
          now(),
        );
        return { draftId, version: (old?.version ?? 0) + 1 };
      },
    );
  }
  listDrafts(who: ReviewIdentity, reviewId: string) {
    operator(who);
    this.own(who, reviewId);
    return this.database.all(
      "SELECT * FROM drafts WHERE owner_id=? AND review_id=? ORDER BY updated_at DESC LIMIT ?",
      who.ownerId,
      reviewId,
      LIMITS.historyPage,
    );
  }
  makeAnchor(
    who: ReviewIdentity,
    reviewId: string,
    fileId: string,
    side: "source" | "old" | "new",
    range?: { startLine: number; endLine: number },
  ) {
    operator(who);
    const file = this.file(who, reviewId, fileId);
    return createAnchor(file.id, side, this.source(file, side), range);
  }
  deleteDraft(
    who: ReviewIdentity,
    reviewId: string,
    draftId: string,
    m: Mutation,
  ) {
    operator(who);
    this.own(who, reviewId);
    return this.mutation(
      who,
      m,
      "deleteDraft",
      { reviewId, draftId, version: m.expectedVersion },
      () => {
        const draft = this.database.get<{ version: number }>(
          "SELECT version FROM drafts WHERE id=? AND review_id=? AND owner_id=?",
          draftId,
          reviewId,
          who.ownerId,
        );
        if (!draft) return this.missing();
        version(draft.version, m.expectedVersion);
        this.database.run("DELETE FROM drafts WHERE id=?", draftId);
        return { draftId, deleted: true };
      },
    );
  }
  project(who: ReviewIdentity, threadId: string, fileId: string) {
    const thread = this.thread(who, threadId),
      anchor = JSON.parse(thread.anchor_json) as OriginalAnchor;
    const previous = this.file(who, thread.review_id, anchor.snapshotFileId),
      current = this.file(who, thread.review_id, fileId);
    const manual = this.database.get<{ projection_json: string }>(
      "SELECT projection_json FROM projections WHERE thread_id=? AND snapshot_file_id=?",
      threadId,
      fileId,
    );
    if (manual) return JSON.parse(manual.projection_json);
    const samePath =
      (previous.new_path || previous.old_path) ===
      (current.new_path || current.old_path);
    const rename =
      current.change_kind === "renamed" &&
      current.old_path === (previous.new_path || previous.old_path) &&
      previous.new_hash !== null &&
      current.old_hash === previous.new_hash;
    const sameFile =
      previous.id === current.id ||
      rename ||
      (samePath &&
        previous.file_identity != null &&
        current.file_identity != null &&
        previous.file_identity === current.file_identity);
    let text: string;
    try {
      const side = anchor.side === "source" && current.change_kind !== "source" && current.change_kind !== "unchanged" ? "new" : anchor.side;
      text = this.source(current, side);
    } catch {
      return {
        status: "missing",
        startLine: null,
        endLine: null,
        method: "unmapped",
      };
    }
    const projection = projectAnchor(anchor, text, { sameFile });
    return { ...projection, side: anchor.side === "source" && current.change_kind !== "source" && current.change_kind !== "unchanged" ? "new" : anchor.side };
  }
  reanchor(
    who: ReviewIdentity,
    threadId: string,
    input: {
      fileId: string;
      side: "source" | "old" | "new";
      range?: { startLine: number; endLine: number };
      reopen?: boolean;
    },
    m: Mutation,
  ) {
    operator(who);
    this.thread(who, threadId);
    return this.mutation(
      who,
      m,
      "reanchor",
      { threadId, input, version: m.expectedVersion },
      () => {
        const thread = this.thread(who, threadId);
        version(thread.version, m.expectedVersion);
        if (thread.state === "resolved" && !input.reopen)
          throw new ReviewError(
            "resolved",
            "Confirm reopen-and-re-anchor first.",
            409,
          );
        const file = this.file(who, thread.review_id, input.fileId),
          anchor = createAnchor(
            file.id,
            input.side,
            this.source(file, input.side),
            input.range,
          );
        const projection = {
          status: "moved",
          startLine: anchor.startLine,
          endLine: anchor.endLine,
          method: "manual",
          side: anchor.side,
          scope: anchor.scope,
        };
        this.database.run(
          "INSERT INTO projections VALUES(?,?,?,?,?,?) ON CONFLICT(thread_id,snapshot_file_id) DO UPDATE SET projection_json=excluded.projection_json,actor_id=excluded.actor_id,created_at=excluded.created_at",
          threadId,
          thread.review_id,
          file.id,
          JSON.stringify(projection),
          who.actorId,
          now(),
        );
        this.database.run(
          "UPDATE threads SET state='open',version=version+1,updated_at=? WHERE id=?",
          now(),
          threadId,
        );
        this.event(
          who,
          thread.review_id,
          "thread.reanchored",
          {
            fileId: file.id,
            projection,
            reopened: thread.state === "resolved",
          },
          threadId,
        );
        return { threadId, version: thread.version + 1 };
      },
    );
  }
  events(who: ReviewIdentity, reviewId: string, after = 0, limit?: number) {
    operator(who);
    this.own(who, reviewId);
    if (!Number.isSafeInteger(after) || after < 0)
      throw new ReviewError("invalid_input", "Invalid event cursor.");
    return this.database.all(
      "SELECT * FROM events WHERE review_id=? AND cursor>? ORDER BY cursor LIMIT ?",
      reviewId,
      after,
      pageSize(limit, LIMITS.historyPage),
    );
  }
}
