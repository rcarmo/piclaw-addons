import { afterEach, describe, expect, test } from "bun:test";

import {
  requestProxmoxApi,
  resolveProxmoxToken,
  setProxmoxCurlExecutorForTests,
} from "./client.js";
import { listKeychainEntries } from "./compat/keychain.js";

afterEach(() => {
  setProxmoxCurlExecutorForTests(null);
  delete (globalThis as { __piclawRuntimeInterop?: unknown }).__piclawRuntimeInterop;
});

describe("proxmox client auth", () => {
  test("listKeychainEntries preserves canonical names from runtime metadata", () => {
    (globalThis as { __piclawRuntimeInterop?: { listKeychainEntries?: () => unknown } }).__piclawRuntimeInterop = {
      listKeychainEntries: () => [
        { name: "proxmox/piclaw-management-token", type: "token" },
        { name: "proxmox/piclaw-management-token", type: "token" },
        { name: "other/service", type: "secret" },
      ],
    };

    expect(listKeychainEntries()).toEqual([
      { name: "proxmox/piclaw-management-token", type: "token" },
      { name: "other/service", type: "secret" },
    ]);
  });

  test("resolveProxmoxToken combines configured username with a raw keychain secret", async () => {
    (globalThis as { __piclawRuntimeInterop?: { getKeychainEntry?: (name: string) => Promise<unknown> } }).__piclawRuntimeInterop = {
      getKeychainEntry: async (name: string) => ({
        name,
        type: "secret",
        secret: "f1630-uuid-token",
      }),
    };

    await expect(resolveProxmoxToken("root@pam!piclaw", "proxmox/piclaw-management-token")).resolves.toEqual({
      username: "root@pam!piclaw",
      secret: "f1630-uuid-token",
    });
  });

  test("requestProxmoxApi uses the configured username in the authorization header", async () => {
    (globalThis as { __piclawRuntimeInterop?: { getKeychainEntry?: (name: string) => Promise<unknown> } }).__piclawRuntimeInterop = {
      getKeychainEntry: async (name: string) => ({
        name,
        type: "secret",
        secret: "f1630-uuid-token",
      }),
    };

    let capturedCommand: string[] = [];
    setProxmoxCurlExecutorForTests(async (command) => {
      capturedCommand = command;
      return {
        exitCode: 0,
        stdout: '{"data":{"version":"9.1.7"}}\n__PICLAW_PROXMOX_STATUS__:200',
        stderr: "",
      };
    });

    const response = await requestProxmoxApi(
      {
        base_url: "https://borg.local:8006/api2/json",
        username: "root@pam!piclaw",
        api_token_keychain: "proxmox/piclaw-management-token",
        allow_insecure_tls: true,
      },
      {
        method: "GET",
        path: "/version",
      },
    );

    expect(response.status).toBe(200);
    expect(capturedCommand).toEqual(expect.arrayContaining([
      "-H",
      "Authorization: PVEAPIToken=root@pam!piclaw=f1630-uuid-token",
    ]));
  });

  test("requestProxmoxApi times out hung curl executors", async () => {
    (globalThis as { __piclawRuntimeInterop?: { getKeychainEntry?: (name: string) => Promise<unknown> } }).__piclawRuntimeInterop = {
      getKeychainEntry: async (name: string) => ({
        name,
        type: "secret",
        secret: "f1630-uuid-token",
      }),
    };

    setProxmoxCurlExecutorForTests(async () => new Promise(() => {}));

    await expect(requestProxmoxApi(
      {
        base_url: "https://borg.local:8006/api2/json",
        username: "root@pam!piclaw",
        api_token_keychain: "proxmox/piclaw-management-token",
        allow_insecure_tls: true,
      },
      {
        method: "GET",
        path: "/version",
        timeout_ms: 5,
      },
    )).rejects.toThrow("Proxmox request GET /version timed out after 1000ms");
  });

  test("requestProxmoxApi passes a hard timeout to the curl executor", async () => {
    (globalThis as { __piclawRuntimeInterop?: { getKeychainEntry?: (name: string) => Promise<unknown> } }).__piclawRuntimeInterop = {
      getKeychainEntry: async (name: string) => ({
        name,
        type: "secret",
        secret: "f1630-uuid-token",
      }),
    };

    let capturedTimeout = 0;
    setProxmoxCurlExecutorForTests(async (_command, timeoutMs) => {
      capturedTimeout = timeoutMs ?? 0;
      return {
        exitCode: 0,
        stdout: '{"data":{"version":"9.1.7"}}\n__PICLAW_PROXMOX_STATUS__:200',
        stderr: "",
      };
    });

    await requestProxmoxApi(
      {
        base_url: "https://borg.local:8006/api2/json",
        username: "root@pam!piclaw",
        api_token_keychain: "proxmox/piclaw-management-token",
        allow_insecure_tls: true,
      },
      {
        method: "GET",
        path: "/version",
        timeout_ms: 12_345,
      },
    );

    expect(capturedTimeout).toBe(13_345);
  });
});
