/**
 * delegate.ts — Delegate tasks to a verified cheaper/faster child Pi model.
 *
 * Runs an ephemeral `pi --mode json --no-session` subprocess with a bounded
 * tool profile, parses structured progress/results, and returns the response
 * inline. Automatic selection is deterministic and tier-capped by the current
 * classified model.
 */
import { spawn as nodeSpawn } from "node:child_process";
import { closeSync, existsSync, openSync, readFileSync, readSync, realpathSync, statSync } from "node:fs";
import { delimiter, dirname, isAbsolute, relative, resolve, join, sep, win32 } from "node:path";
import { createRequire } from "node:module";
import { StringDecoder } from "node:string_decoder";
import { fileURLToPath } from "node:url";

import { createExtensionStorage, type ExtensionStorage } from "./compat/extension-kv.js";

const DEFAULT_TIMEOUT_SEC = 120;
const MAX_OUTPUT_CHARS = 50_000;
const DELEGATE_STATUS_KEY = "delegate";
const MAX_TEXT_FILE_BYTES = 100_000; // 100KB limit for text file inlining
const ADDON_DIR = dirname(fileURLToPath(import.meta.url));

export function getDelegateWorkspaceRoot(
  env: Record<string, string | undefined> = process.env,
  cwd = process.cwd(),
): string {
  const candidate = resolve(env.PICLAW_WORKSPACE || cwd);
  try {
    return realpathSync(candidate);
  } catch {
    return candidate;
  }
}

const DELEGATE_STATUS_ICON_SVG = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M16 3h5v5"></path><path d="M21 3l-7 7"></path><path d="M8 21H3v-5"></path><path d="M3 21l7-7"></path><circle cx="12" cy="12" r="3"></circle></svg>`;

const EXTENSION_ID = "delegate";
const AZURE_PROVIDER_RE = /^azure-/i;
const DEFAULT_SEARCHABLE_PROVIDER_ORDER = ["github-copilot", "anthropic", "openai", "google", "openai-codex", "cerebras", "ollama"];

export interface DelegateConfig {
  /** Operator-approved providers. null and [] both mean approve none (fail closed). */
  searchable_providers: string[] | null;
  /** Additional explicit provider denials. null = default exclusions; [] = no extra denials. */
  excluded_providers: string[] | null;
  /** Model id/full-id exclusion patterns. Supports `*` wildcards and substring fallback. */
  excluded_models: string[];
}

const DEFAULT_CONFIG: DelegateConfig = {
  searchable_providers: null, // fail closed until an operator approves providers in Settings
  excluded_providers: null,
  excluded_models: [],
};

let storage: ExtensionStorage | null = null;
function kv(): ExtensionStorage {
  if (!storage) storage = createExtensionStorage(EXTENSION_ID);
  return storage;
}

function normalizeStringList(values: unknown): string[] | null {
  if (values == null) return null;
  const source = Array.isArray(values)
    ? values
    : (typeof values === "string" ? values.split(/[\n,]+/) : []);
  return [...new Set(source
    .map((value) => typeof value === "string" ? value.trim() : "")
    .filter(Boolean))];
}

function normalizeProviderList(values: unknown): string[] | null {
  return normalizeStringList(values);
}

function normalizeModelExclusionList(values: unknown): string[] {
  return normalizeStringList(values) ?? [];
}

export function normalizeConfig(config: Partial<DelegateConfig> | null | undefined): DelegateConfig {
  const searchableProviders = normalizeProviderList(config?.searchable_providers);
  const excludedProviders = normalizeProviderList(config?.excluded_providers);
  const excludedSet = new Set(excludedProviders ?? []);
  return {
    searchable_providers: searchableProviders === null
      ? null
      : searchableProviders.filter((provider) => !excludedSet.has(provider)),
    excluded_providers: excludedProviders,
    excluded_models: normalizeModelExclusionList(config?.excluded_models),
  };
}

function loadConfig(): DelegateConfig {
  try {
    const saved = kv().get<Partial<DelegateConfig>>("config", "global");
    if (saved) return normalizeConfig({ ...DEFAULT_CONFIG, ...saved });
  } catch { /* first run */ }
  return { ...DEFAULT_CONFIG };
}

function saveConfig(config: DelegateConfig): void {
  kv().set("config", normalizeConfig(config), "global");
}

/**
 * Discover the MCP adapter extension path.
 * Cached after first call — result doesn't change during a session.
 */
let _mcpPathCache: string | null | undefined;
function findMcpAdapter(): string | null {
  if (_mcpPathCache !== undefined) return _mcpPathCache;
  const candidates = [
    join(process.env.BUN_INSTALL || "/usr/local/lib/bun", "install/global/node_modules/pi-mcp-adapter/index.ts"),
    "/usr/local/lib/bun/install/global/node_modules/pi-mcp-adapter/index.ts",
  ];
  for (const p of candidates) {
    if (existsSync(p)) { _mcpPathCache = p; return p; }
  }
  _mcpPathCache = null;
  return null;
}

export type DelegateCliCommand = { command: string; argsPrefix: string[]; label: string };

type DelegateCliResolveOptions = {
  env?: Record<string, string | undefined>;
  platform?: string;
  execPath?: string;
  exists?: (path: string) => boolean;
  isExecutable?: (path: string, platform: string) => boolean;
  resolvePackageCli?: () => string | null;
  hostEntryPoint?: string | null;
};

const PI_CODING_AGENT_PACKAGE = `@earendil-works/${"pi-coding-agent"}`;

function isExecutableFile(path: string, platform: string = process.platform): boolean {
  try {
    const stat = statSync(path);
    if (!stat.isFile()) return false;
    // Windows does not use POSIX executable bits. If the file exists and has a
    // runnable extension, let CreateProcess/cmd handle it.
    if (platform === "win32") return true;
    return (stat.mode & 0o111) !== 0;
  } catch {
    return false;
  }
}

function pathListDelimiter(platform: string): string {
  return platform === "win32" ? ";" : delimiter;
}

function pathExecutableExtensions(env: Record<string, string | undefined>, platform: string): string[] {
  if (platform !== "win32") return [""];
  return String(env.PATHEXT || ".COM;.EXE;.BAT;.CMD")
    .split(";")
    .map((ext) => ext.trim())
    .filter(Boolean);
}

function findExecutableOnPath(
  name: string,
  env: Record<string, string | undefined> = process.env,
  platform: string = process.platform,
  isExecutable: (path: string, platform: string) => boolean = isExecutableFile,
): string | null {
  const hasExtension = /\.[^/\\]+$/.test(name);
  const extensions = hasExtension ? [""] : pathExecutableExtensions(env, platform);
  for (const dir of String(env.PATH || "").split(pathListDelimiter(platform)).filter(Boolean)) {
    const candidates = platform === "win32"
      ? [join(dir, name), ...extensions.map((ext) => join(dir, `${name}${ext}`))]
      : [join(dir, name)];
    for (const candidate of [...new Set(candidates)]) {
      if (isExecutable(candidate, platform)) return candidate;
    }
  }
  return null;
}

/** Resolve the package's published CLI without executing any package code. */
export function resolvePiPackageCli(manifestPath: string): string | null {
  try {
    const manifest = JSON.parse(readFileSync(manifestPath, "utf8"));
    const bin = manifest?.bin?.pi;
    if (manifest?.name !== PI_CODING_AGENT_PACKAGE || typeof bin !== "string" || !bin.trim()
      || isAbsolute(bin) || win32.isAbsolute(bin) || bin.includes("\\") || bin.includes("\0")) return null;
    const root = realpathSync(dirname(manifestPath));
    const candidate = resolve(root, bin);
    const within = (path: string) => {
      const fromRoot = relative(root, path);
      return fromRoot !== "" && fromRoot !== ".." && !fromRoot.startsWith(`..${sep}`) && !isAbsolute(fromRoot);
    };
    if (!within(candidate)) return null;
    const canonical = realpathSync(candidate);
    return within(canonical) && statSync(canonical).isFile() ? canonical : null;
  } catch {
    return null; // Missing/invalid installations are skipped; never guess an internal entrypoint.
  }
}

export function resolvePackagePiCliPath(resolvePackage: (specifier: string) => string = specifier => fileURLToPath(import.meta.resolve(specifier))): string | null {
  try {
    return resolvePiPackageCli(resolvePackage(`${PI_CODING_AGENT_PACKAGE}/package.json`));
  } catch { /* Some package export maps hide package.json. Resolve the public root without importing it. */ }
  try {
    let directory = dirname(resolvePackage(PI_CODING_AGENT_PACKAGE));
    while (true) {
      const manifestPath = join(directory, "package.json");
      if (existsSync(manifestPath)) return resolvePiPackageCli(manifestPath);
      const parent = dirname(directory);
      if (parent === directory) return null;
      directory = parent;
    }
  } catch {
    return null;
  }
}

// Resolve once before a portable "current" symlink can be switched by an upgrade.
const RUNNING_ENTRYPOINT = (() => { try { return realpathSync(process.argv[1] || ""); } catch { return null; } })();

/** Resolve Pi relative to the running Piclaw package, never relative to this add-on. */
export function resolveRunningPiclawCli(entryPoint: string | null): string | null {
  if (!entryPoint) return null;
  let entry: string;
  try { entry = realpathSync(entryPoint); } catch { return null; }
  let directory = dirname(entry);
  while (true) {
    const manifestPath = join(directory, "package.json");
    let manifest: any;
    try { manifest = JSON.parse(readFileSync(manifestPath, "utf8")); } catch { /* not a package boundary */ }
    if (manifest?.name === "piclaw") {
      const hostRequire = createRequire(entry);
      const cli = resolvePackagePiCliPath((specifier) => hostRequire.resolve(specifier));
      if (!cli) throw new Error("Running Piclaw release has no valid Pi CLI manifest; repair the release or set PI_DELEGATE_CLI explicitly.");
      return cli;
    }
    // Another package owns this entrypoint: standalone Pi/test processes must keep normal fallback.
    if (manifest?.name) return null;
    const parent = dirname(directory);
    if (parent === directory) return null;
    directory = parent;
  }
}

/** Freeze PATH/shim resolution for both catalog discovery and child execution. */
export function pinDelegateCliCommand(cli: DelegateCliCommand, env: Record<string,string|undefined> = process.env): DelegateCliCommand {
  const command = isAbsolute(cli.command) || cli.command.includes("/") || cli.command.includes("\\")
    ? cli.command : findExecutableOnPath(cli.command, env, process.platform);
  if (!command) throw new Error("Delegate CLI executable is unavailable; check the running release or PI_DELEGATE_CLI.");
  let resolved: string;
  try { resolved = realpathSync(command); } catch { throw new Error("Delegate CLI executable is unavailable; check the running release or PI_DELEGATE_CLI."); }
  const argsPrefix = cli.argsPrefix.map(arg => {
    // Keep flags/literals unchanged; pin a file argument if it resolves locally.
    try { return !arg.startsWith("-") && statSync(arg).isFile() ? realpathSync(arg) : arg; } catch { return arg; }
  });
  return { command: resolved, argsPrefix, label: [resolved, ...argsPrefix].join(" ") };
}

export function delegateCliDiagnostics(cli: DelegateCliCommand) {
  const canonical = (path: string) => { try { return realpathSync(path); } catch { return path; } };
  const entry = cli.argsPrefix[0];
  let packageVersion: string | null = null;
  if (entry && isAbsolute(entry)) {
    let directory = dirname(canonical(entry));
    while (true) {
      const manifestPath = join(directory, "package.json");
      try {
        const manifest = JSON.parse(readFileSync(manifestPath, "utf8"));
        if (manifest.name === PI_CODING_AGENT_PACKAGE && resolvePiPackageCli(manifestPath) === canonical(entry)) {
          packageVersion = typeof manifest.version === "string" ? manifest.version : null;
          break;
        }
      } catch { /* diagnostics cannot make an explicit command invalid */ }
      const parent = dirname(directory); if (parent === directory) break; directory = parent;
    }
  }
  const stamp = (path: string) => { try { const st = statSync(path); return [canonical(path), st.dev, st.ino, st.size, st.mtimeMs]; } catch { return [path]; } };
  return { command: cli.command, path: entry || cli.command, package_version: packageVersion,
    identity: JSON.stringify([stamp(cli.command), cli.argsPrefix.map(stamp), packageVersion]) };
}

function candidatePiCliPaths(env: Record<string, string | undefined>, resolvePackageCli: () => string | null): string[] {
  const manifests = new Set([
    join(env.BUN_INSTALL || "/usr/local/lib/bun", "install/global/node_modules", PI_CODING_AGENT_PACKAGE, "package.json"),
    join("/usr/local/lib/bun", "install/global/node_modules", PI_CODING_AGENT_PACKAGE, "package.json"),
  ]);
  return [resolvePackageCli(), ...[...manifests].map(resolvePiPackageCli)]
    .filter((path): path is string => Boolean(path));
}

export function resolveDelegateCliCommand(options: DelegateCliResolveOptions = {}): DelegateCliCommand {
  const env = options.env ?? process.env;
  const platform = options.platform ?? process.platform;
  const exists = options.exists ?? existsSync;
  const isExecutable = options.isExecutable ?? isExecutableFile;
  const execPath = options.execPath || process.execPath || "";
  const override = env.PI_DELEGATE_CLI?.trim();
  if (override) {
    const [command, ...argsPrefix] = override.split(/\s+/).filter(Boolean);
    if (command) return { command, argsPrefix, label: override };
  }

  const hostCli = resolveRunningPiclawCli(options.hostEntryPoint === undefined ? RUNNING_ENTRYPOINT : options.hostEntryPoint);
  if (hostCli && execPath) return { command: execPath, argsPrefix: [hostCli], label: `${execPath} ${hostCli}` };

  // Prefer invoking the Pi CLI JS entrypoint through the current runtime. This
  // avoids shebangs like `#!/usr/bin/env node`, so delegate works when Node is
  // not in PATH and also when Piclaw runs under Bun, Node, or a packaged runtime.
  if (execPath) {
    for (const cliPath of candidatePiCliPaths(env, options.resolvePackageCli ?? resolvePackagePiCliPath)) {
      if (exists(cliPath)) return { command: execPath, argsPrefix: [cliPath], label: `${execPath} ${cliPath}` };
    }
  }

  // Last resort: a platform shim/shell script on PATH. This may rely on its own
  // runtime, so only use it after direct current-runtime execution is unavailable.
  const piPath = findExecutableOnPath("pi", env, platform, isExecutable);
  if (piPath) return { command: piPath, argsPrefix: [], label: piPath };

  return { command: "pi", argsPrefix: [], label: "pi" };
}

// ── Model catalog and deterministic classification ──────────────

export type ModelTierNumber = 1 | 2 | 3 | 4 | 5;
export type ModelClassificationStatus = "classified" | "unclassified";
export type ModelClassificationConfidence = "exact-policy" | "none";
export type ModelCatalogSource = "runtime" | "cli";

export interface AvailableModel {
  provider: string;
  id: string;
  fullId: string;
  name?: string;
  context?: string;
  maxOut?: string;
  thinking?: string;
  images?: string;
  contextWindow?: number;
  maxOutputTokens?: number;
  reasoning?: boolean;
  supportsImages?: boolean;
  catalogSource?: ModelCatalogSource;
}

export interface ModelClassification {
  status: ModelClassificationStatus;
  tier: ModelTierNumber | null;
  family: string;
  rule: string | null;
  reason: string;
  confidence: ModelClassificationConfidence;
  preference: number;
}

export interface ModelCandidate {
  id: string;
  tier: ModelTierNumber;
  family: string;
  sourceId: string;
  provider: string;
  modelId: string;
  matchScore: number;
  classificationRule: string;
  classificationReason: string;
  classificationConfidence: ModelClassificationConfidence;
  supportsImages: boolean | null;
  reasoning: boolean | null;
  contextWindow: number | null;
  maxOutputTokens: number | null;
}

export interface RuntimeCatalogSnapshot {
  source: "runtime";
  models: AvailableModel[];
  currentModel: AvailableModel | null;
  capturedAt: number;
}

export interface ExecutableCatalogSnapshot {
  source: "cli";
  cli: DelegateCliCommand;
  cliIdentity: string;
  cliPackageVersion: string | null;
  models: AvailableModel[];
  refreshedAt: number | null;
  lastAttemptAt: number | null;
  lastError: string | null;
  stale: boolean;
}

interface ClassificationRule {
  id: string;
  tier: ModelTierNumber;
  family: string;
  preference: number;
  reason: string;
  matches: (provider: string, normalizedId: string) => boolean;
}

function normalizedPolicyModelId(value: string): string {
  return String(value || "")
    .trim()
    .toLowerCase()
    .replace(/[._]+/g, "-")
    .replace(/-+/g, "-");
}

function rule(
  id: string,
  tier: ModelTierNumber,
  family: string,
  preference: number,
  reason: string,
  pattern: RegExp,
): ClassificationRule {
  return { id, tier, family, preference, reason, matches: (_provider, normalizedId) => pattern.test(normalizedId) };
}

// Ordered from specific variants to broader families. Every model is assigned by
// the first matching rule only, so a model can never expand into multiple tiers.
const MODEL_CLASSIFICATION_RULES: ClassificationRule[] = [
  rule("claude-opus", 5, "claude", 10, "Claude Opus frontier family", /^claude-opus(?:-|$)/),
  rule("claude-haiku", 1, "claude", 30, "Claude Haiku fast family", /^claude-haiku(?:-|$)/),
  rule("claude-fable", 3, "claude", 10, "Claude Fable general-purpose family", /^claude-fable(?:-|$)/),
  rule("claude-sonnet-4-6", 3, "claude", 20, "Claude Sonnet 4.6 general-purpose model", /^claude-sonnet-4-6(?:-|$)/),
  rule("claude-sonnet-5", 3, "claude", 25, "Claude Sonnet 5 general-purpose model", /^claude-sonnet-5(?:-|$)/),
  rule("claude-sonnet", 3, "claude", 30, "Claude Sonnet general-purpose family", /^claude-sonnet(?:-|$)/),

  // Enumerated Astra variants only; do not approve unknown GPT-6 families/suffixes.
  // OpenRouter retains the upstream publisher namespace in its model IDs.
  rule("gpt-6-astra-pro", 4, "gpt", 46, "GPT 6 Astra Pro high-capability variant", /^(?:openai\/)?gpt-6-astra-pro(?::batch)?$/),
  rule("gpt-6-astra", 3, "gpt", 52, "GPT 6 Astra general-purpose model", /^(?:openai\/)?gpt-6-astra(?::batch)?$/),
  // Prepared exact ID; capability/executable discovery remains authoritative.
  rule("gpt-6-1-sol", 3, "gpt", 53, "GPT 6.1 Sol general-purpose model", /^gpt-6-1-sol$/),
  // Exact normalised 0.87.1 IDs; existing punctuation aliases apply, never suffixes.
  rule("gpt-6-sol", 3, "gpt", 53, "GPT 6 Sol general-purpose model", /^gpt-6-sol$/),
  rule("gpt-6-luna", 3, "gpt", 54, "GPT 6 Luna general-purpose model", /^gpt-6-luna$/),
  rule("gpt-codex-mini", 2, "gpt", 20, "GPT Codex Mini fast coding family", /^gpt-5(?:-[0-9]+)?-codex-mini(?:-|$)/),
  rule("gpt-codex-spark", 4, "gpt", 30, "GPT Codex Spark coding specialist", /^gpt-5(?:-[0-9]+)?-codex-spark(?:-|$)/),
  rule("gpt-codex-max", 4, "gpt", 35, "GPT Codex Max coding specialist", /^gpt-5(?:-[0-9]+)?-codex-max(?:-|$)/),
  rule("gpt-codex", 4, "gpt", 40, "GPT Codex coding specialist", /^gpt-5(?:-[0-9]+)?-codex(?:-|$)/),
  rule("gpt-pro", 4, "gpt", 45, "GPT Pro high-capability family", /^gpt-5(?:-[0-9]+)?-pro(?:-|$)/),
  rule("gpt-mini", 2, "gpt", 10, "GPT Mini fast family", /^gpt-5(?:-[0-9]+)?-mini(?:-|$)/),
  rule("gpt-5-4", 3, "gpt", 40, "GPT 5.4 general-purpose model", /^gpt-5-4(?:-|$)/),
  rule("gpt-5-5", 3, "gpt", 45, "GPT 5.5 general-purpose model", /^gpt-5-5(?:-|$)/),
  rule("gpt-5-6", 3, "gpt", 50, "GPT 5.6 general-purpose variants", /^gpt-5-6(?:-|$)/),
  rule("gpt-5-general", 3, "gpt", 55, "GPT 5 general-purpose family", /^gpt-5(?:-[0-9]+)?(?:-|$)/),
  rule("gpt-4", 1, "gpt", 20, "GPT 4 legacy family", /^gpt-4(?:-|$)/),
  rule("openai-o-series", 3, "gpt", 60, "OpenAI o-series reasoning family", /^o(?:1|3|4)(?:-|$)/),

  rule("gemini-flash", 2, "gemini", 40, "Gemini Flash fast family", /^gemini-.*(?:^|-)flash(?:-|$)/),
  rule("gemini-pro", 3, "gemini", 60, "Gemini Pro general-purpose family", /^gemini-.*(?:^|-)pro(?:-|$)/),
  rule("mai-code-flash", 2, "mai", 50, "MAI Code Flash fast coding family", /^mai-.*flash(?:-|$)/),
  rule("grok-code-fast", 1, "grok", 40, "Grok Code Fast family", /^(?:grok|xai)-.*fast(?:-|$)/),
  rule("grok-4-7", 3, "grok", 65, "Grok 4.7 general-purpose model", /^grok-4-7$/),

  rule("deepseek-flash", 2, "deepseek", 60, "DeepSeek Flash fast family", /^deepseek-.*flash(?:-|$)/),
  rule("deepseek-pro", 3, "deepseek", 70, "DeepSeek Pro general-purpose family", /^deepseek-.*pro(?:-|$)/),
  rule("mistral-large", 3, "mistral", 80, "Mistral Large general-purpose family", /^mistral-large(?:-|$)/),
  rule("gemma", 2, "gemma", 70, "Gemma medium-weight family", /^gemma(?:-|$)/),
  rule("gpt-oss", 2, "gpt-oss", 75, "GPT OSS fast hosted family", /^gpt-oss(?:-|$)/),
  rule("glm", 2, "glm", 80, "GLM fast hosted family", /^(?:zai-)?glm(?:-|$)/),
  rule("qwen", 2, "qwen", 85, "Qwen medium-weight local family", /^qwen(?:\d|-|$)/),
  rule("lfm", 1, "lfm", 50, "LFM lightweight local family", /^lfm(?:\d|-|:|$)/),
];

function inferUnclassifiedFamily(modelId: string): string {
  const normalized = normalizedPolicyModelId(modelId);
  return normalized.split("-")[0] || "unknown";
}

export function classifyModel(model: Pick<AvailableModel, "provider" | "id"> | string): ModelClassification {
  const fullId = typeof model === "string" ? model : `${model.provider}/${model.id}`;
  const slash = fullId.indexOf("/");
  const provider = slash >= 0 ? fullId.slice(0, slash).toLowerCase() : "";
  const modelId = slash >= 0 ? fullId.slice(slash + 1) : fullId;
  const normalizedId = normalizedPolicyModelId(modelId);
  const matched = MODEL_CLASSIFICATION_RULES.find((candidate) => candidate.matches(provider, normalizedId));
  if (!matched) {
    return {
      status: "unclassified",
      tier: null,
      family: inferUnclassifiedFamily(modelId),
      rule: null,
      reason: `No ordered Delegate policy rule matches ${fullId}`,
      confidence: "none",
      preference: Number.MAX_SAFE_INTEGER,
    };
  }
  return {
    status: "classified",
    tier: matched.tier,
    family: matched.family,
    rule: matched.id,
    reason: matched.reason,
    confidence: "exact-policy",
    preference: matched.preference,
  };
}

function providerPreference(provider: string, searchableProviders: string[] | null): number {
  const configured = searchableProviders?.indexOf(provider) ?? -1;
  if (configured >= 0) return configured;
  const preferred = DEFAULT_SEARCHABLE_PROVIDER_ORDER.indexOf(provider);
  if (preferred >= 0) return preferred;
  return 100;
}

function getDiscoveredProviders(models: AvailableModel[]): string[] {
  return [...new Set(models.map((model) => model.provider).filter(Boolean))].sort();
}

function getExcludedProviders(models: AvailableModel[], config: DelegateConfig): string[] {
  const discovered = getDiscoveredProviders(models);
  const configured = normalizeProviderList(config.excluded_providers);
  if (configured !== null) return configured.filter((provider) => discovered.includes(provider));
  return discovered.filter((provider) => AZURE_PROVIDER_RE.test(provider));
}

function getAllowedProviders(models: AvailableModel[], config: DelegateConfig): string[] {
  const discovered = getDiscoveredProviders(models);
  const excluded = new Set(getExcludedProviders(models, config));
  const configured = normalizeProviderList(config.searchable_providers) ?? [];
  const discoveredSet = new Set(discovered);
  return configured.filter((provider) => discoveredSet.has(provider) && !excluded.has(provider));
}

function modelExclusionMatches(pattern: string, model: AvailableModel): boolean {
  const normalizedPattern = pattern.trim().toLowerCase();
  if (!normalizedPattern) return false;
  const haystacks = [model.fullId, model.id].map((value) => value.toLowerCase());
  if (normalizedPattern.includes("*")) {
    const escaped = normalizedPattern.replace(/[.+?^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*");
    const re = new RegExp(`^${escaped}$`, "i");
    return haystacks.some((value) => re.test(value));
  }
  return haystacks.some((value) => value === normalizedPattern || value.includes(normalizedPattern));
}

function isExcludedModel(model: AvailableModel, config: DelegateConfig): boolean {
  return normalizeModelExclusionList(config.excluded_models).some((pattern) => modelExclusionMatches(pattern, model));
}

function optionalBoolean(value: boolean | undefined, legacy: string | undefined): boolean | null {
  if (typeof value === "boolean") return value;
  if (typeof legacy === "string") return /^(yes|true|1)$/i.test(legacy);
  return null;
}

function optionalCount(value: number | undefined): number | null {
  return typeof value === "number" && Number.isFinite(value) && value > 0 ? value : null;
}

export function describeImageCapability(model: Pick<ModelCandidate, "id" | "supportsImages">): string | null {
  if (model.supportsImages === true) return null;
  return model.supportsImages === false
    ? `${model.id} (images=no)`
    : `${model.id} (image capability unknown)`;
}

export function buildModelCandidates(models: AvailableModel[], config: DelegateConfig = DEFAULT_CONFIG): ModelCandidate[] {
  const normalizedConfig = normalizeConfig(config);
  const allowedProviders = new Set(getAllowedProviders(models, normalizedConfig));
  const candidates: Array<ModelCandidate & { preference: number; providerRank: number }> = [];
  const seen = new Set<string>();

  for (const model of models) {
    if (seen.has(model.fullId)) continue;
    seen.add(model.fullId);
    if (!allowedProviders.has(model.provider) || isExcludedModel(model, normalizedConfig)) continue;
    const classification = classifyModel(model);
    if (classification.status !== "classified" || classification.tier === null || !classification.rule) continue;
    candidates.push({
      id: model.fullId,
      tier: classification.tier,
      family: classification.family,
      sourceId: classification.rule,
      provider: model.provider,
      modelId: model.id,
      matchScore: 100,
      classificationRule: classification.rule,
      classificationReason: classification.reason,
      classificationConfidence: classification.confidence,
      supportsImages: optionalBoolean(model.supportsImages, model.images),
      reasoning: optionalBoolean(model.reasoning, model.thinking),
      contextWindow: optionalCount(model.contextWindow),
      maxOutputTokens: optionalCount(model.maxOutputTokens),
      preference: classification.preference,
      providerRank: providerPreference(model.provider, normalizedConfig.searchable_providers),
    });
  }

  return candidates
    .sort((a, b) => a.tier - b.tier || a.preference - b.preference || a.providerRank - b.providerRank || a.id.localeCompare(b.id))
    .map(({ preference: _preference, providerRank: _providerRank, ...candidate }) => candidate);
}

function getCurrentClassification(ctx: any): ModelClassification | null {
  const model = ctx?.model;
  return model?.provider && model?.id ? classifyModel({ provider: model.provider, id: model.id }) : null;
}

export function getCurrentTier(ctx: any): ModelTierNumber | null {
  const classification = getCurrentClassification(ctx);
  return classification?.status === "classified" ? classification.tier : null;
}

export interface ExplicitModelValidation {
  model: AvailableModel | null;
  approved: boolean;
  error: string | null;
}

/**
 * Explicit model requests use the same fail-closed approval boundary as
 * automatic selection. An exact executable model is still denied unless its
 * provider is approved, its ID matches the ordered classification policy, and
 * no provider/model exclusion applies.
 */
export function validateExplicitDelegateModel(
  requestedModel: string,
  executableModels: AvailableModel[],
  runtimeModels: AvailableModel[],
  config: DelegateConfig = DEFAULT_CONFIG,
): ExplicitModelValidation {
  const model = executableModels.find((candidate) => candidate.fullId === requestedModel) ?? null;
  if (!model) {
    const runtimeOnly = runtimeModels.some((candidate) => candidate.fullId === requestedModel);
    return {
      model: null,
      approved: false,
      error: runtimeOnly
        ? `Delegate model ${requestedModel} is available in Piclaw but not executable by the child Pi CLI.`
        : `Delegate model ${requestedModel} is not available in the child Pi CLI catalog. Use an exact approved provider/model ID from Delegate settings.`,
    };
  }

  const normalizedConfig = normalizeConfig(config);
  const allowedProviders = new Set(getAllowedProviders(executableModels, normalizedConfig));
  if (!allowedProviders.has(model.provider)) {
    return {
      model: null,
      approved: false,
      error: `Delegate model ${requestedModel} uses provider ${model.provider}, which is not in the approved provider list. Explicit model selection cannot bypass Delegate model approval.`,
    };
  }
  if (isExcludedModel(model, normalizedConfig)) {
    return {
      model: null,
      approved: false,
      error: `Delegate model ${requestedModel} matches a configured model exclusion and is not approved. Explicit model selection cannot bypass Delegate model approval.`,
    };
  }
  const classification = classifyModel(model);
  if (classification.status !== "classified") {
    return {
      model: null,
      approved: false,
      error: `Delegate model ${requestedModel} is not in the ordered approved-model policy. ${classification.reason}`,
    };
  }

  const approved = buildModelCandidates(executableModels, normalizedConfig)
    .some((candidate) => candidate.id === requestedModel);
  return approved
    ? { model, approved: true, error: null }
    : {
        model: null,
        approved: false,
        error: `Delegate model ${requestedModel} is not in the approved candidate list. Explicit model selection cannot bypass Delegate model approval.`,
      };
}

/** Defensive last gate immediately before each child-model launch. */
export function assertApprovedDelegateModelAttempt(model: string, approvedCandidates: ModelCandidate[]): void {
  if (!approvedCandidates.some((candidate) => candidate.id === model)) {
    throw new Error(`Delegate refused unapproved model attempt ${model}. The model is not in the approved candidate list.`);
  }
}

/**
 * Providers can disclose a response model that differs from the requested
 * catalog model. Reject that response unless the disclosed model is also an
 * exact candidate eligible for this request. Opaque provider-side routing cannot be prevented
 * by a client, but a disclosed policy mismatch is never accepted as success.
 */
export function validateDelegateResponseModel(
  requestedModel: string,
  provider: string | null,
  responseModel: string | null,
  approvedCandidates: ModelCandidate[],
): string | null {
  const disclosed = String(responseModel || "").trim();
  if (!disclosed) return null;
  const requestedProvider = requestedModel.split("/", 1)[0] || "";
  const fullId = disclosed.includes("/") ? disclosed : `${provider || requestedProvider}/${disclosed}`;
  if (fullId === requestedModel) return null;
  return approvedCandidates.some((candidate) => candidate.id === fullId)
    ? null
    : `Provider disclosed response model ${fullId}, which is not in the approved Delegate model list.`;
}

type TaskCategory = "quick" | "summarize" | "code" | "analyze" | "reason" | "judge";

const CATEGORY_TARGET_TIER: Record<TaskCategory, ModelTierNumber> = {
  quick: 2,
  summarize: 2,
  code: 3,
  analyze: 3,
  reason: 3,
  judge: 3,
};

const VALID_CATEGORIES = new Set<TaskCategory>(["quick", "summarize", "code", "analyze", "reason", "judge"]);

export function selectModel(
  category: TaskCategory,
  maxTier: ModelTierNumber,
  currentModelId: string | undefined,
  discoveredCandidates: ModelCandidate[],
): string | null {
  const candidates = discoveredCandidates.filter((candidate) => candidate.tier <= maxTier);
  if (candidates.length === 0) return null;
  const targetTier = Math.min(CATEGORY_TARGET_TIER[category] ?? 2, maxTier) as ModelTierNumber;

  if (category === "judge" && currentModelId) {
    const currentFamily = classifyModel(currentModelId).family;
    for (let tier = targetTier; tier >= 1; tier -= 1) {
      const differentFamily = candidates.find((candidate) => candidate.tier === tier && candidate.family !== currentFamily);
      if (differentFamily) return differentFamily.id;
    }
  }

  const atTarget = candidates.find((candidate) => candidate.tier === targetTier);
  if (atTarget) return atTarget.id;
  for (let tier = targetTier - 1; tier >= 1; tier -= 1) {
    const lower = candidates.find((candidate) => candidate.tier === tier);
    if (lower) return lower.id;
  }
  return null;
}

/** Detect authentication failures that must stop the attempt without account/provider fallback. */
export function isProviderAuthError(text: unknown): boolean {
  const value = String(text || "").toLowerCase();
  if (!value) return false;
  return /\b(?:no|missing|invalid)\s+api[ -]?key\b/.test(value)
    || /\b(?:invalid|expired|revoked)\s+(?:access[ -]?|refresh[ -]?|bearer[ -]?)?token\b/.test(value)
    || /\b(?:token|credentials?|authentication)\s+(?:has\s+|have\s+)?(?:expired|revoked)\b/.test(value)
    || /\b(?:invalid|expired|revoked)\s+credentials?\b/.test(value)
    || /\binvalid_grant\b/.test(value)
    || /\b(?:failed to refresh|refresh failed).*\b(?:oauth|token|credentials?)\b/.test(value)
    || /\b(?:oauth|token|credentials?)\s+refresh\s+(?:failed|error)\b/.test(value)
    || /\blogged[ -]?out\b/.test(value)
    || value.includes("missing api key")
    || value.includes("no credentials")
    || value.includes("not authenticated")
    || value.includes("authentication failed")
    || value.includes("unauthorized");
}

export type DelegateFailureKind = "privacy-policy" | "auth" | "model-unavailable" | "provider-setup" | "timeout" | "aborted" | "execution" | "protocol";

export function isOpenCodeGlobalRegionRestriction(text: unknown): boolean {
  const value = String(text || '').replace(/\\u0027/gi, "'");
  return /This Go model requires Global regions\./i.test(value)
    && /Select Global in your workspace.*Privacy settings to use it\./i.test(value);
}

export function formatDelegateFailure(text: string, provider: string): string {
  if (provider === 'opencode-go' && isOpenCodeGlobalRegionRestriction(text)) {
    return '[privacy-policy] This OpenCode Go model requires the workspace Privacy region setting to be Global. Review that setting in the OpenCode console (https://opencode.ai/). Choosing Global broadens permitted processing regions and may relax data-residency restrictions. Piclaw has not changed the setting. Choose another approved compatible model if you need to keep the current restriction. Provider privacy information: https://opencode.ai/docs/go/#privacy. Upstream detail: ' + text;
  }
  return text;
}

export function classifyDelegateFailure(text: unknown): DelegateFailureKind {
  const value = String(text || "").toLowerCase();
  if (value.startsWith('[privacy-policy]')) return 'privacy-policy';
  if (isProviderAuthError(value)) return "auth";
  if (/timed out|timeout/.test(value)) return "timeout";
  if (/\babort(?:ed)?\b|cancelled|canceled/.test(value)) return "aborted";
  if (/model .*(?:not found|unavailable|unsupported|does not exist)|unknown model|failed to resolve model|invalid model/.test(value)) return "model-unavailable";
  if (/provider .*(?:not found|unavailable|unsupported)|unknown provider|failed to (?:initialize|load) provider|no provider (?:registered|configured)/.test(value)) return "provider-setup";
  if (/malformed json|no valid json events|json protocol/.test(value)) return "protocol";
  return "execution";
}

export function isRetryableDelegateFailure(kind: DelegateFailureKind): boolean {
  return kind === "model-unavailable" || kind === "provider-setup";
}

export function buildDelegateModelChain(
  category: TaskCategory,
  maxTier: ModelTierNumber,
  currentModelId: string | undefined,
  discoveredCandidates: ModelCandidate[],
  limit = 3,
): string[] {
  const chain: string[] = [];
  const primary = selectModel(category, maxTier, currentModelId, discoveredCandidates);
  if (primary) chain.push(primary);
  const targetTier = Math.min(CATEGORY_TARGET_TIER[category] ?? 2, maxTier);
  const fallbacks = discoveredCandidates
    .filter((candidate) => candidate.tier <= targetTier)
    .map((candidate, index) => ({ candidate, index }))
    .sort((a, b) => Math.abs(a.candidate.tier - targetTier) - Math.abs(b.candidate.tier - targetTier) || a.index - b.index);
  for (const { candidate } of fallbacks) {
    if (chain.length >= limit) break;
    if (!chain.includes(candidate.id)) chain.push(candidate.id);
  }
  return chain;
}

// ── Model discovery ────────────────────────────────────────────

function parseModelCount(value: unknown): number | undefined {
  if (typeof value === "number") return Number.isFinite(value) && value > 0 ? value : undefined;
  if (typeof value !== "string") return undefined;
  const match = value.trim().match(/^(\d+(?:\.\d+)?)\s*([KMG])?$/i);
  if (!match) return undefined;
  const base = Number(match[1]);
  const multiplier = match[2]?.toUpperCase() === "G" ? 1_000_000_000
    : match[2]?.toUpperCase() === "M" ? 1_000_000
      : match[2]?.toUpperCase() === "K" ? 1_000
        : 1;
  return Math.round(base * multiplier);
}

function parseYesNo(value: unknown): boolean | undefined {
  if (typeof value === "boolean") return value;
  if (typeof value !== "string") return undefined;
  if (/^(yes|true|1)$/i.test(value.trim())) return true;
  if (/^(no|false|0)$/i.test(value.trim())) return false;
  return undefined;
}

export function runtimeModelToAvailable(model: any): AvailableModel | null {
  if (!model?.provider || !model?.id) return null;
  const input = Array.isArray(model.input) ? model.input.map((entry: unknown) => String(entry).toLowerCase()) : [];
  return {
    provider: String(model.provider),
    id: String(model.id),
    fullId: `${model.provider}/${model.id}`,
    name: typeof model.name === "string" ? model.name : undefined,
    contextWindow: parseModelCount(model.contextWindow ?? model.context_window),
    maxOutputTokens: parseModelCount(model.maxTokens ?? model.maxOutputTokens ?? model.max_output_tokens),
    reasoning: typeof model.reasoning === "boolean" ? model.reasoning : undefined,
    supportsImages: input.length > 0
      ? input.includes("image")
      : (typeof model.supportsImages === "boolean" ? model.supportsImages : (typeof model.supports_images === "boolean" ? model.supports_images : undefined)),
    catalogSource: "runtime",
  };
}

export async function captureRuntimeCatalog(
  ctx: any,
  fallback?: RuntimeCatalogSnapshot | null,
): Promise<RuntimeCatalogSnapshot> {
  // Catalog capture is a passive lifecycle read. ModelRegistry.refresh() is
  // process-wide and network-enabled by default, so invoking it from
  // session_start/model_select blocks session readiness and refreshes every
  // dynamic provider. Piclaw owns background provider refresh and publishes
  // its last-good availability snapshot synchronously through getAvailable().
  let rawModels: unknown;
  try {
    rawModels = ctx?.modelRegistry?.getAvailable?.();
  } catch {
    rawModels = undefined;
  }

  const seen = new Set<string>();
  const models = (Array.isArray(rawModels) ? rawModels : [])
    .map(runtimeModelToAvailable)
    .filter((model: AvailableModel | null): model is AvailableModel => Boolean(model))
    .filter((model: AvailableModel) => {
      if (seen.has(model.fullId)) return false;
      seen.add(model.fullId);
      return true;
    });
  const currentModel = runtimeModelToAvailable(ctx?.model) ?? fallback?.currentModel ?? null;
  if (models.length === 0 && fallback?.models.length) {
    return { ...fallback, currentModel, capturedAt: Date.now() };
  }
  return { source: "runtime", models, currentModel, capturedAt: Date.now() };
}

export function mergeExecutableRuntimeMetadata(
  executableModels: AvailableModel[],
  runtimeModels: AvailableModel[],
): AvailableModel[] {
  const runtimeById = new Map(runtimeModels.map((model) => [model.fullId, model]));
  return executableModels.map((executable) => {
    const runtime = runtimeById.get(executable.fullId);
    if (!runtime) return executable;
    return {
      ...executable,
      name: runtime.name ?? executable.name,
      contextWindow: runtime.contextWindow ?? executable.contextWindow,
      maxOutputTokens: runtime.maxOutputTokens ?? executable.maxOutputTokens,
      reasoning: runtime.reasoning ?? executable.reasoning,
      supportsImages: runtime.supportsImages ?? executable.supportsImages,
      catalogSource: "cli",
    };
  });
}

export function parsePiListModelsOutput(output: string): AvailableModel[] {
  const lines = String(output || "").split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  const models: AvailableModel[] = [];
  for (const line of lines) {
    if (/^provider\s+model\s+/i.test(line)) continue;
    const parts = line.split(/\s+/).filter(Boolean);
    if (parts.length < 2) continue;
    const [provider, id, context, maxOut, thinking, images] = parts;
    if (!provider || !id) continue;
    models.push({
      provider,
      id,
      fullId: `${provider}/${id}`,
      context,
      maxOut,
      thinking,
      images,
      contextWindow: parseModelCount(context),
      maxOutputTokens: parseModelCount(maxOut),
      reasoning: parseYesNo(thinking),
      supportsImages: parseYesNo(images),
      catalogSource: "cli",
    });
  }
  return models;
}

/**
 * A POSIX session leader anchors the owned group through TERM escalation.
 * Only that live leader broadcasts signals to its own group, so no delayed
 * negative-PID kill can target a reused group after the CLI parent exits.
 * Windows retains the existing direct-child termination convention.
 */
const DELEGATE_GROUP_ANCHOR = `
trap 'trap "" TERM; kill -TERM -$$; sleep 2; kill -KILL -$$' TERM
trap 'trap "" TERM USR1; kill -KILL -$$' USR1
exec 4<&0
"$@" <&4 3>&- 4<&- &
delegate_child=$!
exec 4<&-
wait "$delegate_child"
delegate_status=$?
printf "%s\\n" "$delegate_status" >&3
exec 3>&-
# Retain the group identity until the host requests owned-group cleanup.
while :; do sleep 3600 & wait $!; done
`;

function spawnDelegateChild(command: string, args: string[], stdin: "ignore" | "pipe", onCliExit: () => void) {
  const posix = process.platform !== "win32";
  const child = nodeSpawn(posix ? "/bin/sh" : command,
    posix ? ["-c", DELEGATE_GROUP_ANCHOR, "delegate-group", command, ...args] : args, {
      cwd: getDelegateWorkspaceRoot(),
      stdio: posix ? [stdin, "pipe", "pipe", "pipe"] : [stdin, "pipe", "pipe"],
      env: process.env,
      detached: posix,
    });
  const owned = { child, cliExitCode: null as number | null };
  let status = "";
  child.stdio[3]?.on("data", (chunk: Buffer) => {
    if (owned.cliExitCode !== null) return;
    status += chunk.toString();
    if (!/^\d{1,3}\n$/.test(status)) return;
    const code = Number(status.trim());
    if (code > 255) return;
    owned.cliExitCode = code;
    onCliExit();
    // Signal only the still-owned child. The live anchor performs both group
    // signals itself; the host never schedules a kill against a saved PGID.
    child.kill("SIGUSR1");
  });
  return owned;
}

function runPiListModels(cli: DelegateCliCommand, timeoutMs = 20_000, signal?: AbortSignal): Promise<string> {
  return new Promise((resolvePromise, reject) => {
    if (signal?.aborted) {
      reject(new Error("Aborted during Delegate model discovery"));
      return;
    }
    const owned = spawnDelegateChild(cli.command, [...cli.argsPrefix, "--no-extensions", "--list-models"], "ignore", () => { cleanup(); forceTimer = setTimeout(() => { if(settled)return; settled=true; child.stdout?.destroy();child.stderr?.destroy();reject(new Error("Delegate model discovery retained pipes after CLI exit.")); }, 1000); });
    const { child } = owned;
    let stdout = "";
    let stderr = "";
    let settled = false;
    let terminationError: Error | null = null;
    let killTimer: ReturnType<typeof setTimeout> | null = null;
    let forceTimer: ReturnType<typeof setTimeout> | null = null;

    const sendSignal = (childSignal: NodeJS.Signals) => {
      try { child.kill(childSignal); } catch { /* already exited */ }
    };
    const cleanup = () => {
      clearTimeout(deadlineTimer);
      if (killTimer) clearTimeout(killTimer);
      if (forceTimer) clearTimeout(forceTimer);
      signal?.removeEventListener("abort", onAbort);
    };
    const terminate = (error: Error) => {
      if (settled || terminationError) return;
      terminationError = error;
      sendSignal("SIGTERM");
      if (process.platform !== "win32") {
        settled = true;
        cleanup();
        reject(error);
        return;
      }
      if (process.platform === "win32") killTimer = setTimeout(() => sendSignal("SIGKILL"), 2_000);
      forceTimer = setTimeout(() => {
        if (settled) return;
        settled = true;
        cleanup();
        reject(error);
      }, 2_500);
    };
    const onAbort = () => terminate(new Error("Aborted during Delegate model discovery"));
    const deadlineTimer = setTimeout(() => terminate(new Error(`${cli.label} --list-models timed out`)), Math.max(1, timeoutMs));
    signal?.addEventListener("abort", onAbort, { once: true });

    child.stdout?.on("data", (chunk: Buffer) => {
      if (stdout.length < 2_000_000) stdout += chunk.toString().slice(0, 2_000_000 - stdout.length);
    });
    child.stderr?.on("data", (chunk: Buffer) => {
      if (stderr.length < 64_000) stderr += chunk.toString().slice(0, 64_000 - stderr.length);
    });
    child.on("close", (code) => {
      if (settled) return;
      settled = true;
      cleanup();
      if (terminationError) reject(terminationError);
      else if ((owned.cliExitCode ?? code) !== 0) reject(new Error(stderr.trim() || `${cli.label} --list-models exited ${owned.cliExitCode ?? code}`));
      else resolvePromise(stdout);
    });
    child.on("error", (error) => {
      if (settled) return;
      settled = true;
      cleanup();
      reject(terminationError ?? error);
    });
  });
}

const MODEL_CATALOG_TTL_MS = Math.max(5_000, Number(process.env.PI_DELEGATE_MODEL_CACHE_TTL_MS || "60000"));
let runtimeCatalogSnapshot: RuntimeCatalogSnapshot | null = null;
let executableCatalogSnapshot: ExecutableCatalogSnapshot | null = null;
let executableCatalogGeneration = 0;

export function invalidateExecutableCatalog(): void {
  if (executableCatalogSnapshot) executableCatalogSnapshot.stale = true;
}

function executableCatalogIsFresh(snapshot: ExecutableCatalogSnapshot, now = Date.now()): boolean {
  return !snapshot.stale
    && snapshot.refreshedAt !== null
    && snapshot.models.length > 0
    && now - snapshot.refreshedAt < MODEL_CATALOG_TTL_MS;
}

export async function getExecutableCatalog(
  refresh = false,
  timeoutMs = 20_000,
  signal?: AbortSignal,
  selectedCli: DelegateCliCommand = pinDelegateCliCommand(resolveDelegateCliCommand()),
): Promise<ExecutableCatalogSnapshot> {
  const generation = ++executableCatalogGeneration;
  const now = Date.now();
  selectedCli = pinDelegateCliCommand(selectedCli);
  const diagnostics = delegateCliDiagnostics(selectedCli);
  const previous = executableCatalogSnapshot;
  const sameCli = previous?.cliIdentity === diagnostics.identity;
  if (!refresh && sameCli && executableCatalogSnapshot && executableCatalogIsFresh(executableCatalogSnapshot, now)) {
    return executableCatalogSnapshot;
  }
  try {
    const output = await runPiListModels(selectedCli, timeoutMs, signal);
    if (delegateCliDiagnostics(selectedCli).identity !== diagnostics.identity) throw new Error("Delegate CLI changed during discovery; retry with the current release.");
    const models = parsePiListModelsOutput(output);
    if (models.length === 0) throw new Error("pi --list-models returned no executable models");
    const snapshot: ExecutableCatalogSnapshot = {
      source: "cli",
      cli: selectedCli,
      cliIdentity: diagnostics.identity,
      cliPackageVersion: diagnostics.package_version,
      models,
      refreshedAt: Date.now(),
      lastAttemptAt: now,
      lastError: null,
      stale: false,
    };
    if (generation === executableCatalogGeneration) executableCatalogSnapshot = snapshot;
    return snapshot;
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    const retainPrevious = sameCli && delegateCliDiagnostics(selectedCli).identity === diagnostics.identity;
    const snapshot: ExecutableCatalogSnapshot = {
      source: "cli",
      cli: selectedCli,
      cliIdentity: diagnostics.identity,
      cliPackageVersion: diagnostics.package_version,
      models: retainPrevious ? previous?.models ?? [] : [],
      refreshedAt: retainPrevious ? previous?.refreshedAt ?? null : null,
      lastAttemptAt: now,
      lastError: message,
      stale: true,
    };
    if (generation === executableCatalogGeneration) executableCatalogSnapshot = snapshot;
    if (signal?.aborted || (timeoutMs < 20_000 && /timed out/i.test(message))) throw error;
    return snapshot;
  }
}

async function getDiscoveredModels(refresh = false): Promise<AvailableModel[]> {
  return (await getExecutableCatalog(refresh)).models;
}

async function getModelCandidates(config: DelegateConfig, refresh = false): Promise<ModelCandidate[]> {
  const models = await getDiscoveredModels(refresh);
  return buildModelCandidates(models, config);
}

// ── Default tool sets per task profile ─────────────────────────

const TOOL_PROFILES: Record<string, string> = {
  read_only:  "read,grep,find,ls",
  standard:   "read,grep,find,ls,bash",
  full:       "read,grep,find,ls,bash,edit,write",
};
const BUILTIN_CHILD_TOOLS = new Set(["read", "grep", "find", "ls", "bash", "edit", "write"]);

/** Explicit built-in lists are MCP-none unless they request mcp. */
export function buildDelegateChildTools(tools: string | undefined, adapterPath: string | null) {
  const profile = tools ? TOOL_PROFILES[tools] : TOOL_PROFILES.standard;
  const requested = (profile || String(tools || "")).split(",").map(name => name.trim()).filter(Boolean);
  if (profile && adapterPath) requested.push("mcp");
  const allowed = new Set(BUILTIN_CHILD_TOOLS);
  if (adapterPath) allowed.add("mcp");
  const unsupported = requested.filter(name => !allowed.has(name));
  if (unsupported.length) {
    delegateFailure(`Delegate child cannot load requested tool(s): ${unsupported.join(", ")}. Use Pi built-ins${adapterPath ? " or mcp" : ""}; workspace add-on tools are intentionally not inherited.`);
  }
  const unique = [...new Set(requested)];
  return { toolsArg: unique.join(","), mcpPath: unique.includes("mcp") ? adapterPath : null };
}

const NATIVE_IMAGE_EXTENSIONS = new Set([".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"]);
const UNSUPPORTED_BINARY_EXTENSIONS = new Set([
  ".tiff", ".tif", ".svg", ".ico", ".pdf", ".zip", ".tar", ".gz", ".7z", ".rar",
  ".mp3", ".wav", ".flac", ".ogg", ".mp4", ".mov", ".avi", ".mkv", ".webm",
]);

export interface DelegateFileInspection {
  kind: "text" | "image" | "unsupported";
  format: string;
  reason?: string;
}

function fileExtension(path: string): string {
  const basename = path.slice(Math.max(path.lastIndexOf("/"), path.lastIndexOf("\\")) + 1);
  const dot = basename.lastIndexOf(".");
  return dot >= 0 ? basename.slice(dot).toLowerCase() : "";
}

function startsWithBytes(buffer: Buffer, bytes: number[], offset = 0): boolean {
  return bytes.every((byte, index) => buffer[offset + index] === byte);
}

function readFileHeader(path: string, bytes = 512): Buffer {
  const fd = openSync(path, "r");
  try {
    const buffer = Buffer.alloc(bytes);
    const count = readSync(fd, buffer, 0, bytes, 0);
    return buffer.subarray(0, count);
  } finally {
    closeSync(fd);
  }
}

export function inspectDelegateFile(path: string): DelegateFileInspection {
  const header = readFileHeader(path);
  const extension = fileExtension(path);
  if (startsWithBytes(header, [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) return { kind: "image", format: "PNG" };
  if (startsWithBytes(header, [0xff, 0xd8, 0xff])) return { kind: "image", format: "JPEG" };
  if (header.subarray(0, 6).toString("ascii") === "GIF87a" || header.subarray(0, 6).toString("ascii") === "GIF89a") return { kind: "image", format: "GIF" };
  if (header.subarray(0, 4).toString("ascii") === "RIFF" && header.subarray(8, 12).toString("ascii") === "WEBP") return { kind: "image", format: "WebP" };
  if (header.subarray(0, 2).toString("ascii") === "BM") return { kind: "image", format: "BMP" };

  const ascii = header.toString("utf8");
  const trimmed = ascii.replace(/^\uFEFF/, "").trimStart();
  let format = "binary data";
  if (trimmed.startsWith("%PDF-")) format = "PDF";
  else if (/^(?:<\?xml[^>]*>\s*)?<svg(?:\s|>)/i.test(trimmed)) format = "SVG";
  else if (startsWithBytes(header, [0x50, 0x4b, 0x03, 0x04])) format = "ZIP archive";
  else if (startsWithBytes(header, [0x1f, 0x8b])) format = "gzip archive";
  else if (header.subarray(257, 262).toString("ascii") === "ustar") format = "tar archive";
  else if (startsWithBytes(header, [0x49, 0x49, 0x2a, 0x00]) || startsWithBytes(header, [0x4d, 0x4d, 0x00, 0x2a])) format = "TIFF";
  else if (startsWithBytes(header, [0x00, 0x00, 0x01, 0x00])) format = "ICO";
  else if (header.subarray(0, 3).toString("ascii") === "ID3") format = "audio";
  else if (header.subarray(0, 4).toString("ascii") === "OggS" || header.subarray(0, 4).toString("ascii") === "fLaC") format = "audio";
  else if (header.subarray(0, 4).toString("ascii") === "RIFF" && header.subarray(8, 12).toString("ascii") === "WAVE") format = "WAV audio";
  else if (header.subarray(4, 8).toString("ascii") === "ftyp" || startsWithBytes(header, [0x1a, 0x45, 0xdf, 0xa3])) format = "video";
  else if (!header.includes(0) && !UNSUPPORTED_BINARY_EXTENSIONS.has(extension)) {
    if (NATIVE_IMAGE_EXTENSIONS.has(extension)) {
      return { kind: "unsupported", format: "invalid image", reason: "The image extension does not match supported PNG, JPEG, GIF, WebP, or BMP content." };
    }
    return { kind: "text", format: "text" };
  } else if (UNSUPPORTED_BINARY_EXTENSIONS.has(extension)) {
    format = extension.slice(1).toUpperCase();
  }

  const reason = format === "PDF"
    ? "Extract its text with an appropriate document tool, or convert the required page to PNG/JPEG before delegation."
    : format === "SVG" || format === "TIFF" || format === "ICO"
      ? "Convert it to PNG, JPEG, GIF, WebP, or BMP before delegation."
      : "Extract, transcribe, or convert it to text or a supported native raster image before delegation.";
  return { kind: "unsupported", format, reason };
}

/** Validate a resolved path: must be inside workspace, no control characters. */
function validateFilePath(resolvedPath: string, original: string, workspaceRoot: string): string | null {
  if (/[\x00-\x1f]/.test(resolvedPath)) return `Unsafe characters in path: ${original}`;
  if (!resolvedPath.startsWith(workspaceRoot + "/") && resolvedPath !== workspaceRoot) {
    return `Path outside workspace: ${original} (resolved to ${resolvedPath})`;
  }
  return null;
}

export interface PreparedDelegateFile {
  resolved: string;
  size: number;
  inspection: DelegateFileInspection;
}

export function prepareDelegateFile(filePath: string): PreparedDelegateFile {
  const workspaceRoot = getDelegateWorkspaceRoot();
  const lexicalPath = resolve(filePath);
  const lexicalError = validateFilePath(lexicalPath, filePath, workspaceRoot);
  if (lexicalError) throw new Error(lexicalError);
  if (!existsSync(lexicalPath)) throw new Error(`File not found: ${filePath}`);
  const resolved = realpathSync(lexicalPath);
  const canonicalError = validateFilePath(resolved, filePath, workspaceRoot);
  if (canonicalError) throw new Error(canonicalError);
  const stat = statSync(resolved);
  if (!stat.isFile()) throw new Error(`Delegate files must be regular files: ${filePath}`);
  // Sniff only after the regular-file check so FIFOs/devices/sockets cannot block here.
  return { resolved, size: stat.size, inspection: inspectDelegateFile(resolved) };
}

// ── Helpers ────────────────────────────────────────────────────

function result(text: string, details?: Record<string, unknown>) {
  return { content: [{ type: "text" as const, text }], ...(details ? { details } : {}) };
}

function delegateFailure(message: string): never {
  throw new Error(message.replace(/^❌\s*/, ""));
}

export function delegateTaskPreview(prompt: string, maxLength = 96): string {
  const collapsed = String(prompt || "").replace(/\s+/g, " ").trim();
  if (!collapsed) return "delegated task";
  return collapsed.length > maxLength ? `${collapsed.slice(0, maxLength - 1)}…` : collapsed;
}

function readTrimmedString(...values: unknown[]): string | null {
  for (const value of values) {
    if (typeof value === "string" && value.trim()) return value.trim();
  }
  return null;
}

function readRecord(value: unknown): Record<string, unknown> | null {
  if (!value) return null;
  if (typeof value === "string") {
    try {
      const parsed = JSON.parse(value);
      return parsed && typeof parsed === "object" ? parsed as Record<string, unknown> : null;
    } catch {
      return null;
    }
  }
  return typeof value === "object" ? value as Record<string, unknown> : null;
}

function extractDelegateStatusArgs(args: unknown): Record<string, unknown> | null {
  const record = readRecord(args);
  if (!record) return null;
  const nested = readRecord(record.arguments) || readRecord(record.input) || readRecord(record.params) || readRecord(record.parameters) || readRecord(record.args) || readRecord(record.payload);
  return nested || record;
}

export function buildDelegateStatusUpdate(model: string, prompt: string, ordinal = 0, total = ordinal): string {
  return `Delegate${ordinal > 0 ? ` (${ordinal} of ${total})` : ""} model: ${model}\nArguments: ${delegateTaskPreview(prompt, 160)}`;
}

function modelFromDelegateStatusPreview(payload: Record<string, unknown> | null): string | null {
  const preview = readTrimmedString(payload?.output_preview, payload?.outputPreview);
  if (!preview) return null;
  const match = preview.match(/^Delegate(?: \(\d+(?: of \d+)?\))? model:\s*([^\n]+)/i);
  return match?.[1]?.trim() || null;
}

export function delegateStatusModelHint(args: unknown, payload?: Record<string, unknown> | null): string | null {
  const record = extractDelegateStatusArgs(args);
  return modelFromDelegateStatusPreview(payload || null) || readTrimmedString(record?.model);
}

type ToolStatusHintRegistrar = (provider: {
  id: string;
  buildHints: (ctx: { toolName: string; args: unknown; payload?: Record<string, unknown> }) => unknown;
}) => void;

function registerToolStatusHintProvider(provider: Parameters<ToolStatusHintRegistrar>[0]): void {
  const fn = (globalThis as Record<string, unknown>).__piclaw_registerToolStatusHintProvider;
  if (typeof fn === "function") (fn as ToolStatusHintRegistrar)(provider);
}

registerToolStatusHintProvider({
  id: "delegate",
  buildHints: ({ toolName, args, payload }) => {
    if (toolName !== "delegate") return null;
    const model = delegateStatusModelHint(args, payload || null);
    if (!model) return null;
    return {
      key: "delegate-model",
      icon_svg: DELEGATE_STATUS_ICON_SVG,
      label: model,
      title: `Delegate model • ${model}`,
      kind: "model",
    };
  },
});

function setDelegateProgress(ctx: any, options: { model: string; category: TaskCategory; prompt: string }, ordinal: number, total: number): void {
  const preview = delegateTaskPreview(options.prompt);
  const message = `Delegate (${ordinal} of ${total}): ${options.category} to ${options.model}: ${preview}`;
  try { ctx?.ui?.setStatus?.(DELEGATE_STATUS_KEY, `🤝 ${message}`); } catch { /* UI may not support status in all modes */ }
  try { ctx?.ui?.setWorkingMessage?.(message); } catch { /* UI may not support working messages in all modes */ }
}

function clearDelegateProgress(ctx: any): void {
  try { ctx?.ui?.setStatus?.(DELEGATE_STATUS_KEY, undefined); } catch { /* ignore */ }
  try { ctx?.ui?.setWorkingMessage?.(undefined); } catch { /* ignore */ }
}

// ── Settings API ───────────────────────────────────────────────

type AddonConfigApiRegistrar = (
  addonId: string,
  action: string,
  handlers: { get?: (payload: unknown, req: Request) => unknown | Promise<unknown>; set?: (payload: unknown, req: Request) => unknown | Promise<unknown> },
  extensionPath?: string,
) => "created" | "updated";

export function providerSummaries(models: AvailableModel[], config: DelegateConfig) {
  const enabled = new Set(getAllowedProviders(models, config));
  const excluded = new Set(getExcludedProviders(models, config));
  const providers = getDiscoveredProviders(models);
  return providers.map((provider) => ({
    provider,
    enabled: enabled.has(provider),
    excluded: excluded.has(provider),
    blacklisted: excluded.has(provider),
    defaultExcluded: config.excluded_providers === null && AZURE_PROVIDER_RE.test(provider),
    modelCount: models.filter((model) => model.provider === provider).length,
  })).sort((left, right) => {
    const configured = config.searchable_providers;
    if (configured !== null) {
      const leftIndex = configured.indexOf(left.provider);
      const rightIndex = configured.indexOf(right.provider);
      const leftConfigured = leftIndex >= 0;
      const rightConfigured = rightIndex >= 0;
      if (leftConfigured !== rightConfigured) return leftConfigured ? -1 : 1;
      if (leftConfigured && rightConfigured && leftIndex !== rightIndex) return leftIndex - rightIndex;
    }
    return providerPreference(left.provider, null) - providerPreference(right.provider, null)
      || left.provider.localeCompare(right.provider);
  });
}

async function handleGetModels(refresh = false) {
  const config = loadConfig();
  const executable = await getExecutableCatalog(refresh);
  const runtime = runtimeCatalogSnapshot;
  const executableModels = mergeExecutableRuntimeMetadata(executable.models, runtime?.models ?? []);
  const candidates = buildModelCandidates(executableModels, config);
  const executableIds = new Set(executableModels.map((model) => model.fullId));
  const runtimeOnlyModels = (runtime?.models.filter((model) => !executableIds.has(model.fullId)) ?? [])
    .map((model) => ({ ...model, classification: classifyModel(model) }));
  const classifications = new Map(executableModels.map((model) => [model.fullId, classifyModel(model)]));
  const unclassifiedModels = executableModels
    .filter((model) => classifications.get(model.fullId)?.status === "unclassified")
    .map((model) => ({ ...model, classification: classifications.get(model.fullId) }));
  const candidateIds = new Set(candidates.map((candidate) => candidate.id));
  const allowedProviders = new Set(getAllowedProviders(executableModels, config));
  const excludedProviders = new Set(getExcludedProviders(executableModels, config));
  const rejectedModels = executableModels
    .filter((model) => !candidateIds.has(model.fullId))
    .map((model) => {
      const classification = classifications.get(model.fullId)!;
      const reason = classification.status === "unclassified"
        ? classification.reason
        : excludedProviders.has(model.provider)
          ? `Provider ${model.provider} is excluded`
          : !allowedProviders.has(model.provider)
            ? `Provider ${model.provider} is not selected`
            : isExcludedModel(model, config)
              ? "Model matches an exclusion pattern"
              : "Model is not eligible";
      return { ...model, classification, rejection_reason: reason };
    });
  return {
    ok: true,
    config,
    cli: executable.cli.label,
    cli_path: executable.cli.argsPrefix[0] || executable.cli.command,
    cli_package_version: executable.cliPackageVersion,
    discovery_error: executable.lastError,
    cache: {
      ttl_ms: MODEL_CATALOG_TTL_MS,
      refreshed_at: executable.refreshedAt,
      last_attempt_at: executable.lastAttemptAt,
      stale: executable.stale,
    },
    runtime_catalog: {
      captured_at: runtime?.capturedAt ?? null,
      current_model: runtime?.currentModel?.fullId ?? null,
      current_classification: runtime?.currentModel ? classifyModel(runtime.currentModel) : null,
      model_count: runtime?.models.length ?? 0,
    },
    executable_catalog: { model_count: executable.models.length, candidate_count: candidates.length },
    effective_exclusions: {
      providers: [...excludedProviders],
      models: normalizeModelExclusionList(config.excluded_models),
    },
    providers: providerSummaries(executableModels, config),
    models: executableModels,
    runtime_only_models: runtimeOnlyModels,
    unclassified_models: unclassifiedModels,
    rejected_models: rejectedModels,
    candidates,
  };
}

const registerAddonConfigApi = (globalThis as Record<string, unknown>).__piclaw_registerAddonConfigApi as AddonConfigApiRegistrar | undefined;
if (typeof registerAddonConfigApi === "function") {
  registerAddonConfigApi(EXTENSION_ID, "config", {
    get: async () => ({ ok: true, config: loadConfig() }),
    set: async (payload) => {
      const body = payload && typeof payload === "object" ? payload as Partial<DelegateConfig> : {};
      const next = await kv().write(() => {
        const current = loadConfig();
        const next = normalizeConfig({
          ...current,
          ...(Object.prototype.hasOwnProperty.call(body, "searchable_providers") ? { searchable_providers: body.searchable_providers } : {}),
          ...(Object.prototype.hasOwnProperty.call(body, "excluded_providers") ? { excluded_providers: body.excluded_providers } : {}),
          ...(Object.prototype.hasOwnProperty.call(body, "excluded_models") ? { excluded_models: body.excluded_models } : {}),
        });
        saveConfig(next);
        return next;
      });
      return { ok: true, config: next };
    },
  }, ADDON_DIR);
  registerAddonConfigApi(EXTENSION_ID, "models", {
    get: async () => handleGetModels(false),
    set: async () => handleGetModels(true),
  }, ADDON_DIR);
}

// ── Extension ──────────────────────────────────────────────────

export default function (pi: any) {
  // Factory-local: a group lasts until all its calls exit. Ordinals are never reused
  // within a group, including across fallback attempts; other sessions are independent.
  let groupTotal = 0;
  const runningDelegates = new Map<symbol, (total: number) => void>();
  const refreshProgress = () => {
    for (const publish of runningDelegates.values()) publish(groupTotal);
  };
  const updateRuntimeCatalog = async (ctx: any) => {
    runtimeCatalogSnapshot = await captureRuntimeCatalog(ctx, runtimeCatalogSnapshot);
  };
  pi.on("session_start", async (_event: unknown, ctx: any) => updateRuntimeCatalog(ctx));
  pi.on("model_select", async (_event: unknown, ctx: any) => updateRuntimeCatalog(ctx));

  const HINT = [
    "## Delegate tool",
    "Use `delegate` for self-contained work in a fresh ephemeral Pi context; it has no conversation history.",
    "Delegate can launch only models in its Settings-approved candidate list: an operator-approved provider, an ordered classified model ID, an exact child-CLI executable entry, and no matching exclusion. No providers are approved by default.",
    "Automatic selection never selects above the current model's verified tier.",
    "The child receives the requested tool profile (read-only, standard, full, or an explicit list); do not assume every installed Piclaw add-on tool is available.",
    "Pass workspace text files or content-sniffed JPEG, PNG, GIF, WebP, and BMP images in `files`; extract or convert PDF, SVG, archives, audio, video, and other binaries first.",
    "An explicit `model` must be an exact entry in the same approved candidate list; it can bypass automatic tier selection but cannot bypass provider approval, model classification, exclusions, executability, or image-capability validation.",
    "Proactively delegate when a task is self-contained and does not need conversation history.",
    "When you call delegate, produce a visible one-sentence timeline update that says what you are delegating and why; do not leave the user with zero feedback while the delegated process runs.",
    "When the user asks to double-check, verify, or review your answer, use `task_category: judge`; it selects another family when a valid tier-safe executable alternative exists.",
  ].join("\n");

  pi.on("before_agent_start", async (event: { systemPrompt: string }, ctx: any) => {
    await updateRuntimeCatalog(ctx);
    // Auto-activate delegate tool so it's available without manual activate_tools
    const active = pi.getActiveTools();
    if (!active.includes("delegate")) {
      pi.setActiveTools([...active, "delegate"]);
    }
    return { systemPrompt: `${event.systemPrompt}\n\n${HINT}` };
  });

  pi.registerTool({
    name: "delegate",
    label: "Delegate to Model",
    description:
      "Delegate a task to a cheaper/faster model in a fresh context. " +
      "The delegate has its own tool access (read, grep, bash, etc.) but no conversation history. " +
      "Use for: summarizing files, quick questions, code generation, data extraction, codebase exploration, " +
      "or any task that doesn't require the full conversation context. " +
      "Every automatic, explicit, and fallback attempt is restricted to the Settings-approved candidate list; " +
      "automatic selection also never exceeds the current model's classified tier.",
    parameters: {
      type: "object",
      required: ["prompt"],
      properties: {
        prompt: {
          type: "string",
          description: "The task to delegate. Be specific — the delegate has no conversation history.",
        },
        task_category: {
          type: "string",
          enum: ["quick", "summarize", "code", "analyze", "reason", "judge"],
          description: "Task category: quick, summarize, code, analyze, reason, or judge. Default: summarize.",
        },
        model: {
          type: "string",
          description: "Exact approved provider/model selection. It must appear in Settings → Delegate → Approved delegate models. It can bypass automatic tier selection but cannot bypass provider approval, ordered model classification, exclusions, executability, or image-capability checks.",
        },
        files: {
          type: "array",
          items: { type: "string" },
          description: "Workspace files to include. Text is inlined up to 100KB; only native PNG, JPEG, GIF, WebP, and BMP images are attached.",
        },
        tools: {
          type: "string",
          description: "Tool profile (read_only, standard, full) or a comma-separated child Pi built-in list. MCP is available only when its explicit adapter is installed. Default: standard.",
        },
        system_prompt: {
          type: "string",
          description: "Custom system prompt override.",
        },
        timeout_sec: {
          type: "integer",
          description: `Timeout in seconds. Default: ${DEFAULT_TIMEOUT_SEC}`,
          minimum: 10,
          maximum: 300,
        },
      },
    },

    async execute(_toolCallId: string, params: any, signal: AbortSignal | undefined, onUpdate: any, ctx: any) {
      const requestedTimeout = Number(params.timeout_sec ?? DEFAULT_TIMEOUT_SEC);
      const timeout = Number.isFinite(requestedTimeout) ? Math.min(300, Math.max(10, requestedTimeout)) : DEFAULT_TIMEOUT_SEC;
      const deadlineAt = Date.now() + timeout * 1_000;
      const remainingBudget = (stage: string): number => {
        if (signal?.aborted) throw new Error(`Delegate aborted during ${stage}`);
        const remaining = deadlineAt - Date.now();
        if (remaining <= 0) throw new Error(`Delegate timed out after ${timeout}s during ${stage}`);
        return remaining;
      };

      const rawCategory = (params.task_category as TaskCategory) || "summarize";
      const category: TaskCategory = VALID_CATEGORIES.has(rawCategory) ? rawCategory : "summarize";
      const config = loadConfig();
      runtimeCatalogSnapshot = await captureRuntimeCatalog(ctx, runtimeCatalogSnapshot);
      remainingBudget("runtime model refresh");
      const selectedCli = pinDelegateCliCommand(resolveDelegateCliCommand());
      const executableCatalog = await getExecutableCatalog(false, Math.min(20_000, remainingBudget("model discovery")), signal, selectedCli);
      remainingBudget("model discovery");
      const discoveredModels = mergeExecutableRuntimeMetadata(executableCatalog.models, runtimeCatalogSnapshot.models);
      const discoveredCandidates = buildModelCandidates(discoveredModels, config);
      const currentModelId = ctx?.model ? `${ctx.model.provider}/${ctx.model.id}` : undefined;
      const maxTier = getCurrentTier(ctx);
      const requestedModel = typeof params.model === "string" ? params.model.trim() : "";
      const explicitValidation = requestedModel
        ? validateExplicitDelegateModel(requestedModel, discoveredModels, runtimeCatalogSnapshot.models, config)
        : null;
      const explicitModel = explicitValidation?.model ?? null;

      if (requestedModel && explicitValidation?.error) delegateFailure(explicitValidation.error);
      if (!requestedModel && maxTier === null) {
        const classification = getCurrentClassification(ctx);
        delegateFailure(`Delegate cannot safely auto-select from unclassified current model ${currentModelId || "(none)"}. ${classification?.reason || "No current model metadata is available."} Select an exact model from Settings → Delegate → Approved delegate models.`);
      }
      if (!requestedModel && discoveredCandidates.length === 0) {
        const discoveryNote = executableCatalog.lastError ? ` Discovery error: ${executableCatalog.lastError}` : "";
        delegateFailure(`No approved executable Delegate model candidates remain. Approve at least one provider in Settings → Delegate and review model exclusions.${discoveryNote}`);
      }

      // Explicit model selection can bypass automatic tier selection only. Provider
      // approval, ordered classification, executable-catalog membership, and
      // model exclusions define one shared approved candidate list.
      const model = requestedModel || selectModel(category, maxTier!, currentModelId, discoveredCandidates);
      if (!model) delegateFailure("Delegate could not select an executable model within the current model tier.");

      // Child capabilities are intentionally narrow: built-ins plus the one
      // explicitly discovered MCP adapter. Workspace add-on extensions are not inherited.
      const { toolsArg, mcpPath } = buildDelegateChildTools(params.tools, findMcpAdapter());

      // Separate files into text (inline in prompt) and binary (pass as @file args)
      let fullPrompt = params.prompt;
      const attachmentArgs: string[] = []; // @file args for binary/image files
      let hasVisualInput = false;

      if (params.files && params.files.length > 0) {
        const textContents: string[] = [];
        for (const filePath of params.files) {
          remainingBudget(`file inspection (${filePath})`);
          let prepared: PreparedDelegateFile;
          try {
            prepared = prepareDelegateFile(filePath);
          } catch (err) {
            delegateFailure(`Failed to inspect ${filePath}: ${err instanceof Error ? err.message : String(err)}`);
          }
          const { resolved, size, inspection } = prepared;
          if (inspection.kind === "unsupported") {
            delegateFailure(`Unsupported Delegate file ${filePath} (${inspection.format}). ${inspection.reason}`);
          }
          if (inspection.kind === "image") {
            // Pi accepts only native PNG, JPEG, GIF, WebP, and BMP attachments.
            attachmentArgs.push(`@${resolved}`);
            hasVisualInput = true;
            continue;
          }
          if (size > MAX_TEXT_FILE_BYTES) {
            delegateFailure(`File too large for inlining: ${filePath} (${(size / 1024).toFixed(0)}KB, max ${MAX_TEXT_FILE_BYTES / 1024}KB). Use the delegate's tools to read it instead.`);
          }
          try {
            const content = readFileSync(resolved, "utf-8");
            textContents.push(`\n--- ${filePath} ---\n${content}\n---`);
          } catch (err) {
            delegateFailure(`Failed to read ${filePath}: ${err instanceof Error ? err.message : String(err)}`);
          }
        }
        if (textContents.length > 0) {
          fullPrompt = `${fullPrompt}\n\nFile contents:${textContents.join("\n")}`;
        }
      }

      // Visual inputs require an explicitly vision-capable executable model. For
      // auto-selection, prefer the analyze target tier when the original pick is light.
      let effectiveModel = model;
      let effectiveCategory: TaskCategory = category;
      let eligibleCandidates = discoveredCandidates;
      if (hasVisualInput) {
        if (explicitModel) {
          if (explicitModel.supportsImages === false) {
            delegateFailure(`Delegate model ${explicitModel.fullId} explicitly reports images=no and cannot accept native image attachments.`);
          }
          if (explicitModel.supportsImages !== true) {
            delegateFailure(`Delegate model ${explicitModel.fullId} has no confirmed image-capability metadata; image delegation fails closed.`);
          }
        } else {
          const visualCandidates = discoveredCandidates.filter((candidate) => candidate.supportsImages === true);
          eligibleCandidates = visualCandidates;
          const selectedCandidate = discoveredCandidates.find((candidate) => candidate.id === model);
          if (selectedCandidate?.tier !== undefined && selectedCandidate.tier < 3) effectiveCategory = "analyze";
          effectiveModel = selectModel(effectiveCategory, maxTier!, currentModelId, visualCandidates);
          if (!effectiveModel) {
            const rejected = discoveredCandidates
              .filter((candidate) => candidate.supportsImages !== true)
              .slice(0, 8)
              .map(describeImageCapability)
              .filter(Boolean)
              .join(", ");
            delegateFailure(`No image-capable Delegate model is available within the verified current-model tier.${rejected ? ` Rejected: ${rejected}.` : ""}`);
          }
        }
      }

      // Disclosed reroutes must respect the same image and automatic tier gates
      // as launched children. Explicit requests bypass tier targeting only.
      eligibleCandidates = eligibleCandidates.filter((candidate) =>
        (!hasVisualInput || candidate.supportsImages === true)
        && (Boolean(requestedModel) || candidate.tier <= Math.min(maxTier!, CATEGORY_TARGET_TIER[effectiveCategory])),
      );

      // Build static pi args shared across model attempts (the model is set per attempt).
      const staticArgs: string[] = [];
      if (mcpPath) staticArgs.push("-e", mcpPath);
      const capabilityHints = [
        "Web search: run 'bun /workspace/.pi/skills/web-search/web-search.ts --query \"QUERY\" --fetch true --fetch-limit 3' to search the web.",
        "Web search summary: run 'bun /workspace/.pi/skills/web-search-summary/web-search-summary.ts --query \"QUERY\"' for summarized results.",
        ...(mcpPath ? ["MCP: use the mcp tool with action 'call_tool' to call MCP server tools."] : []),
      ].join("\n");
      staticArgs.push("--append-system-prompt", capabilityHints);
      if (params.system_prompt) staticArgs.push("--system-prompt", params.system_prompt);
      for (const att of attachmentArgs) staticArgs.push(att);

      // Ordered models to attempt. An explicit selection is used verbatim (no fallback);
      // automatic fallback covers catalogue/setup incompatibility only. Credential
      // failure must not change the account/provider after logout or expiry.
      const modelChain = requestedModel
        ? [effectiveModel]
        : buildDelegateModelChain(effectiveCategory, maxTier!, currentModelId, eligibleCandidates);
      if (!modelChain.includes(effectiveModel)) modelChain.unshift(effectiveModel);

      // One total deadline covers discovery, setup, and all attempts. Setup/model-unavailable
      // failures may fall back, while auth/execution/protocol failures stop immediately.
      remainingBudget("delegate setup");
      const attemptFailures: Array<{ model: string; kind: DelegateFailureKind; message: string }> = [];
      let lastAttemptedModel = effectiveModel;
      const progressId = Symbol();
      let ordinal = 0;
      try {
        for (let attempt = 0; attempt < modelChain.length; attempt += 1) {
          const attemptModel = modelChain[attempt];
          // Keep a final fail-closed gate next to process creation so future
          // selection/fallback changes cannot launch a model outside policy.
          assertApprovedDelegateModelAttempt(attemptModel, eligibleCandidates);
          if (delegateCliDiagnostics(selectedCli).identity !== executableCatalog.cliIdentity) throw new Error("Delegate CLI changed after discovery; retry with the current release.");
          lastAttemptedModel = attemptModel;
          remainingBudget("attempt setup");
          let progress: DelegateProcessProgress | undefined;
          const publishProgress = (total: number) => {
            setDelegateProgress(ctx, { model: attemptModel, category, prompt: params.prompt }, ordinal, total);
            const text = buildDelegateStatusUpdate(attemptModel, params.prompt, ordinal, total);
            try {
              onUpdate?.(result(progress ? `${text}\nProgress: ${progress.message}` : text, {
                status: progress?.type ?? "starting", model: attemptModel, attempt: attempt + 1,
                ...(progress ? { tool: progress.toolName, is_error: progress.isError } : {}),
              }));
            } catch { /* A stale progress callback must not fail another running delegate. */ }
          };
          if (!ordinal) ordinal = ++groupTotal;
          runningDelegates.set(progressId, publishProgress);
          refreshProgress();
          const piArgs = ["--mode", "json", "--no-session", "--no-extensions", "--model", attemptModel, "--tools", toolsArg, ...staticArgs];
          // Read at launch so later calls and fallback attempts follow session changes.
          const thinkingLevel = pi.getThinkingLevel?.();
          if (thinkingLevel !== undefined) piArgs.push("--thinking", thinkingLevel);
          // Progress callbacks are synchronous and may change files; fence again after publishing.
          if (delegateCliDiagnostics(selectedCli).identity !== executableCatalog.cliIdentity) throw new Error("Delegate CLI changed after discovery; retry with the current release.");
          const processResult = await runDelegateProcess(
            piArgs,
            fullPrompt,
            remainingBudget("child launch"),
            signal,
            (update) => { progress = update; publishProgress(groupTotal); },
            selectedCli,
          );

          const processFailure = delegateProcessFailure(processResult);
          const reportedModelFailure = validateDelegateResponseModel(
            attemptModel,
            processResult.provider,
            processResult.model,
            eligibleCandidates,
          );
          const responseModelFailure = validateDelegateResponseModel(
            attemptModel,
            processResult.provider,
            processResult.responseModel,
            eligibleCandidates,
          );
          const rawFailureMessage = processFailure || reportedModelFailure || responseModelFailure;
          const failureMessage = rawFailureMessage ? formatDelegateFailure(rawFailureMessage, attemptModel.split('/')[0]) : rawFailureMessage;
          if (failureMessage) {
            const kind = classifyDelegateFailure(failureMessage);
            attemptFailures.push({ model: attemptModel, kind, message: failureMessage });
            if (!requestedModel && isRetryableDelegateFailure(kind) && attempt < modelChain.length - 1) continue;
            const chain = attemptFailures.map((failure) => `${failure.model} [${failure.kind}]: ${failure.message}`).join(" -> ");
            delegateFailure(`Delegate failed on ${attemptModel}. Attempt chain: ${chain}`);
          }

          const trimmed = processResult.text.trim();
          const responseWasTruncated = processResult.outputTruncated || trimmed.length > MAX_OUTPUT_CHARS;
          const output = trimmed.length > MAX_OUTPUT_CHARS
            ? `${trimmed.slice(0, MAX_OUTPUT_CHARS)}\n\n[truncated at ${MAX_OUTPUT_CHARS} chars]`
            : trimmed;
          const actualModel = processResult.model
            ? (processResult.model.includes("/") || !processResult.provider ? processResult.model : `${processResult.provider}/${processResult.model}`)
            : attemptModel;
          const fallbackNote = attempt > 0
            ? `\n\n_(auto-fell back to \`${attemptModel}\` after ${attempt} classified setup/model failure${attempt > 1 ? "s" : ""})_`
            : "";
          return result(`**Delegated to \`${attemptModel}\` [${category}]:**\n\n${output}${fallbackNote}`, {
            model: attemptModel,
            actual_model: actualModel,
            response_model: processResult.responseModel,
            category,
            explicit_override: Boolean(requestedModel),
            fallback_count: attempt,
            attempts: [...attemptFailures, { model: attemptModel, status: "success" }],
            stop_reason: processResult.stopReason,
            usage: processResult.usage,
            tool_calls: processResult.toolCallCount,
            output_truncated: responseWasTruncated,
            ephemeral_session: true,
          });
        }
        const chain = attemptFailures.map((failure) => `${failure.model} [${failure.kind}]: ${failure.message}`).join(" -> ");
        delegateFailure(`Delegate exhausted ${modelChain.length} model attempt(s). Attempt chain: ${chain || "none"}`);
      } catch (err: any) {
        if (err?.name === "AbortError" || signal?.aborted) {
          delegateFailure(`Delegate aborted (model: ${lastAttemptedModel}).`);
        }
        if (String(err?.message || err).includes("timed out")) {
          delegateFailure(`Delegate timed out after ${timeout}s (model: ${lastAttemptedModel}).`);
        }
        throw err;
      } finally {
        if (runningDelegates.delete(progressId)) {
          if (runningDelegates.size) refreshProgress();
          else {
            groupTotal = 0;
            clearDelegateProgress(ctx);
          }
        }
      }
    },
  });
}

export interface DelegateUsageSummary {
  input: number;
  output: number;
  cacheRead: number;
  cacheWrite: number;
  reasoning: number;
  totalTokens: number;
  /** SDK amounts are USD; unknown/mixed-source values are never a provider bill. */
  cost: number | null;
  costCurrency: "USD" | null;
  costProvenance: "provider_reported" | "catalogue_estimate" | "mixed" | "unavailable";
  providerCostTotal: number | null;
  catalogueCostTotal: number | null;
  unknownCostCount: number;
}

export interface DelegateProcessProgress {
  type: "text" | "tool_start" | "tool_end" | "retry";
  message: string;
  toolName?: string;
  isError?: boolean;
}

export interface DelegateProcessResult {
  text: string;
  stderr: string;
  exitCode: number | null;
  sessionId: string | null;
  provider: string | null;
  model: string | null;
  responseModel: string | null;
  stopReason: string | null;
  errorMessage: string | null;
  usage: DelegateUsageSummary;
  eventCount: number;
  malformedEventCount: number;
  toolCallCount: number;
  outputTruncated: boolean;
}

export interface DelegateCliOverride {
  command: string;
  argsPrefix?: string[];
}

const MAX_JSON_LINE_CHARS = 2_000_000;
const MAX_JSON_EVENTS = 20_000;
const MAX_STDERR_CHARS = 64_000;
const MAX_PROGRESS_EVENTS = 128;

function emptyDelegateUsage(): DelegateUsageSummary {
  return { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, reasoning: 0, totalTokens: 0, cost: null, costCurrency:null, costProvenance:"unavailable", providerCostTotal:null, catalogueCostTotal:null, unknownCostCount:0 };
}

function numeric(value: unknown): number {
  return typeof value === "number" && Number.isFinite(value) ? value : 0;
}

function textFromAssistantMessage(message: any): string {
  if (!Array.isArray(message?.content)) return "";
  return message.content
    .filter((block: any) => block?.type === "text" && typeof block.text === "string")
    .map((block: any) => block.text)
    .join("\n");
}

class DelegateJsonAccumulator {
  private finalText = "";
  private provider: string | null = null;
  private model: string | null = null;
  private responseModel: string | null = null;
  private stopReason: string | null = null;
  private errorMessage: string | null = null;
  private sessionId: string | null = null;
  private usage = emptyDelegateUsage();
  private eventCount = 0;
  private malformedEventCount = 0;
  private toolCallCount = 0;
  private outputTruncated = false;
  private streamedTextChars = 0;
  private lastTextProgressAt = 0;
  private progressEvents = 0;
  private capturedAssistantKeys = new Set<string>();

  constructor(private readonly onProgress?: (progress: DelegateProcessProgress) => void) {}

  markProtocolOverflow(): void {
    this.outputTruncated = true;
    this.malformedEventCount += 1;
  }

  private progress(progress: DelegateProcessProgress): void {
    if (!this.onProgress || this.progressEvents >= MAX_PROGRESS_EVENTS) return;
    this.progressEvents += 1;
    this.onProgress(progress);
  }

  private captureAssistant(message: any): void {
    if (message?.role !== "assistant") return;
    const text = textFromAssistantMessage(message);
    const key = typeof message.responseId === "string" && message.responseId
      ? message.responseId
      : `${message.timestamp || ""}|${message.provider || ""}|${message.model || ""}|${message.stopReason || ""}|${text}`;
    if (this.capturedAssistantKeys.has(key)) return;
    this.capturedAssistantKeys.add(key);
    if (text.length > MAX_OUTPUT_CHARS * 2) {
      this.finalText = text.slice(0, MAX_OUTPUT_CHARS * 2);
      this.outputTruncated = true;
    } else {
      this.finalText = text;
    }
    this.provider = typeof message.provider === "string" ? message.provider : this.provider;
    this.model = typeof message.model === "string" ? message.model : this.model;
    this.responseModel = typeof message.responseModel === "string" ? message.responseModel : this.responseModel;
    this.stopReason = typeof message.stopReason === "string" ? message.stopReason : this.stopReason;
    this.errorMessage = typeof message.errorMessage === "string" && message.errorMessage.trim()
      ? message.errorMessage.trim()
      : this.errorMessage;
    const usage = message.usage;
    if (usage && typeof usage === "object") {
      this.usage.input += numeric(usage.input);
      this.usage.output += numeric(usage.output);
      this.usage.cacheRead += numeric(usage.cacheRead);
      this.usage.cacheWrite += numeric(usage.cacheWrite);
      this.usage.reasoning += numeric(usage.reasoning);
      this.usage.totalTokens += numeric(usage.totalTokens);

    }
    const amount=usage?.cost?.total,known=typeof amount==='number'&&Number.isFinite(amount)&&amount>=0;
    if(known&&usage.cost.totalFromProvider===true)this.usage.providerCostTotal=(this.usage.providerCostTotal??0)+amount;
    else if(known&&(amount>0||usage.documentedFree===true))this.usage.catalogueCostTotal=(this.usage.catalogueCostTotal??0)+amount;
    else this.usage.unknownCostCount++;
    const actual=this.usage.providerCostTotal,estimate=this.usage.catalogueCostTotal;
    this.usage.cost=this.usage.unknownCostCount?null:(actual??0)+(estimate??0);
    this.usage.costCurrency=actual!==null||estimate!==null?'USD':null;
    this.usage.costProvenance=this.usage.unknownCostCount?'unavailable':actual!==null&&estimate!==null?'mixed':actual!==null?'provider_reported':'catalogue_estimate';

  }

  consumeLine(line: string): void {
    const trimmed = line.trim();
    if (!trimmed) return;
    if (this.eventCount >= MAX_JSON_EVENTS) {
      this.outputTruncated = true;
      return;
    }
    let event: any;
    try {
      event = JSON.parse(trimmed);
    } catch {
      this.malformedEventCount += 1;
      return;
    }
    this.eventCount += 1;
    if (event?.type === "session" && typeof event.id === "string") this.sessionId = event.id;
    if (event?.type === "message_end") this.captureAssistant(event.message);
    if (event?.type === "turn_end") this.captureAssistant(event.message);
    if (event?.type === "message_update" && event.assistantMessageEvent?.type === "text_delta") {
      this.streamedTextChars += String(event.assistantMessageEvent.delta || "").length;
      if (this.streamedTextChars - this.lastTextProgressAt >= 2_000) {
        this.lastTextProgressAt = this.streamedTextChars;
        this.progress({ type: "text", message: `Received ${this.streamedTextChars.toLocaleString()} response characters` });
      }
    }
    if (event?.type === "tool_execution_start") {
      this.toolCallCount += 1;
      const toolName = String(event.toolName || "tool");
      this.progress({ type: "tool_start", toolName, message: `Running ${toolName}` });
    }
    if (event?.type === "tool_execution_end") {
      const toolName = String(event.toolName || "tool");
      this.progress({ type: "tool_end", toolName, isError: Boolean(event.isError), message: `${event.isError ? "Failed" : "Completed"} ${toolName}` });
    }
    if (event?.type === "auto_retry_start") {
      this.progress({ type: "retry", message: `Provider retry ${numeric(event.attempt)}/${numeric(event.maxAttempts)}` });
    }
  }

  result(stderr: string, exitCode: number | null): DelegateProcessResult {
    return {
      text: this.finalText,
      stderr,
      exitCode,
      sessionId: this.sessionId,
      provider: this.provider,
      model: this.model,
      responseModel: this.responseModel,
      stopReason: this.stopReason,
      errorMessage: this.errorMessage,
      usage: this.usage,
      eventCount: this.eventCount,
      malformedEventCount: this.malformedEventCount,
      toolCallCount: this.toolCallCount,
      outputTruncated: this.outputTruncated,
    };
  }
}

export function parseDelegateJsonOutput(output: string): DelegateProcessResult {
  const accumulator = new DelegateJsonAccumulator();
  for (const line of String(output || "").split("\n")) accumulator.consumeLine(line);
  return accumulator.result("", 0);
}

export function delegateProcessFailure(processResult: DelegateProcessResult): string | null {
  const failures: string[] = [];
  if (processResult.exitCode !== 0) failures.push(`Process exited with code ${processResult.exitCode}`);
  if (processResult.eventCount === 0) failures.push("No valid JSON events were emitted");
  if (processResult.malformedEventCount > 0) failures.push(`${processResult.malformedEventCount} malformed JSON event(s)`);
  if (processResult.stopReason === "error" || processResult.stopReason === "aborted") {
    failures.push(`Assistant stopped with ${processResult.stopReason}`);
  }
  if (processResult.errorMessage) failures.push(processResult.errorMessage);
  if (processResult.stderr.trim() && failures.length > 0) failures.push(processResult.stderr.trim());
  if (!processResult.text.trim() && failures.length === 0) failures.push("Delegate returned an empty structured response");
  return failures.length > 0 ? [...new Set(failures)].join("; ") : null;
}

/** Run Pi JSON mode with a CLI deadline and cleanup of its owned POSIX group.
 * Descendants that escape that group are not covered. */
export function runDelegateProcess(
  piArgs: string[],
  prompt: string,
  timeoutMs: number,
  signal?: AbortSignal,
  onProgress?: (progress: DelegateProcessProgress) => void,
  cliOverride?: DelegateCliOverride,
): Promise<DelegateProcessResult> {
  return new Promise((resolvePromise, reject) => {
    if (signal?.aborted) {
      const error = new Error("Aborted");
      error.name = "AbortError";
      reject(error);
      return;
    }
    const resolvedCli = cliOverride ?? resolveDelegateCliCommand();
    const owned = spawnDelegateChild(resolvedCli.command, [...(resolvedCli.argsPrefix ?? []), ...piArgs], "pipe", () => { cleanup(); forceSettleTimer = setTimeout(() => { if(settled)return; settled=true; child.stdout?.destroy();child.stderr?.destroy();reject(new Error("Delegate retained pipes after CLI exit.")); }, 1000); });
    const { child } = owned;
    const accumulator = new DelegateJsonAccumulator(event => { if (!settled && !terminationError) onProgress?.(event); });
    const decoder = new StringDecoder("utf8");
    let lineBuffer = "";
    let stderr = "";
    let settled = false;
    let terminationError: Error | null = null;
    let killTimer: ReturnType<typeof setTimeout> | null = null;
    let forceSettleTimer: ReturnType<typeof setTimeout> | null = null;

    const appendStderr = (chunk: Buffer) => {
      if (stderr.length >= MAX_STDERR_CHARS) return;
      const remaining = MAX_STDERR_CHARS - stderr.length;
      stderr += chunk.toString().slice(0, remaining);
    };
    const consumeStdout = (chunk: Buffer) => {
      lineBuffer += decoder.write(chunk);
      while (true) {
        const newline = lineBuffer.indexOf("\n");
        if (newline < 0) break;
        const line = lineBuffer.slice(0, newline);
        lineBuffer = lineBuffer.slice(newline + 1);
        if (line.length > MAX_JSON_LINE_CHARS) accumulator.markProtocolOverflow();
        else accumulator.consumeLine(line);
      }
      if (lineBuffer.length > MAX_JSON_LINE_CHARS) {
        lineBuffer = "";
        accumulator.markProtocolOverflow();
      }
    };
    child.stdout?.on("data", consumeStdout);
    child.stderr?.on("data", appendStderr);
    child.stdin?.on("error", () => { /* child exit is handled below */ });

    function cleanup(): void {
      clearTimeout(deadlineTimer);
      if (killTimer) clearTimeout(killTimer);
      if (forceSettleTimer) clearTimeout(forceSettleTimer);
      signal?.removeEventListener("abort", onAbort);
    }

    function sendSignal(childSignal: NodeJS.Signals): void {
      try { child.kill(childSignal); } catch { /* already exited */ }
    }

    function terminate(error: Error): void {
      if (settled || terminationError) return;
      terminationError = error;
      sendSignal("SIGTERM");
      if (process.platform !== "win32") {
        settled = true;
        cleanup();
        reject(error);
        return;
      }
      if (process.platform === "win32") killTimer = setTimeout(() => sendSignal("SIGKILL"), 2_000);
      forceSettleTimer = setTimeout(() => {
        if (settled) return;
        settled = true;
        cleanup();
        reject(error);
      }, 5_000);
    }

    const deadlineTimer = setTimeout(() => terminate(new Error(`timed out after ${Math.ceil(timeoutMs / 1000)}s`)), timeoutMs);
    const onAbort = () => {
      const error = new Error("Aborted");
      error.name = "AbortError";
      terminate(error);
    };
    if (signal?.aborted) onAbort();
    else signal?.addEventListener("abort", onAbort, { once: true });

    if (!terminationError) {
      child.stdin?.end(prompt);
    }

    child.on("close", (code) => {
      if (settled) return;
      settled = true;
      const tail = lineBuffer + decoder.end();
      if (tail.trim()) {
        if (tail.length > MAX_JSON_LINE_CHARS) accumulator.markProtocolOverflow();
        else accumulator.consumeLine(tail);
      }
      cleanup();
      if (terminationError) reject(terminationError);
      else resolvePromise(accumulator.result(stderr, owned.cliExitCode ?? code));
    });

    child.on("error", (error) => {
      if (settled) return;
      settled = true;
      cleanup();
      reject(error);
    });
  });
}
