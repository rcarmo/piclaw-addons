import { getPeerService } from "./runtime-service.js";
import type { AddonLocalContext } from "./compat/runtime.js";
export async function runAction(
  input: Record<string, any>,
  service = getPeerService(),
  context?: AddonLocalContext | null,
) {
  switch (input.action) {
    case "status":
      return service.dashboard(context);
    case "identity":
      return service.identity();
    case "ticket":
      await service.start();
      return { ticket: service.transport.ticket(), ...service.identity() };
    case "pair":
      return service.pair({
        clientId: String(input.client_id ?? ""),
        alias: input.alias,
        ticket: input.ticket,
      });
    case "accept":
      await service.accept(
        String(input.peer ?? ""),
        String(input.confirmation ?? ""),
      );
      break;
    case "deny":
      await service.deny(String(input.peer ?? ""));
      break;
    case "revoke":
      await service.revoke(
        String(input.peer ?? ""),
        String(input.confirmation ?? ""),
      );
      break;
    case "rotate":
      return {
        identity: await service.rotateIdentity(
          String(input.confirmation ?? ""),
        ),
      };
    case "forget":
      await service.forget(
        String(input.peer ?? ""),
        String(input.confirmation ?? ""),
      );
      break;
    case "alias":
      await service.setAlias(String(input.peer ?? ""), String(input.alias ?? ""));
      break;
    case "policy":
      await service.setPolicy(String(input.peer ?? ""), input);
      break;
    case "remote_permissions":
      return service.remotePermissions(String(input.peer ?? ""));
    case "advertise":
      await service.advertise(
        String(input.local_agent ?? ""),
        String(input.alias ?? ""),
        input.modes ?? ["queue"],
      );
      break;
    case "unadvertise":
      await service.unadvertise(String(input.alias ?? ""));
      break;
    case "session_targets":
      return service.localSessions(context);
    case "session_advertise":
      await service.sessionAdvertise({ agent: String(input.agent ?? ""), session_alias: String(input.session_alias ?? ""), chat_jid: String(input.chat_jid ?? ""), incarnation: String(input.incarnation ?? ""), modes: input.modes ?? ["queue"] }, context);
      break;
    case "session_unadvertise":
      await service.sessionUnadvertise(String(input.agent ?? ""), String(input.session_alias ?? ""), context);
      break;
    case "ping":
      return service.ping(String(input.peer ?? ""));
    case "retry":
      return service.retry(String(input.message_id ?? ""));
    case "work_send":
      return service.workSend(
        String(input.peer ?? ""),
        String(input.prompt ?? ""),
        input.request_type ?? "proposal",
        input.capabilities ?? [],
        String(input.origin_chat ?? ""),
      );
    case "work_review":
      return service.reviewWork(
        String(input.request_id ?? ""),
        String(input.result ?? ""),
        input.capabilities ?? [],
        input.approve === true,
      );
    default:
      throw new Error("Unknown Iroh Remote Peer action.");
  }
  return { ok: true };
}

export const remotePeerParameters = {
      type: "object",
      properties: {
        action: {
          type: "string",
          enum: [
            "status",
            "identity",
            "ticket",
            "pair",
            "accept",
            "deny",
            "revoke",
            "forget",
            "rotate",
            "alias",
            "policy",
            "remote_permissions",
            "advertise",
            "unadvertise",
            "session_targets",
            "session_advertise",
            "session_unadvertise",
            "ping",
            "retry",
            "work_send",
            "work_review",
          ],
        },
        client_id: { type: "string" },
        peer: { type: "string" },
        ticket: { type: "string" },
        alias: { type: "string" },
        confirmation: { type: "string" },
        expected_epoch: { type: "string" },
        expected_policy: {
          type: "object",
          properties: {
            scope: { type: "string" },
            modes: { type: "array", items: { type: "string" } },
            agents: { type: "array", items: { type: "string" } },
            files: { type: "boolean" },
            sessions: { type: "array", items: { type: "object" } },
          },
          required: ["scope", "modes", "agents", "files"],
          additionalProperties: false,
        },
        scope: {
          type: "string",
          enum: ["none", "inbox-only", "named-agents", "all-advertised"],
        },
        modes: {
          type: "array",
          items: { type: "string", enum: ["queue", "auto", "steer"] },
        },
        agents: { type: "array", items: { type: "string" } },
        sessions: { type: "array", items: { type: "object", properties: { agent: { type: "string" }, session_alias: { type: "string" }, revision: { type: "string" }, modes: { type: "array", items: { type: "string", enum: ["queue", "auto", "steer"] } } }, required: ["agent", "session_alias", "revision", "modes"], additionalProperties: false } },
        agent: { type: "string" },
        session_alias: { type: "string" },
        chat_jid: { type: "string" },
        incarnation: { type: "string" },
        files: { type: "boolean" },
        local_agent: { type: "string" },
        message_id: { type: "string" },
        prompt: { type: "string" },
        request_type: { type: "string", enum: ["proposal", "execute"] },
        capabilities: { type: "array", items: { type: "string" } },
        origin_chat: { type: "string" },
        request_id: { type: "string" },
        result: { type: "string" },
        approve: { type: "boolean" },
      },
      required: ["action"],
      additionalProperties: false,
    };
