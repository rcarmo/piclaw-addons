import { afterEach, describe, expect, test } from "bun:test";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

import goalAddon, {
  buildGoalBudgetLimitPrompt,
  buildGoalContinuationPrompt,
  buildGoalFinalizationPrompt,
  buildGoalSystemPrompt,
  buildLocalAgentMessageHeaders,
  createThreadGoal,
  flushGoalPromptDispatchesForTests,
  goalResponse,
  loadThreadGoal,
  resetGoalAddonForTests,
  resolveActiveChatJid,
  setGoalPromptSenderForTests,
} from "./index.ts";
import { withChatContext } from "./compat/chat-context.ts";
import { goalDeadlineCheckpointProvider } from "./deadline-checkpoint.ts";

const addonDir = import.meta.dir;

afterEach(async () => {
  await flushGoalPromptDispatchesForTests();
  resetGoalAddonForTests();
  delete process.env.PICLAW_INTERNAL_SECRET;
  delete process.env.PICLAW_WEB_INTERNAL_SECRET;
  delete (globalThis as { __piclawRuntimeInterop?: unknown }).__piclawRuntimeInterop;
  delete (globalThis as { __piclaw_runtime?: unknown }).__piclaw_runtime;
  delete (globalThis as { __PICLAW_BROADCAST_EVENT__?: unknown }).__PICLAW_BROADCAST_EVENT__;
  delete (globalThis as { __piclaw_planSidebarApi?: unknown }).__piclaw_planSidebarApi;
  delete (globalThis as { __piclaw_registerAddonConfigApi?: unknown }).__piclaw_registerAddonConfigApi;
});

function createHarness(options: { confirm?: boolean; pending?: boolean; idle?: boolean; mockPromptSender?: boolean } = {}) {
  const commands = new Map<string, any>();
  const tools = new Map<string, any>();
  const handlers: Array<{ event: string; handler: (...args: any[]) => any }> = [];
  const sentUserMessages: Array<{ content: unknown; options?: unknown }> = [];
  const sentMessages: Array<{ message: unknown; options?: unknown }> = [];
  const notifications: Array<{ message: string; level: string }> = [];
  const confirmations: string[] = [];

  const api = {
    on(event: string, handler: (...args: any[]) => any) { handlers.push({ event, handler }); },
    registerTool(tool: any) { tools.set(tool.name, tool); },
    registerCommand(name: string, command: any) { commands.set(name, command); },
    sendMessage(message: unknown, options?: unknown) { sentMessages.push({ message, options }); },
    sendUserMessage(content: unknown, options?: unknown) { sentUserMessages.push({ content, options }); },
  } as any;

  if (options.mockPromptSender !== false) {
    setGoalPromptSenderForTests(async (_goal, content) => {
      sentUserMessages.push({ content, options: { via: "local-agent-endpoint" } });
    });
  }

  const ctx = {
    ui: {
      notify(message: string, level = "info") { notifications.push({ message, level }); },
      async confirm(message: string) { confirmations.push(message); return options.confirm === true; },
    },
    sessionManager: { getSessionDir: () => "/tmp/web_default" },
    isIdle: () => options.idle !== false,
    hasPendingMessages: () => options.pending === true,
  } as any;

  goalAddon(api);
  return { api, commands, tools, handlers, sentUserMessages, sentMessages, notifications, confirmations, ctx };
}

function installRuntimeKvStore(): void {
  const values = new Map<string, unknown>();
  const storageKey = (extensionId: string, name: string, scope = "chat", scopeKey = "") => `${extensionId}:${scope}:${scopeKey}:${name}`;
  (globalThis as any).__piclawRuntimeInterop = { getExtensionKvStore: () => ({
    get: (extensionId: string, name: string, scope?: string, scopeKey?: string) => values.get(storageKey(extensionId, name, scope, scopeKey)) ?? null,
    set: (extensionId: string, name: string, value: unknown, scope?: string, scopeKey?: string) => { values.set(storageKey(extensionId, name, scope, scopeKey), structuredClone(value)); },
    delete: (extensionId: string, name: string, scope?: string, scopeKey?: string) => values.delete(storageKey(extensionId, name, scope, scopeKey)),
    list: () => [],
    clear: () => { const count = values.size; values.clear(); return count; },
  }) };
}

function customMessageText(message: unknown): string {
  const content = (message as any)?.content;
  if (Array.isArray(content)) {
    return content
      .map((part) => part?.type === "text" && typeof part.text === "string" ? part.text : "")
      .filter(Boolean)
      .join("\n");
  }
  return String(content ?? "");
}

test("goal addon exports an extension entrypoint", () => {
  expect(typeof goalAddon).toBe("function");
});

test("goal manifest declares the web entry", () => {
  const manifest = JSON.parse(readFileSync(resolve(addonDir, "package.json"), "utf8")) as any;
  expect(manifest.name).toBe("@rcarmo/piclaw-addon-goal");
  expect(manifest.pi?.web?.entries).toEqual(["web/index.ts"]);
  expect(manifest.pi?.runtime).toEqual({ entries: ["runtime.ts"], load: "startup" });
});

test("goal compat storage avoids runtime source imports", () => {
  const source = readFileSync(resolve(addonDir, "compat", "extension-kv.ts"), "utf8");
  expect(source).not.toContain("require(");
  expect(source).not.toContain("piclaw/runtime/src");
});

test("goal status and stop-reason schemas use string enums", () => {
  const { tools } = createHarness();
  expect(tools.get("update_goal").parameters.properties.status).toMatchObject({
    type: "string",
    enum: ["complete", "blocked"],
  });
  expect(tools.get("goal_stop").parameters.properties.reason).toMatchObject({
    type: "string",
    enum: ["plan_complete_unverified", "no_progress", "user_needed", "external_blocked", "other"],
  });
});

test("goal README documents Codex-compatible tools and statuses", () => {
  const readme = readFileSync(resolve(addonDir, "README.md"), "utf8");
  expect(readme).toContain("get_goal");
  expect(readme).toContain("create_goal");
  expect(readme).toContain("update_goal");
  expect(readme).toContain("budget_limited");
  expect(readme).toContain("blocked");
});

test("goal web pane targets the thread-goal addon API", () => {
  const source = readFileSync(resolve(addonDir, "web", "index.ts"), "utf8");
  expect(source).toContain("const API = `/agent/addons/api/${ADDON_ID}/goal`");
  expect(source).toContain("registerSettingsPane");
  expect(source).toContain("goal.thread-goal-updated");
  expect(source).toContain("get_goal");
  expect(source).toContain("create_goal");
  expect(source).toContain("update_goal");
  expect(source).not.toContain("`${API}/config`");
  expect(source).not.toContain("`${API}/session`");
});

test("partial config saves preserve status and do not duplicate resume continuations", async () => {
  installRuntimeKvStore();
  let configSet: ((payload: unknown, req: Request) => Promise<any>) | undefined;
  (globalThis as any).__piclaw_registerAddonConfigApi = (_addonId: string, _action: string, handlers: any) => {
    configSet = handlers.set;
    return "created";
  };
  await import(`./index.ts?config-lifecycle=${Date.now()}`);
  expect(configSet).toBeDefined();

  const { commands, sentUserMessages, ctx } = createHarness();
  await withChatContext("web:goal", "web", async () => {
    await commands.get("goal").handler("Finish docs", ctx);
    await commands.get("goal").handler("pause", ctx);
  });
  const paused = loadThreadGoal("web:goal")!;
  expect(paused).toMatchObject({ status: "paused", lifecycle_generation: 2 });

  await configSet!({ token_budget: 500 }, new Request("http://localhost/agent/addons/api/goal/goal?chat_jid=web%3Agoal"));
  expect(loadThreadGoal("web:goal")).toMatchObject({ status: "paused", lifecycle_generation: 2, token_budget: 500 });
  expect(sentUserMessages).toHaveLength(1);
});

test("goal continuation requests include internal auth only for loopback agent URLs", () => {
  process.env.PICLAW_INTERNAL_SECRET = "test-secret";
  expect(buildLocalAgentMessageHeaders("http://127.0.0.1:3000")).toMatchObject({
    "Content-Type": "application/json",
    "X-Piclaw-Internal-Secret": "test-secret",
    Authorization: "Bearer test-secret",
  });
  expect(buildLocalAgentMessageHeaders("http://localhost:3000")["X-Piclaw-Internal-Secret"]).toBe("test-secret");
  expect(buildLocalAgentMessageHeaders("https://example.invalid")).toEqual({ "Content-Type": "application/json" });
});

test("goal continuations fall back deterministically when an older core has no enqueue API", async () => {
  const originalFetch = globalThis.fetch;
  const requests: Array<{ url: string; init?: RequestInit }> = [];
  globalThis.fetch = (async (input: string | URL | Request, init?: RequestInit) => {
    requests.push({ url: String(input), init });
    return new Response(null, { status: 202 });
  }) as typeof fetch;
  (globalThis as { __piclaw_runtime?: unknown }).__piclaw_runtime = {};
  try {
    const { commands, sentUserMessages, ctx } = createHarness({ mockPromptSender: false });
    await withChatContext("web:goal", "web", async () => {
      await commands.get("goal").handler("Ship through the compatibility path", ctx);
    });
    expect(sentUserMessages).toHaveLength(0);
    expect(requests).toHaveLength(1);
    expect(requests[0]?.url).toContain("/agent/default/message?chat_jid=web%3Agoal");
    expect(requests[0]?.init?.method).toBe("POST");
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test("goal continuations fail closed when the Piclaw runtime enqueue API throws", async () => {
  const originalFetch = globalThis.fetch;
  const requests: string[] = [];
  globalThis.fetch = (async (input: string | URL | Request) => {
    requests.push(String(input));
    return new Response(null, { status: 202 });
  }) as typeof fetch;
  (globalThis as { __piclaw_runtime?: unknown }).__piclaw_runtime = {
    enqueueAgentMessage: async () => { throw new Error("runtime queue unavailable"); },
  };
  try {
    const { commands, notifications, ctx } = createHarness({ mockPromptSender: false });
    await withChatContext("web:goal", "web", async () => {
      await commands.get("goal").handler("Ship through the throwing runtime path", ctx);
    });
    expect(requests).toHaveLength(0);
    expect(notifications.at(-1)?.level).toBe("warning");
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test("goal continuations prefer the first-class Piclaw runtime enqueue API over localhost HTTP", async () => {
  const enqueued: unknown[] = [];
  (globalThis as { __piclaw_runtime?: unknown }).__piclaw_runtime = {
    enqueueAgentMessage: async (request: unknown) => {
      enqueued.push(request);
      return { status: "ok", chat_jid: "web:goal", queued: "followup", thread_id: null };
    },
  };

  const { commands, sentUserMessages, ctx } = createHarness({ mockPromptSender: false });
  await withChatContext("web:goal", "web", async () => {
    await commands.get("goal").handler("Ship the runtime API", ctx);
  });
  await flushGoalPromptDispatchesForTests();

  expect(sentUserMessages).toHaveLength(0);
  expect(enqueued).toEqual([
    {
      chatJid: "web:goal",
      content: "🎯 Continue goal: Ship the runtime API",
      mode: "auto",
      source: "goal.continuation",
    },
  ]);
});

test("resolveActiveChatJid falls back to the session directory for web branches", () => {
  const ctx = {
    sessionManager: {
      getSessionDir: () => "/workspace/.pi/agent/sessions/web_branch-123",
    },
  } as any;
  expect(resolveActiveChatJid(ctx)).toBe("web:branch-123");
});

test("createThreadGoal stores Codex-shaped state and rejects duplicates", () => {
  const goal = createThreadGoal("web:goal", "Ship <unsafe> & verify", 1234);
  expect(goal.objective).toBe("Ship <unsafe> & verify");
  expect(goal.status).toBe("active");
  expect(goal.token_budget).toBe(1234);
  expect(goal.tokens_used).toBe(0);
  expect(goal.time_used_seconds).toBe(0);
  expect(loadThreadGoal("web:goal")?.goal_id).toBe(goal.goal_id);
  expect(() => createThreadGoal("web:goal", "second")).toThrow(/already has a goal/);
});

test("goalResponse matches Codex-style tool response fields", () => {
  const goal = createThreadGoal("web:goal", "Ship docs", 100);
  const response = goalResponse(goal);
  expect(response.goal).toMatchObject({
    threadId: "web:goal",
    goalId: goal.goal_id,
    objective: "Ship docs",
    status: "active",
    tokenBudget: 100,
    tokensUsed: 0,
    timeUsedSeconds: 0,
  });
  expect(response.remainingTokens).toBe(100);
  expect(response.completionBudgetReport).toBeNull();
});

test("goal prompts port Codex fidelity, escaping, plan action=update, and blocked audit language", () => {
  const goal = createThreadGoal("web:goal", "Fix <x> & ship", 1000);
  const continuation = buildGoalContinuationPrompt(goal);
  expect(continuation).toContain("Fix &lt;x&gt; &amp; ship");
  expect(continuation).toContain("If the plan tool is available");
  expect(continuation).toContain("plan action=update");
  expect(continuation).toContain("Completion audit:");
  expect(continuation).toContain("Blocked audit:");
  expect(continuation).toContain("at least three consecutive goal turns");
  expect(continuation).toContain("goal_complete");
  expect(continuation).toContain("update_goal with status \"complete\"");
  const systemPrompt = buildGoalSystemPrompt(goal);
  expect(systemPrompt).toContain("## Active Goal");
  expect(systemPrompt).toContain("Codex-compatible fallback");
  expect(systemPrompt).toContain("update_goal({ status: \"complete\"");
  expect(systemPrompt).toContain("do not end the turn with only the tool call");
  expect(systemPrompt).not.toContain("Tokens used:");
  expect(systemPrompt).not.toContain("Tokens remaining:");
  expect(buildGoalSystemPrompt({ ...goal, tokens_used: 750, time_used_seconds: 60 })).toBe(systemPrompt);
  const finalization = buildGoalFinalizationPrompt(goal, 1, [{ step: "Verify release", status: "completed" }]);
  expect(finalization).toContain("no pending or in-progress items");
  expect(finalization).toContain("call goal_complete");
  expect(finalization).toContain("call update_goal with status \"complete\"");
  expect(finalization).toContain("call goal_stop");
  const budget = buildGoalBudgetLimitPrompt(goal);
  expect(budget).toContain("has reached its token budget");
  expect(budget).toContain("Do not call goal_complete or update_goal(status=\"complete\") unless the goal is actually complete");
});

describe("Codex-style goal tools", () => {
  test("registers get_goal, create_goal, goal_complete, goal_stop, and update_goal", () => {
    const { tools } = createHarness();
    expect([...tools.keys()].sort()).toEqual(["create_goal", "get_goal", "goal_complete", "goal_stop", "update_goal"]);
  });

  test("create_goal and get_goal share persisted thread goal state", async () => {
    const { tools, ctx } = createHarness();
    const createGoal = tools.get("create_goal");
    const getGoal = tools.get("get_goal");

    const created = await createGoal.execute("call-1", { objective: "Ship goal port", token_budget: 500 }, undefined, undefined, ctx);
    expect(created.details.goal.status).toBe("active");
    expect(created.details.remainingTokens).toBe(500);

    const read = await getGoal.execute("call-2", {}, undefined, undefined, ctx);
    expect(read.details.goal.objective).toBe("Ship goal port");
    expect(read.details.terminalGuidance.join("\n")).toContain("update_goal({ status: \"complete\"");
    expect(read.details.terminalGuidance.join("\n")).toContain("goal_stop");
  });

  test("goal_complete records evidence without early-terminating the user-visible turn", async () => {
    const { tools, ctx } = createHarness();
    await tools.get("create_goal").execute("call-1", { objective: "Close checklist", token_budget: 500 }, undefined, undefined, ctx);
    const result = await tools.get("goal_complete").execute("call-2", { summary: "Checklist closed.", evidence: ["bun test passed", "commit abc123 pushed"] }, undefined, undefined, ctx);
    expect(result.details.goal.status).toBe("complete");
    expect(result.details.goal.completionSummary).toBe("Checklist closed.");
    expect(result.details.goal.completionEvidence).toEqual(["bun test passed", "commit abc123 pushed"]);
    expect(result.details.completionBudgetReport).toContain("Goal achieved");
    expect(result.content[0].text).toContain("Now provide a concise final answer to the user");
    expect(result.terminate).toBeUndefined();
    expect(loadThreadGoal("web:default")?.status).toBe("complete");
  });

  test("goal_stop records the stop reason without early-terminating the user-visible turn", async () => {
    const { tools, ctx } = createHarness();
    await tools.get("create_goal").execute("call-1", { objective: "Wait for external service" }, undefined, undefined, ctx);
    const result = await tools.get("goal_stop").execute("call-2", { reason: "user_needed", summary: "Need credentials.", evidence: ["401 from service"] }, undefined, undefined, ctx);
    expect(result.details.goal.status).toBe("stopped");
    expect(result.details.goal.stopReason).toBe("user_needed");
    expect(result.details.goal.stopEvidence).toEqual(["401 from service"]);
    expect(result.content[0].text).toContain("Now provide a concise final answer to the user");
    expect(result.terminate).toBeUndefined();
  });

  test("update_goal can complete with final usage report without early termination", async () => {
    const { tools, ctx } = createHarness();
    await tools.get("create_goal").execute("call-1", { objective: "Close checklist", token_budget: 500 }, undefined, undefined, ctx);
    const result = await tools.get("update_goal").execute("call-2", { status: "complete", summary: "Verified.", evidence: ["release check passed"] }, undefined, undefined, ctx);
    expect(result.details.goal.status).toBe("complete");
    expect(result.details.goal.completionSummary).toBe("Verified.");
    expect(result.details.goal.completionEvidence).toEqual(["release check passed"]);
    expect(result.details.completionBudgetReport).toContain("Goal achieved");
    expect(result.content[0].text).toContain("Now provide a concise final answer to the user");
    expect(result.terminate).toBeUndefined();
    expect(loadThreadGoal("web:default")?.status).toBe("complete");
  });

  test("update_goal complete requires evidence", async () => {
    const { tools, ctx } = createHarness();
    await tools.get("create_goal").execute("call-1", { objective: "Close checklist" }, undefined, undefined, ctx);
    await expect(tools.get("update_goal").execute("call-2", { status: "complete", summary: "Verified." }, undefined, undefined, ctx)).rejects.toThrow("requires at least one concrete evidence item");
    expect(loadThreadGoal("web:default")?.status).toBe("active");
  });

  test("update_goal can mark blocked", async () => {
    const { tools, ctx } = createHarness();
    await tools.get("create_goal").execute("call-1", { objective: "Wait for external service" }, undefined, undefined, ctx);
    const result = await tools.get("update_goal").execute("call-2", { status: "blocked", summary: "Service unavailable three turns." }, undefined, undefined, ctx);
    expect(result.details.goal.status).toBe("blocked");
    expect(result.content[0].text).toContain("Now provide a concise final answer to the user");
    expect(result.terminate).toBeUndefined();
    expect(loadThreadGoal("web:default")?.last_blocker).toContain("Service unavailable");
  });
});

describe("/goal command and runtime loop", () => {
  test("before_agent_start injects compact active-goal terminal guidance", async () => {
    const { handlers, ctx } = createHarness();
    const beforeAgentStart = handlers.find((entry) => entry.event === "before_agent_start")?.handler;
    createThreadGoal("web:default", "Ship docs", 100);
    const result = await beforeAgentStart({ systemPrompt: "base" }, ctx);
    expect(result.systemPrompt).toContain("## Active Goal");
    expect(result.systemPrompt).toContain("Ship docs");
    expect(result.systemPrompt).toContain("goal_complete({ summary, evidence })");
    expect(result.systemPrompt).toContain("update_goal({ status: \"complete\"");
  });

  test("/goal starts a thread goal and asynchronously queues the Codex continuation prompt", async () => {
    const { commands, sentUserMessages, sentMessages, notifications, ctx } = createHarness();
    await withChatContext("web:goal", "web", async () => {
      await commands.get("goal").handler("Ship the release", ctx);
    });
    const goal = loadThreadGoal("web:goal");
    expect(goal?.objective).toBe("Ship the release");
    expect(goal?.status).toBe("active");
    expect(sentUserMessages).toHaveLength(1);
    await flushGoalPromptDispatchesForTests();
    expect(String(sentUserMessages[0]?.content)).toBe("🎯 Continue goal: Ship the release");
    expect(sentUserMessages[0]?.options).toEqual({ via: "local-agent-endpoint" });
    expect(notifications.at(-1)?.message).toContain("server-side continuation queued");
  });

  test("/goal replaces an existing goal without hidden confirmation", async () => {
    const { commands, sentUserMessages, confirmations, ctx } = createHarness({ confirm: false });
    await withChatContext("web:goal", "web", async () => {
      await commands.get("goal").handler("First goal", ctx);
      await commands.get("goal").handler("Second goal", ctx);
    });
    expect(confirmations).toHaveLength(0);
    expect(loadThreadGoal("web:goal")?.objective).toBe("Second goal");
    expect(loadThreadGoal("web:goal")?.status).toBe("active");
    expect(sentUserMessages).toHaveLength(2);
    expect(String(sentUserMessages[1]?.content)).toBe("🎯 Goal updated: Second goal");
  });

  test("/goal and /goal help post a visible command table with current status", async () => {
    const { commands, sentMessages, ctx } = createHarness();
    await withChatContext("web:goal", "web", async () => {
      await commands.get("goal").handler("", ctx);
      await commands.get("goal").handler("help", ctx);
    });
    const helpMessages = sentMessages.filter((entry) => (entry.message as any)?.customType === "goal_help");
    expect(helpMessages).toHaveLength(2);
    const body = customMessageText(helpMessages[0]?.message);
    expect((helpMessages[0]?.message as any)?.display).toBe(true);
    expect(body).toContain("/goal commands");
    expect(body).toContain("| Command | Action |");
    expect(body).toContain("`/goal pause`");
    expect(body).toContain("`/goal reset` (`clear`)");
    expect(body).toContain("No goal is currently set for web:goal.");
  });

  test("/goal pause and resume advance lifecycle identity, invalidate checkpoints, and queue only once", async () => {
    installRuntimeKvStore();
    const { commands, sentUserMessages, ctx } = createHarness();
    (globalThis as any).__piclaw_planSidebarApi = {
      getPlan: () => ({ plan: [{ step: "Finish docs", status: "in_progress" }] }),
    };
    await withChatContext("web:goal", "web", async () => {
      await commands.get("goal").handler("Finish docs", ctx);
      const started = loadThreadGoal("web:goal")!;
      expect(started.lifecycle_generation).toBe(1);
      const lease = goalDeadlineCheckpointProvider.tryLatch({
        chatJid: "web:goal",
        operationId: "op-pause",
        sourceSeq: 1,
        operationGeneration: 1,
        oldTurnId: "turn-pause",
        checkpointId: "checkpoint-pause",
        deadlineAt: new Date(Date.now() + 1_000).toISOString(),
      })!;
      goalDeadlineCheckpointProvider.markScheduled(lease, { generation: 2 });

      await commands.get("goal").handler("pause", ctx);
      expect(loadThreadGoal("web:goal")).toMatchObject({ status: "paused", lifecycle_generation: 2, deadline_checkpoint: null });
      await commands.get("goal").handler("resume", ctx);
      expect(loadThreadGoal("web:goal")).toMatchObject({ status: "active", lifecycle_generation: 3, deadline_checkpoint: null });
      expect(goalDeadlineCheckpointProvider.resolveContinuation({
        chatJid: "web:goal",
        goalId: started.goal_id,
        checkpointId: "checkpoint-pause",
        generation: 2,
      })).toEqual({ status: "suppress" });
      await commands.get("goal").handler("resume", ctx);
    });
    expect(sentUserMessages).toHaveLength(2);
  });

  test("complete and stop transitions invalidate checkpoints before reactivation", async () => {
    for (const terminalTool of ["goal_complete", "goal_stop"] as const) {
      resetGoalAddonForTests();
      installRuntimeKvStore();
      const { commands, tools, ctx } = createHarness();
      (globalThis as any).__piclaw_planSidebarApi = {
        getPlan: () => ({ plan: [{ step: "Finish docs", status: "in_progress" }] }),
      };
      await withChatContext("web:goal", "web", async () => {
        await commands.get("goal").handler("Finish docs", ctx);
        const lease = goalDeadlineCheckpointProvider.tryLatch({
          chatJid: "web:goal",
          operationId: `op-${terminalTool}`,
          sourceSeq: 1,
          operationGeneration: 1,
          oldTurnId: `turn-${terminalTool}`,
          checkpointId: `checkpoint-${terminalTool}`,
          deadlineAt: new Date(Date.now() + 1_000).toISOString(),
        })!;
        goalDeadlineCheckpointProvider.markScheduled(lease, { generation: 2 });
        if (terminalTool === "goal_complete") {
          await tools.get(terminalTool).execute("call-terminal", { summary: "Done", evidence: ["verified"] }, undefined, undefined, ctx);
        } else {
          await tools.get(terminalTool).execute("call-terminal", { reason: "other", summary: "Stopped" }, undefined, undefined, ctx);
        }
        expect(loadThreadGoal("web:goal")).toMatchObject({ lifecycle_generation: 2, deadline_checkpoint: null });
        await commands.get("goal").handler("resume", ctx);
        expect(loadThreadGoal("web:goal")).toMatchObject({ status: "active", lifecycle_generation: 3, deadline_checkpoint: null });
        expect(goalDeadlineCheckpointProvider.resolveContinuation({
          chatJid: "web:goal",
          goalId: lease.goalId,
          checkpointId: lease.checkpointId,
          generation: 2,
        })).toEqual({ status: "suppress" });
      });
    }
  });

  test("/goal clear is an exact synonym for /goal reset", async () => {
    for (const alias of ["reset", "clear"]) {
      resetGoalAddonForTests();
      const { commands, notifications, ctx } = createHarness();
      await withChatContext("web:goal", "web", async () => {
        await commands.get("goal").handler("Finish docs", ctx);
        expect(loadThreadGoal("web:goal")?.objective).toBe("Finish docs");
        await commands.get("goal").handler(alias, ctx);
        expect(loadThreadGoal("web:goal")).toBeNull();
      });
      expect(notifications.at(-1)?.message).toBe("Goal cleared");
    }
  });

  test("queued goal prompts are swallowed after /goal stop regardless of queue", async () => {
    const { commands, handlers, sentUserMessages, sentMessages, ctx } = createHarness();
    const input = handlers.find((entry) => entry.event === "input")?.handler;
    await withChatContext("web:goal", "web", async () => {
      await commands.get("goal").handler("Finish docs", ctx);
      expect(String(sentUserMessages[0]?.content)).toBe("🎯 Continue goal: Finish docs");
      expect(String(sentUserMessages[0]?.content)).not.toContain("piclaw-goal");
      await commands.get("goal").handler("stop", ctx);
      expect(loadThreadGoal("web:goal")?.status).toBe("paused");
      const result = await input({ type: "input", text: sentUserMessages[0]?.content, source: "extension" }, ctx);
      expect(result).toEqual({ action: "handled" });
    });
    expect(customMessageText(sentMessages.at(-1)?.message)).toContain("skipped queued continuation continuation");
  });

  test("active goal prompts continue without timeline metadata", async () => {
    const { commands, handlers, sentUserMessages, ctx } = createHarness();
    const input = handlers.find((entry) => entry.event === "input")?.handler;
    await withChatContext("web:goal", "web", async () => {
      await commands.get("goal").handler("Finish docs", ctx);
      const result = await input({ type: "input", text: sentUserMessages[0]?.content, source: "extension" }, ctx);
      expect(result.action).toBe("transform");
      expect(result.text).toContain("Continue working toward the active thread goal");
      expect(String(sentUserMessages[0]?.content)).toBe("🎯 Continue goal: Finish docs");
      expect(String(sentUserMessages[0]?.content)).not.toContain("piclaw-goal");
    });
  });

  test("message_end accounts usage and agent_end emits continuation while active", async () => {
    const { commands, handlers, sentUserMessages, ctx } = createHarness();
    const messageEnd = handlers.find((entry) => entry.event === "message_end")?.handler;
    const agentEnd = handlers.find((entry) => entry.event === "agent_end")?.handler;
    await withChatContext("web:goal", "web", async () => {
      await commands.get("goal").handler("Finish docs", ctx);
      await messageEnd({ message: { role: "assistant", usage: { totalTokens: 123 } } }, ctx);
      await agentEnd({}, ctx);
    });
    expect(loadThreadGoal("web:goal")?.tokens_used).toBe(123);
    expect(sentUserMessages).toHaveLength(2);
    expect(String(sentUserMessages[1]?.content)).toBe("🎯 Continue goal: Finish docs");
  });

  test("released checkpoint suppresses only the exact late agent_end turn", async () => {
    const values = new Map<string, unknown>();
    const storageKey = (extensionId: string, name: string, scope = "chat", scopeKey = "") => `${extensionId}:${scope}:${scopeKey}:${name}`;
    (globalThis as any).__piclawRuntimeInterop = { getExtensionKvStore: () => ({
      get: (extensionId: string, name: string, scope?: string, scopeKey?: string) => values.get(storageKey(extensionId, name, scope, scopeKey)) ?? null,
      set: (extensionId: string, name: string, value: unknown, scope?: string, scopeKey?: string) => { values.set(storageKey(extensionId, name, scope, scopeKey), structuredClone(value)); },
      delete: (extensionId: string, name: string, scope?: string, scopeKey?: string) => values.delete(storageKey(extensionId, name, scope, scopeKey)),
      list: () => [],
      clear: () => { const count = values.size; values.clear(); return count; },
    }) };
    const { commands, handlers, sentUserMessages, ctx } = createHarness();
    const messageEnd = handlers.find((entry) => entry.event === "message_end")?.handler;
    const agentEnd = handlers.find((entry) => entry.event === "agent_end")?.handler;
    (globalThis as any).__piclaw_planSidebarApi = {
      getPlan: () => ({ plan: [{ step: "Finish docs", status: "in_progress" }] }),
    };
    await withChatContext("web:goal", "web", async () => {
      await commands.get("goal").handler("Finish docs", ctx);
      await messageEnd({ message: { role: "assistant", stopReason: "aborted", usage: { totalTokens: 5 } } }, ctx);
      const lease = goalDeadlineCheckpointProvider.tryLatch({
        chatJid: "web:goal",
        operationId: "op-1",
        sourceSeq: 1,
        operationGeneration: 1,
        oldTurnId: "turn-old",
        checkpointId: "checkpoint-1",
        deadlineAt: new Date(Date.now() + 1_000).toISOString(),
      });
      expect(lease).not.toBeNull();
      goalDeadlineCheckpointProvider.markScheduled(lease!, { generation: 2 });
      await messageEnd({ message: { role: "assistant", stopReason: "aborted", usage: { totalTokens: 5 } } }, ctx);
      expect(loadThreadGoal("web:goal")).toMatchObject({
        lifecycle_generation: 1,
        deadline_checkpoint: {
          checkpoint_id: "checkpoint-1",
          continuation_generation: 2,
          lifecycle_generation: 1,
          status: "scheduled",
        },
      });
      expect(goalDeadlineCheckpointProvider.resolveContinuation({
        chatJid: "web:goal",
        goalId: lease!.goalId,
        checkpointId: "checkpoint-1",
        generation: 2,
      }).status).toBe("continue");
      expect(goalDeadlineCheckpointProvider.resolveContinuation({
        chatJid: "web:goal",
        goalId: lease!.goalId,
        checkpointId: "checkpoint-1",
        generation: 2,
      }).status).toBe("continue");
      await messageEnd({ message: { role: "assistant", stopReason: "aborted", usage: { totalTokens: 5 } } }, ctx);
      expect(loadThreadGoal("web:goal")).toMatchObject({
        lifecycle_generation: 1,
        tokens_used: 15,
        deadline_checkpoint: { checkpoint_id: "checkpoint-1", status: "claimed" },
      });
      expect(goalDeadlineCheckpointProvider.resolveContinuation({
        chatJid: "web:goal",
        goalId: lease!.goalId,
        checkpointId: "checkpoint-1",
        generation: 2,
      }).status).toBe("continue");
      goalDeadlineCheckpointProvider.release(lease!);
      await agentEnd({}, ctx);
    }, { turnId: "turn-old" });
    expect(sentUserMessages).toHaveLength(1);
    expect(loadThreadGoal("web:goal")?.deadline_checkpoint).toMatchObject({ checkpoint_id: "checkpoint-1", status: "claimed" });

    await withChatContext("web:goal", "web", async () => {
      await agentEnd({}, ctx);
    }, { turnId: "turn-new" });
    expect(sentUserMessages).toHaveLength(2);
    expect(String(sentUserMessages[1]?.content)).toBe("🎯 Continue goal: Finish docs");
    expect(loadThreadGoal("web:goal")?.deadline_checkpoint).toBeNull();
  });

  test("a hard-error successor retains claimed checkpoint evidence for exact retry", async () => {
    installRuntimeKvStore();
    const { commands, handlers, sentUserMessages, ctx } = createHarness();
    const messageEnd = handlers.find((entry) => entry.event === "message_end")?.handler;
    const agentEnd = handlers.find((entry) => entry.event === "agent_end")?.handler;
    (globalThis as any).__piclaw_planSidebarApi = {
      getPlan: () => ({ plan: [{ step: "Finish docs", status: "in_progress" }] }),
    };
    let goalId = "";
    await withChatContext("web:goal", "web", async () => {
      await commands.get("goal").handler("Finish docs", ctx);
      const lease = goalDeadlineCheckpointProvider.tryLatch({
        chatJid: "web:goal",
        operationId: "op-error",
        sourceSeq: 2,
        operationGeneration: 1,
        oldTurnId: "turn-old",
        checkpointId: "checkpoint-error",
        deadlineAt: new Date(Date.now() + 60_000).toISOString(),
      });
      expect(lease).not.toBeNull();
      goalId = lease!.goalId;
      goalDeadlineCheckpointProvider.markScheduled(lease!, { generation: 4 });
      expect(goalDeadlineCheckpointProvider.resolveContinuation({
        chatJid: "web:goal",
        goalId,
        checkpointId: "checkpoint-error",
        generation: 4,
      }).status).toBe("continue");
      goalDeadlineCheckpointProvider.release(lease!);
      await messageEnd({ message: { role: "assistant", stopReason: "error", errorMessage: "retry", usage: { totalTokens: 5 } } }, ctx);
    }, { turnId: "turn-old" });

    await withChatContext("web:goal", "web", async () => {
      await agentEnd({}, ctx);
    }, { turnId: "turn-new" });
    expect(sentUserMessages).toHaveLength(1);
    expect(loadThreadGoal("web:goal")?.deadline_checkpoint).toMatchObject({ checkpoint_id: "checkpoint-error", status: "claimed" });
    expect(goalDeadlineCheckpointProvider.resolveContinuation({
      chatJid: "web:goal",
      goalId,
      checkpointId: "checkpoint-error",
      generation: 4,
    }).status).toBe("continue");
  });

  test("ordinary accounting invalidates malformed persisted lifecycle and checkpoint identities", async () => {
    installRuntimeKvStore();
    const { commands, handlers, ctx } = createHarness();
    const messageEnd = handlers.find((entry) => entry.event === "message_end")?.handler;
    await withChatContext("web:goal", "web", async () => {
      await commands.get("goal").handler("Finish docs", ctx);
    });
    const runtimeStore = (globalThis as any).__piclawRuntimeInterop.getExtensionKvStore();
    const checkpoint = {
      checkpoint_id: "checkpoint-malformed",
      operation_id: "op-malformed",
      source_seq: 2,
      operation_generation: 1,
      continuation_generation: 4,
      lifecycle_generation: 1,
      old_turn_id: "turn-malformed",
      expires_at: new Date(Date.now() + 60_000).toISOString(),
      status: "claimed",
    };
    const readRawGoal = () => runtimeStore.get("goal", "thread-goal", "chat", "web:goal");
    const writeRawGoal = (goal: unknown) => runtimeStore.set("goal", "thread-goal", goal, "chat", "web:goal");

    const initial = readRawGoal();
    writeRawGoal({ ...initial, lifecycle_generation: Number.MAX_SAFE_INTEGER + 1, deadline_checkpoint: checkpoint });
    await withChatContext("web:goal", "web", async () => {
      await messageEnd({ message: { role: "assistant", stopReason: "stop", usage: { totalTokens: 1 } } }, ctx);
    });
    expect(readRawGoal()).toMatchObject({ lifecycle_generation: 1, deadline_checkpoint: null });

    for (const checkpointId of [" checkpoint-malformed", "x".repeat(513)]) {
      const repaired = readRawGoal();
      writeRawGoal({ ...repaired, deadline_checkpoint: { ...checkpoint, checkpoint_id: checkpointId } });
      await withChatContext("web:goal", "web", async () => {
        await messageEnd({ message: { role: "assistant", stopReason: "stop", usage: { totalTokens: 1 } } }, ctx);
      });
      expect(readRawGoal()).toMatchObject({ lifecycle_generation: 1, deadline_checkpoint: null });
    }

    const beforeMalformedGoalId = readRawGoal();
    writeRawGoal({
      ...beforeMalformedGoalId,
      goal_id: ` ${(beforeMalformedGoalId as any).goal_id}`,
      deadline_checkpoint: checkpoint,
    });
    await withChatContext("web:goal", "web", async () => {
      await messageEnd({ message: { role: "assistant", stopReason: "stop", usage: { totalTokens: 1 } } }, ctx);
    });
    expect(readRawGoal()).toMatchObject({ lifecycle_generation: 1, deadline_checkpoint: null });
    expect((readRawGoal() as any).goal_id).not.toBe(` ${(beforeMalformedGoalId as any).goal_id}`);

    const beforeMalformedStatus = readRawGoal();
    writeRawGoal({ ...beforeMalformedStatus, status: "unknown", deadline_checkpoint: checkpoint });
    await withChatContext("web:goal", "web", async () => {
      await messageEnd({ message: { role: "assistant", stopReason: "stop", usage: { totalTokens: 1 } } }, ctx);
    });
    expect(readRawGoal()).toMatchObject({ status: "active", lifecycle_generation: 1, deadline_checkpoint: null });
    expect(goalDeadlineCheckpointProvider.resolveContinuation({
      chatJid: "web:goal",
      goalId: String((readRawGoal() as any).goal_id),
      checkpointId: "checkpoint-malformed",
      generation: 4,
    })).toEqual({ status: "suppress" });
  });

  test("agent_end treats an all-completed plan as a finalization candidate instead of normal continuation", async () => {
    const { commands, handlers, sentUserMessages, ctx } = createHarness();
    const messageEnd = handlers.find((entry) => entry.event === "message_end")?.handler;
    const agentEnd = handlers.find((entry) => entry.event === "agent_end")?.handler;
    (globalThis as any).__piclaw_planSidebarApi = {
      getPlan: () => ({
        markdown: "- [x] Inspect\n- [x] Test",
        explanation: null,
        plan: [
          { step: "Inspect", status: "completed" },
          { step: "Test", status: "completed" },
        ],
      }),
    };
    await withChatContext("web:goal", "web", async () => {
      await commands.get("goal").handler("Finish docs", ctx);
      await messageEnd({ message: { role: "assistant", stopReason: "stop", usage: { totalTokens: 12 } } }, ctx);
      await agentEnd({}, ctx);
    });
    expect(sentUserMessages).toHaveLength(2);
    expect(String(sentUserMessages[1]?.content)).toBe("🎯 Finalize goal: Finish docs");
    expect(loadThreadGoal("web:goal")?.completion_probe_count).toBe(1);
  });

  test("queued finalization prompts expand to completion-or-stop instructions", async () => {
    const { commands, handlers, sentUserMessages, ctx } = createHarness();
    const input = handlers.find((entry) => entry.event === "input")?.handler;
    (globalThis as any).__piclaw_planSidebarApi = {
      getPlan: () => ({ markdown: "- [x] done", explanation: null, plan: [{ step: "done", status: "completed" }] }),
    };
    await withChatContext("web:goal", "web", async () => {
      await commands.get("goal").handler("Finish docs", ctx);
      const goal = loadThreadGoal("web:goal")!;
      const candidate = { ...goal, completion_probe_count: 1 };
      const result = await input({ type: "input", text: `🎯 Finalize goal: ${goal.objective}`, source: "extension" }, ctx);
      expect(result.action).toBe("transform");
      expect(result.text).toContain("The current Plan Sidebar checklist has no pending or in-progress items");
      expect(result.text).toContain("call goal_complete");
      expect(result.text).toContain("call goal_stop");
      expect(candidate.completion_probe_count).toBe(1);
    });
    expect(sentUserMessages[0]?.content).toBe("🎯 Continue goal: Finish docs");
  });

  test("repeated unresolved all-completed plan auto-stops the goal loop", async () => {
    const { commands, handlers, sentUserMessages, ctx } = createHarness();
    const messageEnd = handlers.find((entry) => entry.event === "message_end")?.handler;
    const agentEnd = handlers.find((entry) => entry.event === "agent_end")?.handler;
    (globalThis as any).__piclaw_planSidebarApi = {
      getPlan: () => ({ markdown: "- [x] Inspect", explanation: null, plan: [{ step: "Inspect", status: "completed" }] }),
    };
    await withChatContext("web:goal", "web", async () => {
      await commands.get("goal").handler("Finish docs", ctx);
      for (let index = 0; index < 3; index += 1) {
        await messageEnd({ message: { role: "assistant", stopReason: "stop", usage: { totalTokens: 1 } } }, ctx);
        await agentEnd({}, ctx);
      }
    });
    const goal = loadThreadGoal("web:goal");
    expect(goal?.status).toBe("stopped");
    expect(goal?.stop_reason).toBe("plan_complete_unverified");
    expect(sentUserMessages.map((msg) => String(msg.content))).toEqual([
      "🎯 Continue goal: Finish docs",
      "🎯 Finalize goal: Finish docs",
      "🎯 Finalize goal: Finish docs",
    ]);
  });

  test("repeated unchanged incomplete plans auto-stop as no progress", async () => {
    const { commands, handlers, sentUserMessages, ctx } = createHarness();
    const messageEnd = handlers.find((entry) => entry.event === "message_end")?.handler;
    const agentEnd = handlers.find((entry) => entry.event === "agent_end")?.handler;
    (globalThis as any).__piclaw_planSidebarApi = {
      getPlan: () => ({ markdown: "- [-] Implement\n- [ ] Test", explanation: null, plan: [
        { step: "Implement", status: "in_progress" },
        { step: "Test", status: "pending" },
      ] }),
    };
    await withChatContext("web:goal", "web", async () => {
      await commands.get("goal").handler("Finish docs", ctx);
      for (let index = 0; index < 3; index += 1) {
        await messageEnd({ message: { role: "assistant", stopReason: "stop", usage: { totalTokens: 1 } } }, ctx);
        await agentEnd({}, ctx);
      }
    });
    const goal = loadThreadGoal("web:goal");
    expect(goal?.status).toBe("stopped");
    expect(goal?.stop_reason).toBe("no_progress");
    expect(sentUserMessages.map((msg) => String(msg.content))).toEqual([
      "🎯 Continue goal: Finish docs",
      "🎯 Continue goal: Finish docs",
      "🎯 Continue goal: Finish docs",
    ]);
  });

  test("agent_end auto-continues even when the last assistant message ended on a tool call", async () => {
    const { commands, handlers, sentUserMessages, ctx } = createHarness();
    const messageEnd = handlers.find((entry) => entry.event === "message_end")?.handler;
    const agentEnd = handlers.find((entry) => entry.event === "agent_end")?.handler;
    await withChatContext("web:goal", "web", async () => {
      await commands.get("goal").handler("Finish docs", ctx);
      await messageEnd({ message: { role: "assistant", stopReason: "toolUse", usage: { totalTokens: 5 } } }, ctx);
      await agentEnd({}, ctx);
    });
    expect(sentUserMessages).toHaveLength(2);
    expect(String(sentUserMessages[1]?.content)).toBe("🎯 Continue goal: Finish docs");
  });

  test("non-Goal assistant outcomes cannot continue a later Goal", async () => {
    const { commands, handlers, sentUserMessages, ctx } = createHarness();
    const messageEnd = handlers.find((entry) => entry.event === "message_end")?.handler;
    const agentEnd = handlers.find((entry) => entry.event === "agent_end")?.handler;
    await withChatContext("web:goal", "web", async () => {
      await messageEnd({ message: { role: "assistant", stopReason: "stop", usage: { totalTokens: 5 } } }, ctx);
      await commands.get("goal").handler("Finish docs", ctx);
      await agentEnd({}, ctx);
    });
    expect(sentUserMessages).toHaveLength(1);
  });

  test("assistant outcomes are one-shot at agent_end", async () => {
    const { commands, handlers, sentUserMessages, ctx } = createHarness();
    const messageEnd = handlers.find((entry) => entry.event === "message_end")?.handler;
    const agentEnd = handlers.find((entry) => entry.event === "agent_end")?.handler;
    await withChatContext("web:goal", "web", async () => {
      await commands.get("goal").handler("Finish docs", ctx);
      await messageEnd({ message: { role: "assistant", stopReason: "stop", usage: { totalTokens: 5 } } }, ctx);
      await agentEnd({}, ctx);
      await agentEnd({}, ctx);
    });
    expect(sentUserMessages).toHaveLength(2);
  });

  test("assistant outcomes expire before a delayed agent_end can continue", async () => {
    const now = Date.now();
    const originalNow = Date.now;
    Date.now = () => now;
    try {
      const { commands, handlers, sentUserMessages, ctx } = createHarness();
      const messageEnd = handlers.find((entry) => entry.event === "message_end")?.handler;
      const agentEnd = handlers.find((entry) => entry.event === "agent_end")?.handler;
      await withChatContext("web:goal", "web", async () => {
        await commands.get("goal").handler("Finish docs", ctx);
        await messageEnd({ message: { role: "assistant", stopReason: "stop", usage: { totalTokens: 5 } } }, ctx);
        Date.now = () => now + 60 * 60_000;
        await agentEnd({}, ctx);
      });
      expect(sentUserMessages).toHaveLength(1);
    } finally {
      Date.now = originalNow;
    }
  });

  test("terminal lifecycle changes evict the prior assistant outcome", async () => {
    const { commands, handlers, sentUserMessages, ctx } = createHarness();
    const messageEnd = handlers.find((entry) => entry.event === "message_end")?.handler;
    const agentEnd = handlers.find((entry) => entry.event === "agent_end")?.handler;
    await withChatContext("web:goal", "web", async () => {
      await commands.get("goal").handler("Finish docs", ctx);
      await messageEnd({ message: { role: "assistant", stopReason: "stop", usage: { totalTokens: 5 } } }, ctx);
      await commands.get("goal").handler("pause", ctx);
      await commands.get("goal").handler("resume", ctx);
      await agentEnd({}, ctx);
    });
    expect(sentUserMessages).toHaveLength(2);
  });

  test("a failing continuation dispatch does not throw out of agent_end", async () => {
    const { commands, handlers, ctx } = createHarness();
    const messageEnd = handlers.find((entry) => entry.event === "message_end")?.handler;
    const agentEnd = handlers.find((entry) => entry.event === "agent_end")?.handler;
    setGoalPromptSenderForTests(async () => { throw new Error("continuation endpoint down"); });
    await withChatContext("web:goal", "web", async () => {
      await commands.get("goal").handler("Finish docs", ctx);
      await messageEnd({ message: { role: "assistant", stopReason: "stop", usage: { totalTokens: 5 } } }, ctx);
      await expect(agentEnd({}, ctx)).resolves.toBeUndefined();
    });
    expect(loadThreadGoal("web:goal")?.status).toBe("active");
  });

  test("real tool activity prevents the no-progress auto-stop when the plan is unchanged", async () => {
    const { commands, handlers, ctx } = createHarness();
    const beforeAgentStart = handlers.find((entry) => entry.event === "before_agent_start")?.handler;
    const toolEnd = handlers.find((entry) => entry.event === "tool_execution_end")?.handler;
    const messageEnd = handlers.find((entry) => entry.event === "message_end")?.handler;
    const agentEnd = handlers.find((entry) => entry.event === "agent_end")?.handler;
    (globalThis as any).__piclaw_planSidebarApi = {
      getPlan: () => ({ markdown: "- [-] Implement\n- [ ] Test", explanation: null, plan: [
        { step: "Implement", status: "in_progress" },
        { step: "Test", status: "pending" },
      ] }),
    };
    await withChatContext("web:goal", "web", async () => {
      await commands.get("goal").handler("Finish docs", ctx);
      for (let index = 0; index < 4; index += 1) {
        await beforeAgentStart({ systemPrompt: "base" }, ctx);
        toolEnd({ toolName: "bash" }, ctx);
        await messageEnd({ message: { role: "assistant", stopReason: "stop", usage: { totalTokens: 1 } } }, ctx);
        await agentEnd({}, ctx);
      }
    });
    const goal = loadThreadGoal("web:goal");
    expect(goal?.status).toBe("active");
    expect(goal?.no_progress_turns).toBe(1);
  });

  test("goal-internal tool calls do not count as progress for the no-progress auto-stop", async () => {
    const { commands, handlers, ctx } = createHarness();
    const beforeAgentStart = handlers.find((entry) => entry.event === "before_agent_start")?.handler;
    const toolEnd = handlers.find((entry) => entry.event === "tool_execution_end")?.handler;
    const messageEnd = handlers.find((entry) => entry.event === "message_end")?.handler;
    const agentEnd = handlers.find((entry) => entry.event === "agent_end")?.handler;
    (globalThis as any).__piclaw_planSidebarApi = {
      getPlan: () => ({ markdown: "- [-] Implement", explanation: null, plan: [{ step: "Implement", status: "in_progress" }] }),
    };
    await withChatContext("web:goal", "web", async () => {
      await commands.get("goal").handler("Finish docs", ctx);
      for (let index = 0; index < 3; index += 1) {
        await beforeAgentStart({ systemPrompt: "base" }, ctx);
        toolEnd({ toolName: "get_goal" }, ctx);
        await messageEnd({ message: { role: "assistant", stopReason: "stop", usage: { totalTokens: 1 } } }, ctx);
        await agentEnd({}, ctx);
      }
    });
    const goal = loadThreadGoal("web:goal");
    expect(goal?.status).toBe("stopped");
    expect(goal?.stop_reason).toBe("no_progress");
  });

  test("agent_end does not auto-continue when pending user input exists", async () => {
    const { commands, handlers, sentUserMessages, ctx } = createHarness({ pending: true });
    const messageEnd = handlers.find((entry) => entry.event === "message_end")?.handler;
    const agentEnd = handlers.find((entry) => entry.event === "agent_end")?.handler;
    await withChatContext("web:goal", "web", async () => {
      await commands.get("goal").handler("Finish docs", ctx);
      await messageEnd({ message: { role: "assistant", stopReason: "stop", usage: { totalTokens: 12 } } }, ctx);
      await agentEnd({}, ctx);
    });
    expect(sentUserMessages).toHaveLength(1);
  });

  test("agent_end does not auto-continue after a failed assistant turn", async () => {
    const { commands, handlers, sentUserMessages, ctx } = createHarness();
    const messageEnd = handlers.find((entry) => entry.event === "message_end")?.handler;
    const agentEnd = handlers.find((entry) => entry.event === "agent_end")?.handler;
    await withChatContext("web:goal", "web", async () => {
      await commands.get("goal").handler("Finish docs", ctx);
      await messageEnd({ message: { role: "assistant", stopReason: "error", errorMessage: "400 No tool call found" } }, ctx);
      await agentEnd({}, ctx);
    });
    expect(sentUserMessages).toHaveLength(1);
  });

  test("agent_end auto-continues after a turn aborted purely for compaction", async () => {
    const { commands, handlers, sentUserMessages, ctx } = createHarness();
    const beforeAgentStart = handlers.find((entry) => entry.event === "before_agent_start")?.handler;
    const sessionCompact = handlers.find((entry) => entry.event === "session_compact")?.handler;
    const messageEnd = handlers.find((entry) => entry.event === "message_end")?.handler;
    const agentEnd = handlers.find((entry) => entry.event === "agent_end")?.handler;
    await withChatContext("web:goal", "web", async () => {
      await commands.get("goal").handler("Finish docs", ctx);
      await beforeAgentStart({ systemPrompt: "base" }, ctx);
      // Mid-turn tool ceiling aborts the turn to force compaction.
      sessionCompact({ compactionEntry: { firstKeptEntryId: "x" } }, ctx);
      await messageEnd({ message: { role: "assistant", stopReason: "aborted", usage: { totalTokens: 7 } } }, ctx);
      await agentEnd({}, ctx);
    });
    expect(sentUserMessages).toHaveLength(2);
    expect(String(sentUserMessages[1]?.content)).toBe("🎯 Continue goal: Finish docs");
  });

  test("agent_end auto-continues after a mid-turn-ceiling abort even when no session_compact fires", async () => {
    // Real mid-turn tool-execution ceiling: the attempt aborts (stopReason
    // "aborted") but the compaction is deferred to the next prompt, so no
    // session_compact event fires this turn. The tool-activity signature must
    // still be recognized as a continuation boundary.
    const { commands, handlers, sentUserMessages, ctx } = createHarness();
    const beforeAgentStart = handlers.find((entry) => entry.event === "before_agent_start")?.handler;
    const toolEnd = handlers.find((entry) => entry.event === "tool_execution_end")?.handler;
    const messageEnd = handlers.find((entry) => entry.event === "message_end")?.handler;
    const agentEnd = handlers.find((entry) => entry.event === "agent_end")?.handler;
    await withChatContext("web:goal", "web", async () => {
      await commands.get("goal").handler("Finish docs", ctx);
      await beforeAgentStart({ systemPrompt: "base" }, ctx);
      toolEnd({ toolName: "bash" }, ctx);
      toolEnd({ toolName: "bash" }, ctx);
      await messageEnd({ message: { role: "assistant", stopReason: "aborted", usage: { totalTokens: 9 } } }, ctx);
      await agentEnd({}, ctx);
    });
    expect(sentUserMessages).toHaveLength(2);
    expect(String(sentUserMessages[1]?.content)).toBe("🎯 Continue goal: Finish docs");
  });

  test("agent_end auto-continues after a bare aborted turn (no tool activity, no session_compact)", async () => {
    // Robust behavior: any non-errored outcome — including a bare `aborted` with no
    // tool activity and no session_compact — is a continuation boundary. The
    // ceiling/context-pressure abort does not reliably surface tool-activity or
    // session_compact signals to the addon, so only a hard error suppresses the loop.
    const { commands, handlers, sentUserMessages, ctx } = createHarness();
    const beforeAgentStart = handlers.find((entry) => entry.event === "before_agent_start")?.handler;
    const messageEnd = handlers.find((entry) => entry.event === "message_end")?.handler;
    const agentEnd = handlers.find((entry) => entry.event === "agent_end")?.handler;
    await withChatContext("web:goal", "web", async () => {
      await commands.get("goal").handler("Finish docs", ctx);
      await beforeAgentStart({ systemPrompt: "base" }, ctx);
      await messageEnd({ message: { role: "assistant", stopReason: "aborted", usage: { totalTokens: 7 } } }, ctx);
      await agentEnd({}, ctx);
    });
    expect(sentUserMessages).toHaveLength(2);
    expect(String(sentUserMessages[1]?.content)).toBe("🎯 Continue goal: Finish docs");
  });

  test("agent_end auto-continues after a compaction abort carrying errorMessage 'Request was aborted'", async () => {
    // Exact production signature on orangepi6plus: the mid-turn ceiling / context-
    // pressure abort ends the turn with stopReason "aborted" AND errorMessage
    // "Request was aborted". This must NOT be treated as a hard error — it is a
    // continuation boundary. (Regression for the 0.1.34/35/36 stall.)
    const { commands, handlers, sentUserMessages, ctx } = createHarness();
    const beforeAgentStart = handlers.find((entry) => entry.event === "before_agent_start")?.handler;
    const messageEnd = handlers.find((entry) => entry.event === "message_end")?.handler;
    const agentEnd = handlers.find((entry) => entry.event === "agent_end")?.handler;
    await withChatContext("web:goal", "web", async () => {
      await commands.get("goal").handler("Finish docs", ctx);
      await beforeAgentStart({ systemPrompt: "base" }, ctx);
      await messageEnd({ message: { role: "assistant", stopReason: "aborted", errorMessage: "Request was aborted", usage: { totalTokens: 7 } } }, ctx);
      await agentEnd({}, ctx);
    });
    expect(sentUserMessages).toHaveLength(2);
    expect(String(sentUserMessages[1]?.content)).toBe("🎯 Continue goal: Finish docs");
  });

  test("agent_end does not auto-continue after a hard-errored turn", async () => {
    const { commands, handlers, sentUserMessages, ctx } = createHarness();
    const beforeAgentStart = handlers.find((entry) => entry.event === "before_agent_start")?.handler;
    const messageEnd = handlers.find((entry) => entry.event === "message_end")?.handler;
    const agentEnd = handlers.find((entry) => entry.event === "agent_end")?.handler;
    await withChatContext("web:goal", "web", async () => {
      await commands.get("goal").handler("Finish docs", ctx);
      await beforeAgentStart({ systemPrompt: "base" }, ctx);
      await messageEnd({ message: { role: "assistant", stopReason: "error", errorMessage: "model exploded", usage: { totalTokens: 7 } } }, ctx);
      await agentEnd({}, ctx);
    });
    expect(sentUserMessages).toHaveLength(1);
  });
  test("agent_end still queues continuation when runtime reports non-idle during compaction", async () => {
    const { commands, handlers, sentUserMessages, ctx } = createHarness({ idle: false });
    const messageEnd = handlers.find((entry) => entry.event === "message_end")?.handler;
    const agentEnd = handlers.find((entry) => entry.event === "agent_end")?.handler;
    await withChatContext("web:goal", "web", async () => {
      await commands.get("goal").handler("Finish docs", ctx);
      await messageEnd({ message: { role: "assistant", stopReason: "stop", usage: { totalTokens: 12 } } }, ctx);
      await agentEnd({}, ctx);
    });
    expect(sentUserMessages).toHaveLength(2);
    expect(String(sentUserMessages[1]?.content)).toBe("🎯 Continue goal: Finish docs");
  });

  test("budget exhaustion marks budget_limited and emits wrap-up prompt once", async () => {
    const { handlers, sentUserMessages, ctx } = createHarness();
    const messageEnd = handlers.find((entry) => entry.event === "message_end")?.handler;
    const agentEnd = handlers.find((entry) => entry.event === "agent_end")?.handler;
    await withChatContext("web:goal", "web", async () => {
      createThreadGoal("web:goal", "Stabilize deployment", 100);
      await messageEnd({ message: { role: "assistant", usage: { totalTokens: 120 } } }, ctx);
      await agentEnd({}, ctx);
      await agentEnd({}, ctx);
    });
    expect(loadThreadGoal("web:goal")?.status).toBe("budget_limited");
    expect(sentUserMessages).toHaveLength(1);
    expect(String(sentUserMessages[0]?.content)).toBe("🎯 Goal budget reached: Stabilize deployment");
  });
});
