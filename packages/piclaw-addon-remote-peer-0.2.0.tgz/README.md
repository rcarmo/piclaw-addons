# Remote Peer

`@rcarmo/piclaw-addon-remote-peer` makes Piclaw's existing `chat` tool work across a small trusted group of instances. Operators pair peers and choose which inboxes, agents, modes and file limits are exposed; agents discover exact usable addresses and send text or files without learning the pairing protocol.

## Agent workflow

```text
chat({ action: "directory" })
chat({ target_address: "lab!inbox", content: "Please review this.", mode: "queue", idempotency_key: "review-2026-08-29" })
chat({ target_address: "lab!@research", content: "CSV attached.", files: ["exports/data.csv"], mode: "queue", idempotency_key: "csv-2026-08-29" })
```

The directory is the allowlist. It returns directly usable local addresses, allowed modes, reachability/roster freshness and receiver-owned file limits. Remote sends default to `queue`. Files use bounded raw binary transfer with SHA-256 verification and become ordinary Piclaw attachments at the receiver; binary data is never put in message text.

Inbound messages identify the authenticated peer and source agent and include an opaque reply address. Reply to that address exactly as supplied.

## Requirements

- Piclaw `>=2.12.0`
- Messaging runtime API v1
- External routes API v1

The add-on does not import Piclaw runtime internals.

## Storage

The add-on uses Piclaw's scoped data directory:

```text
<PICLAW_DATA>/addons/remote-peer/
├── identity.json
├── state.db
├── state.db-wal
├── state.db-shm
└── backups/
```

`identity.json` is written with mode `0600` where supported. `state.db` uses WAL, foreign keys, secure delete, a five-second busy timeout, integrity checks and explicit checksummed migrations.

Peer, message, proposal, receipt and audit ledgers are relational tables in `state.db`. They are not stored in extension KV and are not added to Piclaw's `messages.db`.

Normal add-on uninstall preserves the scoped data directory. Destructive identity/database reset will be an explicit confirmed Settings action in a later release.

## Pairing and management

```text
remote_peer({ action: "status" })
remote_peer({ action: "identity" })
remote_peer({ action: "list_peers" })
remote_peer({ action: "pending" })
remote_peer({ action: "pair_request", url: "https://peer.example" })
remote_peer({ action: "accept_pair", request_id: "pair_..." })
remote_peer({ action: "deny_pair", request_id: "pair_..." })
remote_peer({ action: "ping", peer: "peer-alias" })
remote_peer({ action: "set_alias", peer: "peer-alias", alias: "new-alias" })
remote_peer({ action: "roster" })
remote_peer({ action: "roster", peer: "peer-alias" })
remote_peer({ action: "advertise_agent", local_agent: "research", alias: "research", modes: ["queue", "auto"] })
remote_peer({ action: "set_policy", peer: "peer-alias", scope: "named-agents", mode_ceiling: "queue-auto", agents: ["research"] })
remote_peer({ action: "message_status", message_id: "rmsg_..." })
remote_peer({ action: "message_failures" })
remote_peer({ action: "revoke", peer: "peer-alias" })
```

The `/pair` command provides equivalent pairing actions. Only public identity metadata is returned. The private key is never returned through tools, commands, external routes, or the Settings API.

## Operator setup and pairing

After setup, use Piclaw's built-in `chat` tool with an address returned by `chat({ action: "directory" })`:

```text
chat({ target_address: "lab!inbox", content: "Please review this finding.", mode: "queue" })
```

Use `peer!inbox` for the default inbox or `peer!@alias` for an operator-advertised agent. Replies use an opaque `peer!reply.<capability>` address embedded in the authenticated peer-message block; it routes back to the original source context without disclosing a raw chat JID.

The add-on persists outbound/inbound ledgers, signs the exact request body, verifies the authenticated peer, calls core's safe peer-delivery ABI, and returns a signed durable receipt. Supplying an `idempotency_key` makes safe retries return the original receipt without a second timeline row.

Pairing defaults to `inbox-only`, `queue`, and file transfer disabled. Operators must explicitly advertise local aliases, grant each peer `named-agents` or `all-advertised` scope, raise the mode ceiling, and enable a bounded file policy. Both sender-side directory validation and receiver-side policy enforcement apply.

Detailed documentation:

- [Protocol](docs/protocol.md)
- [Security model](docs/security.md)
- [Mediated work](docs/mediated-work.md)
- [Operator guide](docs/operator-guide.md)
- [Troubleshooting](docs/troubleshooting.md)
- [Architecture diagram](docs/architecture.svg)
- [Release E2E matrix](docs/e2e-matrix.md)
- [0.2.0 three-instance MVP evidence](docs/e2e-mvp-0.2.0.md)

## Settings

The **Remote Peer** Settings pane provides:

- health, public identity, endpoint configuration, peer/pending/failure counts;
- immutable fingerprint/origin review for inbound pairing;
- peer aliases, messaging scopes, mode ceilings, revocation, and risk confirmations;
- operator-selected advertised local agents;
- pending requests, last-seen state, and failed-receipt status.

Fingerprint confirmation is required for acceptance and revocation. `all-advertised` and `steer` require the typed phrase `ALLOW REMOTE ACCESS`. Key rotation requires every peer be revoked first, then `ROTATE <current fingerprint>`; it archives the old identity and requires restart/re-pair. Runtime endpoint changes require a Piclaw restart. Browser payloads are redacted and never contain private keys, raw chat JIDs, reply capabilities, internal database paths, or unselected local agents.

![Remote Peer Settings pane](assets/settings-pane-microvm.png)

## Deferred beyond the chat MVP

Mediated `work_*` actions remain available for compatibility but are not part of the agent-chat MVP or default agent guidance. The MVP proves one-hop text/file conversation, opaque replies, delivery receipts and retry. It does not grant direct remote tool execution or multi-hop federation.

## Current scope

This release registers pairing, signed ping/revoke/message/roster/proposal/execute/result endpoints, the one-hop bang-address transport, and mediated work review. It does not grant a remote peer direct Piclaw tool execution.
